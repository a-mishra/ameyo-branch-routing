export const NavArrow = () => (
    <svg
      className="svg-icon"
      aria-hidden="true"
      role="img"
      focusable="false"
      xmlns="http://www.w3.org/2000/svg"
      width="9"
      height="14"
      viewBox="0 0 14 14"
    >
      <path 
        d="M7.55908 0.875427L1.76882 6.66569L7.55908 12.456" 
        stroke="#1AD0A5" 
        stroke-width="1.65467" 
        stroke-linecap="round"
      />
    </svg>
  );
