import React, {  useRef, useEffect, useState, useLayoutEffect } from 'react'
import { connect, styled , Global, css} from 'frontity';
import {layout, SectionAnimation} from '../../../utils/constants';
import {useOnScreen, useWindowDimentions, useContainerDimensions, useType} from '../../../utils/hooks/usehooks'
import { Section, Container } from '../../misc/layout';
import { motion, useMotionValue, useAnimation } from "framer-motion";

const SectionWrapper = styled.div`
position: relative;
overflow-x: clip;

.section-container {
    margin-top: ${layout.reponsiveCssValue(24, 36, 1200, 24, 1600, 36)};
    padding-top: 0px;

    ${layout.screen.mob} {
        padding-left: 0px;
        padding-right: 0px;
    }

}


.section-inner {

    background: rgba(255, 255, 255, 0.4);
    border: 2px solid rgba(255, 255, 255, 0.72);
    box-sizing: border-box;
    // backdrop-filter: blur(9px);
    border-radius: ${layout.reponsiveCssValue(19, 26, 1200, 19, 1600, 28)};

    ${layout.screen.mob} {
        border-radius: 28px;
    }

    .text-cards-container {
        display: flex;
        flex-direction: row;
        align-items: stretch;

        ${layout.screen.mob} {
            flex-direction: column;
        }

        .texts {
            position: relative;

            width: ${layout.reponsiveCssValue(300, 420, 1200, 300, 1600, 420)};
            .text-wrapper {
                width: ${layout.reponsiveCssValue(260, 345, 1200, 260, 1600, 345)};
            }

            padding-top: ${layout.reponsiveCssValue(32, 44, 1200, 32, 1600, 44)};
            padding-left: ${layout.reponsiveCssValue(35, 48, 1200, 35, 1600, 48)};

            ${layout.screen.mob} {
                padding-top: 32px;
                padding-left: 28px;
                padding-right: 28px;
                padding-bottom: 0px;
            }

            .texts-heading {
                color: #141416;
                margin-bottom: 29px;
            }

            .texts-heading-desktop {
                font-family: 'Roboto Slab';
                font-style: normal;
                font-weight: 500;
                font-size: 68.5006px;
                line-height: 97%;
            }

            .texts-description {
                margin-top: ${layout.reponsiveCssValue(4, 19, 1200, 2, 1600, 19)};
                color: #40413B;
            }

            .image-wrapper {
                position: absolute;
                bottom: 0;
            }

            ${layout.screen.mob} {
                padding-left: ${layout.constants.mobile_padding['level4'] || '0rem'};
                padding-right: ${layout.constants.mobile_padding['level4'] || '0rem'};                
                width: 100%;
                .text-wrapper {
                    width: 70%;
                }

                .image-wrapper {
                    position: absolute;
                    bottom: 0;
                    width: 30%;
                    right: 0;
                    padding-top: 4px;
                    padding-right: 4px;
                    max-height: 100%;
                    z-index: -1;
                }

                .texts-heading {
                    margin: 0rem;
                    font-family: 'Roboto Slab';
                    font-style: normal;
                    font-weight: 500;
                    font-size: 28px;
                    line-height: 44px;
                }

                .texts-description {
                    margin-top: 15px;
                    margin-bottom: 31px;
                }
            }
        }

        .cards {
            display: flex;
            flex-direction: column;
            flex: 1;
            width: 100%;

            padding-top: ${layout.reponsiveCssValue(32, 44, 1200, 32, 1600, 44)};
            padding-bottom: ${layout.reponsiveCssValue(32, 44, 1200, 32, 1600, 44)};
            padding-left: ${layout.reponsiveCssValue(35, 48, 1200, 35, 1600, 48)};
            padding-right: ${layout.reponsiveCssValue(35, 48, 1200, 35, 1600, 48)};

            ${layout.screen.mob} {
                padding-bottom: 35px;
            }
            
            ${layout.screen.xs} {
                padding: 0px;
                padding-bottom: 35px;
            }
        }

        .cards > div {
            &:not(:last-child) {
                margin-bottom: ${layout.reponsiveCssValue(21.54, 25, 1200, 25, 1600, 21.54)};
                ${layout.screen.mob} {
                    margin-bottom: 26px;
                }
            }
        }

        
    }
}

`;


const SectionPricingHero = ({state, actions, data, libraries}) =>  {
    const ref = useRef(null)
    const [onScreen, portionInView, viewed] = useOnScreen(ref, "0px");
    const Html2React = libraries.html2react.Component;
    const deviceType = useType();

    useEffect(() => {
        actions.intraPageLinks.update(data?.section?.internalLink, portionInView);
        return () => {
            actions.intraPageLinks.update(data?.section?.internalLink, 0);
        }
    }, [portionInView])

    const [sectionHeight, setsectionHeight] = useState(0);

    const handleResize = () => {
        if(ref.current) {
            setsectionHeight(ref.current.offsetHeight)
        }
    }
    
    useEffect(() => {
        handleResize();
        window.addEventListener("resize", handleResize)
        window.addEventListener("orientationchange", handleResize)
        
        return () => {
        window.removeEventListener("resize", handleResize)
        window.removeEventListener("orientationchange", handleResize)
        }
    }, [])


    return (
        <>
            <SectionWrapper  id={data?.section?.internalLink}>
                <Section padding={'level4'} className='section-container'>
                    <motion.div 
                        className="section-inner"
                        ref={ref}
                        variants={SectionAnimation}
                        initial={'hidden'}
                        animate={viewed ? 'show' : 'hidden'}
                        transition={{
                            ...SectionAnimation.transition(0, true)
                        }}
                        onAnimationComplete={handleResize}
                    >
    
                        <div className="text-cards-container"> 
                            <div className="texts">
                                <div className='text-wrapper'>
                                    <h2 className={`${deviceType=='mobile'? 'h2':'texts-heading-desktop'} texts-heading`}>{data.heading}</h2>
                                    <p className={`${deviceType=='mobile'? 'body1':'body1'} texts-description`}>{data.description}</p>
                                </div>

                                {/* image */}
                                <motion.div
                                    className='image-wrapper'
                                >
                                    <img src={data?.image?.url} alt={data?.image?.name}></img>
                                </motion.div>
                            </div>

                            <motion.div
                                className='cards'
                            >
                                {/* lightCard */}
                                <LightCard data={data?.cardLight} deviceType={deviceType}/>

                                {/* darkCard */}
                                <DarkCard data={data?.cardDark} deviceType={deviceType}/>
                            </motion.div>
                        </div>

                    </motion.div>
                </Section>

            </SectionWrapper>
        </>
    )
}


export default connect(SectionPricingHero)


const DarkCard = connect((props) => {
    const Html2React = props?.libraries?.html2react?.Component;

    return(
        <DarkCardWrapper isInnerCard={props.isInnerCard}>
            <div className="card-texts">
                { props.data?.heading && <h4 className={`${props.deviceType=='mobile'? 'h2':'h4'} card-heading`}><Html2React html={props.data?.heading || ''}/></h4>}
                { props.data?.description && <p className={`${props.deviceType=='mobile'? (props.isInnerCard ? 'body2': 'small-text1 bold'):'body3'} card-description`}>{props.data?.description}</p>}

                {
                    props.data?.list?.length > 0 &&
                    <div className ='list'>
                        <List data={props.data?.list}/>
                    </div>
                }
                {
                    props.data?.button?.title && <Button title={props.data?.button?.title} link={props.data?.button?.link} type={props.data?.button?.type?.value} />
                }

            </div>
        </DarkCardWrapper>
    )
})

const DarkCardWrapper = styled.div`

    ${(props)=>(props.isInnerCard == true ? `
        background: #EAEFEC;
        box-sizing: border-box;
        // backdrop-filter: blur(9px);
        border-radius: ${layout.reponsiveCssValue(8.56, 11.41, 1200, 8.56, 1600, 11.41)};
        // margin-top: ${layout.reponsiveCssValue( 60, 80,1200, 60, 1600, 80)};
        width: 100%;
    ` : `
        background: #EAEFEC;
        box-sizing: border-box;
        // backdrop-filter: blur(9px);
        border-radius: ${layout.reponsiveCssValue(19, 26, 1200, 19, 1600, 28)};
        // margin-top: ${layout.reponsiveCssValue( 60, 80,1200, 60, 1600, 80)};
        width: 100%;
    `)}


    ${layout.screen.mob} {
        margin-top: 0px;
        ${(props)=>(props.isInnerCard == true ? `
            border-radius: 12px;
        ` : `
            border-radius: 28px;
        `)}
    }

    .card-texts {
        display: flex;
        flex-direction: column;
        flex-grow: 1;
        position:relative;

        ${(props)=>(props.isInnerCard == true ? `
            padding-top: ${layout.reponsiveCssValue(18.55, 25.8, 1200, 18.55, 1600, 25.8)};
            padding-bottom: ${layout.reponsiveCssValue(23.75, 26.85, 1200, 23.75, 1600, 26.85)};
            padding-left: ${layout.reponsiveCssValue(28, 43, 1200, 28, 1600, 43)};
            padding-right: ${layout.reponsiveCssValue(28, 43, 1200, 28, 1600, 43)};
        ` : `
            padding-top: ${layout.reponsiveCssValue(14.57, 25.8, 1200, 14.57, 1600, 25.8)};
            padding-bottom: ${layout.reponsiveCssValue(35, 35, 1200, 35, 1600, 35)};
            padding-left: ${layout.reponsiveCssValue(48, 64, 1200, 48, 1600, 64)};
            padding-right: ${layout.reponsiveCssValue(48, 64, 1200, 48, 1600, 64)};
        `)}

        ${layout.screen.mob} {
            ${(props)=>(props.isInnerCard == true ? `
                padding-top: ${layout.reponsiveCssValue(18.55, 25.8, 1200, 18.55, 1600, 25.8)};
                padding-bottom: ${layout.reponsiveCssValue(23.75, 26.85, 1200, 23.75, 1600, 26.85)};
                padding-left: ${layout.reponsiveCssValue(28, 43, 1200, 28, 1600, 43)};
                padding-right: ${layout.reponsiveCssValue(28, 43, 1200, 28, 1600, 43)};
            `:`
                padding-top: ${layout.reponsiveCssValue(14.57, 42, 375, 42, 1200, 14.57)};
                padding-bottom: ${layout.reponsiveCssValue(35, 52, 375, 52, 1200, 35)};
                padding-left: ${layout.reponsiveCssValue(34, 48, 375, 34, 1200, 48)};
                padding-right: ${layout.reponsiveCssValue(34, 48, 375, 34, 1200, 48)};
            `)}
        }



        .card-heading {
            color: #0E342C;
            // margin-bottom: 47px;
            margin-bottom: 0.2px;

            ${layout.screen.mob} {
                margin-bottom: 6px;
            }
        }
        .card-description {
            color: #2F695D;
            margin-bottom: ${layout.reponsiveCssValue(17, 22.3, 1200, 17, 1600, 22.3)};

            ${layout.screen.mob} {
                margin-bottom: ${layout.reponsiveCssValue(35, 36, 375, 35, 1200, 36)};
            }
        }
      }
`;


const LightCard = (props) => {
    return(
        <LightCardWrapper>
            <div className="card-texts">
                <div className="pricing-container">
                    {
                        props.data?.pricings?.map((elem, index)=>(
                            <div className='item'>
                                <h4 className={`price-heading`}>{elem?.heading}</h4>
                                <p className={`${props.deviceType=='mobile'? 'small-text1 bold':'small-text1'} card-description`}>{elem?.description}</p>
                                <p className={`${props.deviceType=='mobile'? 'nav-text-6':'nav-text-6'} subtext`}>{elem?.subtext}</p>
                            </div>
                        ))
                    }
                </div>
                <DarkCard data={props.data.cardDark} isInnerCard={true} deviceType={props.deviceType}/>
            </div>
        </LightCardWrapper>
    )
}

const LightCardWrapper = styled.div`
    background: #ffffff;
    border: 2px solid rgba(255, 255, 255, 0.72);
    box-sizing: border-box;
    // backdrop-filter: blur(9px);
    border-radius: ${layout.reponsiveCssValue(19, 26, 1200, 19, 1600, 28)};
    // margin-top: ${layout.reponsiveCssValue( 60, 80,1200, 60, 1600, 80)};
    width: 100%;
    
    ${layout.screen.mob} {
        margin-top: 0px;
        border-radius: 28px;
    }

    .card-texts {
        display: flex;
        flex-direction: column;
        flex-grow: 1;
        position:relative;
        padding-top: ${layout.reponsiveCssValue(26.66, 36.66, 1200, 26.66, 1600, 36.66)};
        padding-bottom: ${layout.reponsiveCssValue(24, 28.66, 1200, 28.66, 1600, 24)};
        padding-left: ${layout.reponsiveCssValue(35, 48, 1200, 35, 1600, 48)};
        padding-right: ${layout.reponsiveCssValue(35, 48, 1200, 35, 1600, 48)};

        ${layout.screen.xs} {
            padding-top: 13px;
            padding-bottom: 35px;
            padding-left: 28px;
            padding-right: 28px;
        }

        .pricing-container {
            display: grid;
            grid-template-columns: repeat(2, 50%);
            margin-bottom: ${layout.reponsiveCssValue(9, 18, 1200, 18, 1600, 9)};
            // grid-column-gap: ${layout.reponsiveCssValue(48, 78, 1200, 48, 1600, 78)};
            // align-items: center;
            // justify-content: center;

            ${layout.screen.mob} {
                margin-bottom: 35px;
                grid-column-gap: 12px;
                grid-template-columns: repeat(2, auto);
            }

            .item {
                display: flex;
                flex-direction: column;
                align-content: center;
                justify-content: flex-start;
                text-align: center;
                max-width: 240px;
                margin-left: auto;
                margin-right: auto;

                ${layout.screen.mob} {
                    width: 100%;
                }


                .price-heading {
                    font-family: 'Roboto Slab';
                    font-style: normal;
                    font-weight: 500;
                    font-size: 60.8895px;
                    line-height: 109%;
                    color: #00AB88;
                    margin-bottom: 10.16px;
                    
                    ${layout.screen.mob} {
                        font-family: 'Roboto Slab';
                        font-style: normal;
                        font-weight: 500;
                        font-size: 44px;
                        line-height: 159%
                    }
                }

                .card-description {
                    margin-bottom: 3.81px;
                }

                .subtext {
                    color: #96A5A2;
                    ${layout.screen.mob} {
                        font-family: 'Roboto';
                        font-style: normal;
                        font-weight: 500;
                        font-size: 10px;
                        line-height: 160%;
                        text-align: center;
                        letter-spacing: 0.951398px;
                    }
                }
            }

        }

    }
`;



const List = (props) => {

    return(
        <StyledList>
            {
                props.data && props.data.map((elem, index)=>(
                    <li>
                        <span className='list-style-icon'></span><span className="h7">{elem?.title}</span>
                    </li>
                ))
            }
        </StyledList>
    )
}

const StyledList = styled.ul`
margin-bottom: ${layout.reponsiveCssValue(28, 24.2, 1200, 28, 1600, 24.2)};
display: grid;
grid-template-columns: repeat(2, 50%);
grid-row-gap: 25px;
grid-column-gap: 18px;

${layout.screen.xs} {
    grid-template-columns: repeat(1, auto);

}
${layout.screen.mob} {
    margin-bottom: ${layout.reponsiveCssValue(35, 36, 375, 35, 1200, 36)};
}
li {
    display: flex;
    .list-style-icon {
        width: 28.17px;
        height: 28.17px;
        border-radius: 50%;
        background: #fff;
        display: flex;
    }
    .h7 {
        margin-left: 18.79px;
        display: flex;
        flex: 1;
    }
    .h7 {
        color: #2F695D;
    }


    // &:not(:last-child) {
    //     margin-bottom: ${layout.reponsiveCssValue(21.54, 24, 1200, 24, 1600, 21.54)};
    // }

}
`;



// Start : Buttons component

const ButtonWrapper = styled.div`
    display: flex;
    justify-content: start;
    align-items: center;
    flex-wrap: wrap;

    .button {
        cursor: pointer;
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        border-width: 0px;
        border-color: rgba(255, 255, 255, 0.72);
        border-style: solid;
        padding: 13.2374px 78px;
        border-radius: 13.2374px;
        ${layout.screen.mob} {
            padding: 16px 84px;
            // width: 100%;
        }
        a {
            display: flex;
            flex-direction: row;
        }

        h1, h2, h3, h4, h5, h6 {
            flex: 1;
            ${layout.screen.mob} {
                white-space: nowrap;
            }
        }

        img {
            width: 6px;
        }

    }

    .button.dark {
        background: #00AB88;
        
        h1, h2, h3, h4, h5, h6 {
            color: #FFFFFF;
        }
    }

    .button.light {
        background: #ffffff;
        a {
            color: #1D6F5E;
        }
        h1, h2, h3, h4, h5, h6 {
            color: #2F695D;
        }
    }


    .button.transparent {
        background: transparent;
        border-width: none;
        border-color: none;
        border-style: none;
        padding: 0px 0px;
        border-radius: none;
        

        h1, h2, h3, h4, h5, h6 {
            margin: 0 2rem;
            ${layout.screen.mob} {
                margin: 0px;
            }
            color: #1D6F5E;
        }
    }


    .button.translucent {
        background: rgba(255, 255, 255, 0.4);
        box-sizing: border-box;
        backdrop-filter: blur(3.30935px);
        h1, h2, h3, h4, h5, h6 {
            color: #1D6F5E;
        }
        
    }

`;


const Button = ({type, title, link}) => {
    return (
        <ButtonWrapper>
            <motion.div 
                className={`button ${type}`}
                whileHover={{
                    scale: 1.05,
                    transition: { ease: 'anticipate', duration: 0.200 },
                }}
                whileTap={{ scale: 0.95 }}
            >
                <a href={`${link || 'javascript:void(0)'}`}>
                    <h5 className='button1'>{title}</h5>
                </a>
            </motion.div>
        </ButtonWrapper>
    )
}

// End : Buttons component

