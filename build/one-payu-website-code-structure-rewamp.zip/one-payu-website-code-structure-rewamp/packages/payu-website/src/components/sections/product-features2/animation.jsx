import React, {useRef, useState, useEffect} from 'react';
import { Player, Controls } from '@lottiefiles/react-lottie-player';
import { useCounter, useHover } from 'usehooks-ts' 
import { useOnScreen, useLottieContainerDimensions, useWindowDimentions } from '../../../utils/hooks/usehooks'; 
import {styled} from 'frontity'
import { layout } from '../../../utils/constants';
import { getDataFromNetworkOrLocalStorage } from '../../../utils/methods';

const Animation = ({lottie, animationText, inView, onLoad, height, width }) => {

    const player = useRef();
    const playerWrapper = useRef();

    const { count, setCount, increment, decrement, reset } = useCounter(0);
    const [animationDirection, setanimationDirection] = useState(1);
    const [animationState, setanimationState] = useState('');
    const [initalRenderCompleted, setinitalRenderCompleted] = useState(false)
    const [isLoaded, setisLoaded] = useState(false);
    const playerDimentions = useLottieContainerDimensions(playerWrapper, isLoaded);

    const loopStartFrame = lottie?.settings?.loopStartFrame || 0;
    
    const [page, setPage] = useState(0);

    const onEvent = (event) => {
        // take actions for events
        switch(event) {
            case "load": 
                if(inView) {
                    setPlayback(true);
                }
                setisLoaded(true);
                onLoad();
                break;

            case "play": 
                if(initalRenderCompleted) {
                    player?.current.setSeeker((loopStartFrame || 0 ), true);
                }
                break;

            case "frame":
                animationDirection ? increment() : decrement();
                if(count >=(loopStartFrame || 0 ) && initalRenderCompleted == false) {
                    setinitalRenderCompleted(true);
                }
                frameUpdateCheck();

                break;

            default :
                if(['loop', 'stop', 'complete'].includes(event)) {
                    resetAnimation();
                }
                break;
        }

        // update animation state
        if(['load', 'error', 'ready', 'play', 'pause', 'stop', 'freeze', 'complete'].includes(event))
            setanimationState(event);
    }

    const frameUpdateCheck = () => {

    }

    const resetAnimation = () => {
        if(initalRenderCompleted) {
            player?.current.setSeeker(loopStartFrame || 0, true );
        }
        setCount((loopStartFrame || 0 ));
    }

    const startAnimationFromFrame = (frameId) => {
        setCount(frameId);
        player?.current.setSeeker(frameId, true );
    }


    const setPlayback = (flag) => {
        if(flag) {
            if(initalRenderCompleted) {
                player?.current.setSeeker(count, flag);
                player?.current.play();
            }
            else
                player?.current.play();
        } else {
            player?.current.pause();
        }
    }


    // useEffect(() => {
    //     setPlayback(startFromFrame) // hover off karne par animation pause ho jayega, agar shouldPlay false hai to || Agar shouldPlay true hai to hover off ka koi effect nahi aayega.
    // }, [startFromFrame])

    useEffect(() => {
        if(inView === true)
        setImmediate(() => {
            setPlayback(true)
        }, 1000);

        
        else if(inView === false)
            setPlayback(false)
    }, [inView])



    const [lottieSrc, setlottieSrc] = useState(null)
    useEffect(() => {
        // setlottieSrc(getDataFromNetworkOrLocalStorage(lottie?.media?.url));
    }, [])




    return (
        <Wrapper playerDimentions={playerDimentions}>
            <div ref={playerWrapper}>
                <Player
                    onEvent={onEvent}
                    ref={player}
                    autoplay={true}
                    loop={true}
                    src={lottie?.media?.url} //  {lottieSrc} //
                    style={{ 
                        // height: 'auto', 
                        height: width/height > (640/800) ? height : 'auto',
                        width:  'auto', 
                        // width: width && width-16 || 'auto', 
                        maxHeight: height ? '100%' : 620, 
                        maxWidth: width,
                        overflow: 'visible'
                    }}
                    hover={false}
                    renderer="svg"
                    className="lottie-animation"
                    keepLastFrame={true}
                >
                    {
                        isLoaded && <div className="animation-texts">
                            <h4 className='h4'>{animationText?.heading}</h4>
                            <p className='body2'>{animationText?.description}</p>
                        </div>
                    }
                    {
                        isLoaded && <FauxShadowContainer />
                    }
                </Player>
                
            </div>
            
              {/* {
                  isLoaded && <FauxShadowContainer width={playerDimentions && playerDimentions.svgWidth || 0}/>
              } */}
            
        </Wrapper>
    );
}

export default Animation;


const Wrapper = styled.div`
.lf-player-container {
    position: relative;
    // box-shadow: rgba(149, 157, 165, 0.2) 0px 0px 24px;

    .animation-texts {
        position: absolute;
        bottom: 0;
        left: 0;
        padding: 5%;
        margin: 0 11% 0 11%;


        // heading w:433 -> font-size: font-size: 19.8px;
        // line-height: 31px;
        // w: 525 : font-size: 24 lineHeight: 38

        h1,h2,h3,h4,h5,h6 {
            // color: #0E342C;
            // font-size: 100%;
            // font-size: ${(props)=>(layout.reponsiveCssValue(0, 24, 475, 19.8, 574, 24, (props.playerDimentions?.width) ? `${(props.playerDimentions?.width)}px` : null)  )};
        }

        // p: 
        // 574: 26lh, 16fs letterspace: 1px
        // 475: 21lh, 13.2fs,letterspace 0.825px
        p {
            // color: #314235;
            // font-size: 75%;
            // line-height: 152%;
            // letter-spacing: 0.825px;
            
            // font-size: ${layout.reponsiveCssValue(0, 16, 475, 13.2, 574, 16, (playerDimentions?.width) ? `${(playerDimentions?.width)}px` : null)};
        }


    }
}
`;

const FauxShadowContainer = styled.div`
    position: absolute;
    bottom: -72px;
    height: 18px;
    width: calc( ${(props) => props.width}px * 1 );
    width: 100%;
    background: #b0b0b016;
    border-radius: 40%;
    z-index: -10;
    margin: 0px auto;
    box-shadow: rgba(149, 157, 165, 0.2) 0px 0px 24px;
`;



/*

height: auto Player ka
.lottie ka overflow visible;
.lottie>svg (first) ka bounding box lo, animation text wrapper ko bounding box mein place kar do


.lottie position relative;
.lottie width; 
animation text at left 0, bottom 0
animation text sizes based on .lottie width;

*/