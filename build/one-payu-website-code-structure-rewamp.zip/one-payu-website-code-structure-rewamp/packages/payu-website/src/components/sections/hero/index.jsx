import React, {  useRef, useEffect, useState, useLayoutEffect } from 'react'
import { connect, styled , Global, css} from 'frontity';
import {layout, SectionAnimation} from '../../../utils/constants';
import {getAnimDimentions} from '../../../utils/methods';
import {useOnScreen, useWindowDimentions, useContainerDimensions, useType} from '../../../utils/hooks/usehooks'
import { Section, Row, Col, Container } from '../../misc/layout';
import { motion, useMotionValue, useAnimation, AnimatePresence } from "framer-motion";

// import ThreadImage from '../../../assets/images/thread.svg'
import { getDataFromNetworkOrLocalStorage } from '../../../utils/methods';
import Animation from './animation';
import { useInterval } from "usehooks-ts";
import ReactPlayer from 'react-player/file'

const BackgroundMediaAnimation = {
    hidden: { opacity: 0, scale: 1, y: 0 },
    show: {
        opacity: 1,
        scale: 1,
        y: 0
    },
    transition: (n, longDelay=false) => ({
        ease: 'anticipate',
        duration: longDelay ? 0.8 : 0.5, 
        delay: (longDelay ? 0.8 : 0.5)*(n) - 0.1*n, 
    })
}


export const HeroMedia = {
    hidden: { opacity: 0, scale: 0.95, y: -60, x: '-50%' },
    show: {
        opacity: 1,
        scale: 1,
        y: 0,
        x: '-50%'
    },
    transition: (n, longDelay=false) => ({
        // y: { type: "spring",
        //   damping: 10,
        //   mass: 0.2,
        //   stiffness: 150
        //  }, 
        ease: 'anticipate',
        duration: longDelay ? 0.8 : 0.5, 
        delay: (longDelay ? 0.8 : 0.5)*(n) - 0.1*n, 
    })
}


const HeroSectionWrapper = styled.div`
position: relative;
overflow-x: clip;

.section {
    margin-top: 0px;
    padding-top: 0px;


    .section-inner {
        // min-height: calc( max(100vh - 2*${layout.constants.headerHeight}, 600px) );
        
        // height: calc( 100vh - 2*${layout.constants.headerHeight});
        // max-height: 700px;
        height: ${layout.reponsiveCssValue(520, 700, 1200, 520, 1600, 700)};
        // display: flex;
        // flex-direction: column;
        // flex: 1;
        position: relative;
        // justify-content: center;

        ${layout.screen.mob} {
            min-height: unset;
            // margin-top: ${layout.reponsiveCssValue(38, 58, 375,42, 993, 58)};
            margin-top: 340px;
            height: 100%;
            max-height: unset;
        }

        .media-container-mobile {
            display: none;
            
            ${layout.screen.mob} {
                display:flex;
                flex:1;
                position: relative;
                justify-content: center;
                align-items: center;
            }
            .media-animation-wrapper {
                margin: 8px;
                max-height: 600px;
            }

            .media-image-wrapper {
                margin: 8px;
                max-height: 600px;
            }


        }

        .text-container-maintext {

            // flex: 0 0 33%; // changed
            // width: 33%; // changed
            // display: flex;
            // justify-content: flex-start;
            // align-items: flex-start;
            // flex-direction: column;
            // margin-top: 0rem;
            // min-height: 400px;

            padding-top: ${layout.reponsiveCssValue(96, 120, 1200, 96, 1600, 120)};
            max-width: ${layout.reponsiveCssValue(350, 450, 1200, 350, 1600, 450)};

            
            ${layout.screen.mob} {
                width: 100%;
                flex: 1;
                min-height: unset;
                margin-top: ${layout.reponsiveCssValue(38, 58, 375,42, 993, 58)};
                padding-top: 24px;
            }

            h1 {
                max-width: min(550px, 100%);
                margin-top: 0px;
            }
            
            p {
                max-width:  ${layout.reponsiveCssValue(358, 465, 1200, 358, 1600, 465)}; //384px;
            }

            .button-container {
                margin-top: 1.8rem;
            }

        }

        .media-container {
            flex: 1;
            display: flex;
            justify-content: flex-end;
            align-items: center;
            height: ${layout.reponsiveCssValue(360, 479, 1440,412, 1600, 479)};

            ${layout.screen.mob} {
                display:none;
            }
            z-index: -1;

            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            overflow: none;

            .media-animation-wrapper {
                margin: 8px;
                max-height: 100%;
            }

            .media-image-wrapper {
                margin: 8px;
                max-height: 100%;
            }
        }

        .card-container {


            position: absolute;
            // bottom: 0;
            bottom: -36px;
            right: 0;


            display: flex;
            align-items: flex-end;
            justify-content: flex-end;
            flex:1;

            ${layout.screen.mob} {
                position: relative;
                bottom: unset;
                right: unset;
                display: flex;
                align-items: flex-start;
                justify-content: flex-end; // flex-start
                flex:1;
                margin-top: 40px;
            }

            .flashcards-wrapper {
                // max-width: 320px;
                width: ${layout.reponsiveCssValue(300, 386, 1200, 300, 1600, 386)};
                display: flex;
                flex-direction: column;
                flex:1;

                ${layout.screen.mob} {
                    width: unset;
                    max-width: 400px; // unset
                }

                h5 {
                    margin-bottom: 1.5rem;
                    color: #314235;
                }
                .flashcards-cards-container {
                    display: flex;
                    // gap: 2rem; // flex->gap safari <14.1 fix
                    flex-direction: column;

                }

                .flashcards-cards-container > div {
                    &:not(:last-child) {
                        margin-bottom: 2rem; // flex->gap safari <14.1 fix
                    }
                }

                .flashcard-button-container {
                    margin-top: 1.8rem;
                }
            }
        }

    }

    .icon-container {
        width: 80%;
        margin: 0 auto;
        margin-top: ${layout.reponsiveCssValue(97, 128, 1200,97, 1600, 128)};
        ${layout.screen.mob} {
            width: 100%;
            margin-top: 50px;
        }

        height: ${layout.reponsiveCssValue(20, 32, 1440, 25.22, 1600, 32)};
        ${layout.screen.mob} {
            height: ${layout.reponsiveCssValue(12, 16, 375, 13.41, 993, 16)};
        }

        position: relative;
        .icon-wrapper-2 {
            position: absolute;
            width: 100%;
        }
    }

}


.background-media {
    position: absolute;
    width: 100%;
    // bottom: 100px;  //TODO : test
    left: 0px;
    z-index: -2;
    ${layout.screen.mob} {
        display:none;
    }

    position: absolute;
    top: 45%;
    left: 50%;
    transform: translate(-50%, -50%) !important;
}


.background-media-mobile {
    position: absolute;
    width: 100%;
    // top: ${(props)=>(props.width*0.33)}px;
    top: -372px;
    left: 0px;
    z-index: -2;
    display:none;
    ${layout.screen.mob} {
        display:block;
    }
}

`;



const SectionWrapper = styled.div`
    position: relative;
    overflow-x: clip;

    .section {
        margin-top: 0px;
        padding-top: 0px;


        .section-inner {
            // min-height: calc( max(100vh - 2*${layout.constants.headerHeight}, 600px) );
            display: flex;
            flex-direction: column;
            flex: 1;
            position: relative;
            justify-content: center;

            // height: ${layout.reponsiveCssValue(480, 680, 1200, 480, 1600, 680)};
            margin-top: 18px;
            // height: ${layout.reponsiveCssValue(480, 680, 1200, 480, 1600, 540)};
            height: ${(props)=>(props.height ? `${props.height}px` : layout.reponsiveCssValue(480, 680, 1200, 480, 1600, 540))};
            // margin-top: ${layout.reponsiveCssValue(48, 78, 1200, 48, 1600, 78)};
            margin-top: calc(  min( 10vh, 78px) );



            ${layout.screen.mob} {
                min-height: unset;
                margin-top: ${layout.reponsiveCssValue(38, 58, 375,42, 993, 58)};
                height: unset;
                margin-top: 0px;
            }

            .media-container-mobile {
                display: none;
                margin: 0 auto;
                
                ${layout.screen.mob} {
                    display:flex;
                    flex:1;
                    position: relative;
                }
                .media-animation-wrapper {
                    margin: 0px;
                    max-height: 600px;
                }

                .media-image-wrapper {
                    margin: 8px;
                    max-height: 600px;
                }


            }

            .text-container-maintext {

                flex: 0 0 50%;
                width: 50%;
                display: flex;
                justify-content: center;
                align-items: flex-start;
                flex-direction: column;
                margin-top: 0rem;
                min-height: 400px;
                
                ${layout.screen.mob} {
                    width: 100%;
                    flex: 1;
                    min-height: unset;
                    margin-top: ${layout.reponsiveCssValue(38, 58, 375,42, 993, 58)};
                }

                h1 {
                    max-width: ${layout.reponsiveCssValue(450, 650, 1200, 450, 1600, 650)};
                    ${layout.screen.mob} {
                        max-width: min(550px, 100%);
                    }
                    margin-top: 0px;
                }
                
                p {
                    max-width: ${layout.reponsiveCssValue(395, 514, 1200, 395, 1600, 514)};
                }

                .button-container {
                    margin-top: 1.8rem;
                }

            }

            .media-container {
                flex: 1;
                display: flex;
                justify-content: flex-end;
                align-items: center;

                ${layout.screen.mob} {
                    display:none;
                }

                position: absolute;
                left: 50%;
                top: 0;
                bottom: 0;
                right: 0;
                overflow: none;

                .media-animation-wrapper {
                    margin: 8px;
                    max-height: 100%;
                }

                .media-image-wrapper {
                    margin: 8px;
                    max-height: 100%;
                }
            }

        }

        .icon-container {
            width: 80%;
            margin: 0 auto;
            ${layout.screen.mob} {
                width: 100%;
            }

            height: ${layout.reponsiveCssValue(20, 32, 1440, 25.22, 1600, 32)};
            margin-top: ${layout.reponsiveCssValue(20, 32, 1440, 25.22, 1600, 32)};
            ${layout.screen.mob} {
                height: ${layout.reponsiveCssValue(12, 16, 375, 13.41, 993, 16)};
                margin-top: ${layout.reponsiveCssValue(12, 16, 375, 13.41, 993, 16)};
            }


        }

    }


    .background-media {
        position: absolute;
        width: 100%;
        bottom: 0px;
        left: 0px;
        z-index: -2;
        ${layout.screen.mob} {
            display:none;
        }
    }


    .background-media-mobile {
        position: absolute;
        width: 100%;
        top: ${(props)=>(props.width*0.66)}px;
        left: 0px;
        z-index: -2;
        display:none;
        ${layout.screen.mob} {
            display:block;
        }
    }

`;


const SectionHero = ({state, actions, data, libraries}) =>  {

    const Html2React = libraries.html2react.Component;
    const isHero = data?.flashCards?.cards && data?.flashCards?.cards.length > 0 ? true : false;


    const ref = useRef(null)
    const [onScreen, portionInView, viewed] = useOnScreen(ref, "0px");
    useEffect(() => {
        actions.intraPageLinks.update(data?.section?.internalLink, portionInView);
        return () => {
            actions.intraPageLinks.update(data?.section?.internalLink, 0);
        }
    }, [portionInView])
    

    const [width, setwidth] = useState(0);
    const [windowWidth, setwindowWidth] = useState(0);
    const [animWidth, setanimWidth] = useState(0);
    const [animHeight, setanimHeight] = useState(0);
    
    const [height, setheight] = useState(0);
    const handleResize = () => {
        
        if(ref.current) {
            setwidth(ref.current.offsetWidth);
            setheight(ref.current.offsetHeight);
        }

        if(window?.innerWidth) {
            setwindowWidth(Math.min(1600, window.innerWidth));
            let animDimentions = getAnimDimentions(data?.settings?.animationSize?.value, window.innerWidth, false);
            setanimWidth(animDimentions.width);
            setanimHeight(animDimentions.height);
        }
    }

    useEffect(() => {
        // console.log('hero data', data)
        handleResize();
        window.addEventListener("resize", handleResize)
        window.addEventListener("orientationchange", handleResize)
        
        return () => {
        window.removeEventListener("resize", handleResize)
        window.removeEventListener("orientationchange", handleResize)
        }
    }, [])

    const handleRouteChange = (link) => {
        window.location.href = link
    }

    const deviceType = useType();

    if(isHero) {
        return (
            <HeroSectionWrapper width={width}>
                <Section padding={'level4'} className="section">
                    <motion.div 
                        className="section-inner"
                        ref={ref}
                    >
                        {/* <motion.div className="media-container-mobile"
                            variants={SectionAnimation}
                            initial={'hidden'}
                            animate={viewed ? 'show' : 'hidden'}
                            transition={{ 
                                ...SectionAnimation.transition(2)
                            }}
                        >
                            <MediaPlayer data={data?.media?.type?.value && data?.media?.data && data?.media?.data[data?.media?.type?.value]} mediaType={data?.media?.type?.value}/>
                        </motion.div> */}

                        <motion.div className={`text-container-maintext`}
                            variants={SectionAnimation}
                            initial={'show'}
                            animate={viewed ? 'show' : 'show'}
                            transition={{ 
                                ...SectionAnimation.transition(0, false)
                            }}
                        >
                            <p className="hero-product-name">{<Html2React html={data?.productName || ''} />}</p>
                            <h1 className="h1">
                                {<Html2React html={data?.heading || ''} />}
                            </h1>
                            <p class="body1">
                                {<Html2React html={data?.description || ''} />}
                            </p>
                            <div class="button-container">
                                <Buttons buttons={data?.buttons} changeRoute={handleRouteChange}/>
                            </div>
                        </motion.div>

                        <motion.div className="card-container"
                            variants={SectionAnimation}
                            initial={'show'}
                            animate={viewed ? 'show' : 'show'}
                            transition={{ 
                                ...SectionAnimation.transition(0)
                            }}
                        >
                            <div className="flashcards-wrapper">
                                <h5 className="h7">
                                    {<Html2React html={data?.flashCards?.heading} />}
                                </h5>
                                <div className="flashcards-cards-container">
                                    {
                                        data?.flashCards?.cards && data?.flashCards?.cards.map((elem, index)=>(
                                            <FlashCard image={elem?.image} title={elem?.heading} description={elem?.description} link={elem?.link} changeRoute={handleRouteChange}/>
                                        ))
                                    }
                                </div>
                                <div class="flashcard-button-container">
                                    <Buttons buttons={[data?.flashCards?.button]} mobAlignRight={false} changeRoute={handleRouteChange}/>
                                </div>
                            </div>
                        </motion.div>

                        {/* <motion.div className="media-container"
                            variants={HeroMedia}
                            initial={'hidden'}
                            animate={viewed ? 'show' : 'hidden'}
                            transition={{ 
                                ...HeroMedia.transition(2)
                            }}
                        >
                            <MediaPlayer height={`calc(  min( max(calc( 412px + (479 - 412) * (( 100vw - 1440px) / (1600 - 1440)) ) , 360px), 479px  ) )` } data={data?.media?.type?.value && data?.media?.data && data?.media?.data[data?.media?.type?.value]} mediaType={data?.media?.type?.value}/>
                        </motion.div> */}

                        

                    </motion.div>
                    <motion.div class="icon-container">
                            <Icons icons={data?.logo} viewed={viewed} switchingInterval={data?.settings?.switchingInterval}/>
                    </motion.div>
                </Section>
                <motion.div className="background-media"
                    variants={BackgroundMediaAnimation}
                    initial={'show'}
                    animate={viewed ? 'show' : 'show'}
                    transition={{ 
                        ...BackgroundMediaAnimation.transition(0)
                    }}
                >
                    <MediaPlayer 
                        width={windowWidth} 
                        height={windowWidth*(480/1200)} 
                        data={data?.section?.background?.type?.value && data?.section?.background?.data && data?.section?.background?.data[state?.environment?.isWindowsDesktop==true && data?.settings?.dontUseFallback?.value!=='true' ? ('video') : data?.section?.background?.type?.value]} 
                        mediaType={state?.environment?.isWindowsDesktop==true && data?.settings?.dontUseFallback?.value!=='true' ? ('video') : data?.section?.background?.type?.value}
                    />
                </motion.div>
                {
                    deviceType == 'mobile' &&
                    <motion.div className="background-media-mobile"
                        variants={BackgroundMediaAnimation}
                        initial={'show'}
                        animate={viewed ? 'show' : 'show'}
                        transition={{ 
                            ...BackgroundMediaAnimation.transition(0)
                        }}
                    >
                        <MediaPlayer height={372} data={data?.section?.background?.type?.value && data?.section?.background?.data && data?.section?.background?.data[data?.section?.background?.type?.value]} mediaType={data?.section?.background?.type?.value}/>
                    </motion.div>
                }
            </HeroSectionWrapper>
        )
    }


    return (
        <SectionWrapper width={width} height={animHeight}>
            <Section padding={'level4'} className="section">
                <motion.div 
                    className="section-inner"
                    ref={ref}
                >
                    {
                        deviceType == 'mobile' &&
                        <motion.div className="media-container-mobile"
                            variants={SectionAnimation}
                            initial={'hidden'}
                            animate={viewed ? 'show' : 'hidden'}
                            transition={{ 
                                ...SectionAnimation.transition(2)
                            }}
                        >
                            <MediaPlayer preserveAspectRatio={'xMidYMid meet'} width={animWidth} height={animHeight} data={data?.media?.type?.value && data?.media?.data && data?.media?.data[data?.media?.type?.value]} mediaType={data?.media?.type?.value}/>
                        </motion.div>
                    }

                    <motion.div className={`text-container-maintext`}
                        variants={SectionAnimation}
                        initial={'hidden'}
                        animate={viewed ? 'show' : 'hidden'}
                        transition={{ 
                            ...SectionAnimation.transition(0, true)
                        }}
                    >
                        <p className="hero-product-name">{<Html2React html={data?.productName || ''} />}</p>
                        <h1 className="h1">
                            {<Html2React html={data?.heading || ''} />}
                        </h1>
                        <p class="body1">
                            {<Html2React html={data?.description || ''} />}
                        </p>
                        <div class="button-container">
                            <Buttons buttons={data?.buttons} changeRoute={handleRouteChange}/>
                        </div>
                    </motion.div>

                    <motion.div className="media-container"
                        variants={SectionAnimation}
                        initial={'hidden'}
                        animate={viewed ? 'show' : 'hidden'}
                        transition={{ 
                            ...SectionAnimation.transition(2)
                        }}
                    >
                        <MediaPlayer 
                        preserveAspectRatio={'xMidYMid meet'} 
                        width={animWidth} 
                        height={animHeight} 
                        data={data?.media?.type?.value && data?.media?.data && data?.media?.data[state?.environment?.isWindowsDesktop==true && data?.settings?.dontUseFallback?.value!=='true' ? ('video') : data?.media?.type?.value]} 
                        mediaType={state?.environment?.isWindowsDesktop==true && data?.settings?.dontUseFallback?.value!=='true' ? ('video') : data?.media?.type?.value}
                        
                        />
                    </motion.div>

                    

                </motion.div>
                <motion.div class="icon-container">
                        <Icons icons={data?.logo} viewed={viewed} switchingInterval={data?.settings?.switchingInterval}/>
                </motion.div>
            </Section>
            {/* <motion.div className="background-media"
                variants={BackgroundMediaAnimation}
                initial={'hidden'}
                animate={viewed ? 'show' : 'hidden'}
                transition={{ 
                    ...BackgroundMediaAnimation.transition(3)
                }}
                style={{bottom:'180px'}}
            >
                <MediaPlayer data={data?.section?.background?.type?.value && data?.section?.background?.data && data?.section?.background?.data[data?.section?.background?.type?.value]} mediaType={data?.section?.background?.type?.value} />
            </motion.div> */}
            {/* <motion.div className="background-media-mobile"
                variants={BackgroundMediaAnimation}
                initial={'hidden'}
                animate={viewed ? 'show' : 'hidden'}
                transition={{ 
                    ...BackgroundMediaAnimation.transition(3)
                }}
            >
                <MediaPlayer data={data?.section?.background?.type?.value && data?.section?.background?.data && data?.section?.background?.data[data?.section?.background?.type?.value]} mediaType={data?.section?.background?.type?.value}/>
            </motion.div> */}
        </SectionWrapper>
    )

}

export default connect(SectionHero)




// Start: Icons component
// const IconsWrapper = styled.div`
// display: flex;
// justify-content: center;
// align-items: center;

// `;

// const Logo = styled.div`
//     max-height: 1.6rem;
//     margin: 0px 1.5rem;
// `;

// const Icons = ({icons}) => {
//     return (
//         <IconsWrapper>
//             {icons && icons.map((elem)=>{
//                 return(
//                     <Logo>
//                         <img src={elem?.image?.url} alt={elem?.image?.name}/>
//                     </Logo>
//                 )
                
//             })}
//         </IconsWrapper>
//     )
// }
// End: Icons component


// Start : Icons component

const IconsWrapper = styled.div`
    display: flex;
    justify-content: space-around;
    align-items: center;
    flex-wrap: wrap;
    gap: 30px;

    ${layout.screen.mob} {
        // justify-content: space-evenly;
        justify-content: space-between;
        gap:unset;
        max-width: 550px;
        margin: 0 auto;
    } 
`;

const Logo = styled.div`
    display: flex;
    justify-content: center;
    flex-basis: 64px;
    img {
        height: 100%;
        width: auto;
    }

    height: ${layout.reponsiveCssValue(20, 32, 1440, 25.22, 1600, 32)};
    ${layout.screen.mob} {
        height: ${layout.reponsiveCssValue(12, 16, 375, 13.41, 993, 16)};
        flex-basis: 16px;
    } 
`;


const Icons = ({icons, viewed, switchingInterval}) => {
    // get the number of pages,
    // create a interval, based on user input default to 10s
    // define n=6, number of icons in each page
    // for last page icons would be last set of n icons;

    const [page, setpage] = useState(0);
    const delay = (switchingInterval || 10)*1000;
    const numberOfIconsOnPage = 6;

    useInterval(
        () => {
            let range = Math.ceil(icons?.length / numberOfIconsOnPage) ;
            if(range)
                setpage(((page+1) % range));
        },
        delay
    );

    const [modifiedIconsArray, setmodifiedIconsArray] = useState([]);

    useEffect(() => {
        let numberOfPages = Math.ceil(icons?.length / numberOfIconsOnPage);
        let tempArray = [];
        for(let i = 0; i < numberOfPages ; i++) {
            tempArray[i] = icons.slice(i*numberOfIconsOnPage, numberOfIconsOnPage + i*numberOfIconsOnPage);

            if( i == (numberOfPages - 1) ) {
                let offset = numberOfPages*numberOfIconsOnPage - icons.length;
                tempArray[i] = icons.slice( (i*numberOfIconsOnPage)-offset, numberOfIconsOnPage + (i*numberOfIconsOnPage)-offset)
            }
        }
        setmodifiedIconsArray(tempArray);
    }, [])
    


    return (
        <motion.div
            variants={SectionAnimation}
            initial={{x: 0, opacity: 0}}
            animate={viewed ? {x:0, opacity: 1} : {}}
            transition={{
                staggerChildren: 0.1,
                delayChildren: 0.3,
                duration: 0.5,
                delay: 0.5,
                ...BackgroundMediaAnimation.transition(1)
            }}
        >
            
                {/* {icons && icons.map((elem)=>(
                        <Logo>
                            <img src={elem?.image?.url} alt={elem?.image?.name}/>
                        </Logo>
                    )
                )} */}
                {modifiedIconsArray?.map((elem, index)=>(
                        <AnimatePresence>
                            {page == (index) && (
                                <motion.div
                                    initial={{
                                        opacity: 0, y: 20, scale: 0.95, 
                                    }}
                                    animate={{ opacity: 1, y:0, scale: 1 ,
                                        transition: {
                                            delay: 0.7,
                                            duration: 0.5
                                        }
                                    }}
                                    exit={{ opacity: 0, y: 20, scale: 0.95 ,
                                        transition: {
                                            delay: 0,
                                            duration: 0.5
                                        } 
                                    }}
                                    className='icon-wrapper-2'
                                >
                                    <IconsWrapper>

                                        {elem && elem.map((elem)=>(
                                                <Logo>
                                                    <img src={elem?.image?.url} alt={elem?.image?.name}/>
                                                </Logo>
                                            )
                                        )}
                                    </IconsWrapper>

                                </motion.div>
                            )}
                        </AnimatePresence>
                ))}
            
        </motion.div>
    )
}
// End: Icons component


// Start: Buttons component
const ButtonsWrapper = styled.div`
    display: flex;
    justify-content: start;
    align-items: center;
    flex-wrap: wrap;
    //gap: 12px; // flex->gap safari <14.1 fix

    ${layout.screen.mob} {
        justify-content: ${(props)=> (props.mobAlignRight ? 'flex-end' : 'flex-start')}
    }

    .button {
        cursor: pointer;
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        padding: 13.2374px 26.4748px;
        border-radius: 13.2374px;
        margin-right: 12px; // flex->gap safari <14.1 fix

    }

    .button.dark {
        background: #00AB88;
        a {
            color: #FFFFFF;
        }
    }

    .button.light {
        background: #ffffff;
        a {
            color: #2F695D;
        }
    }


    .button.transparent {
        background: transparent;
        padding: 0px;

        a {
            // color: #2F695D;
        }
    }


    .button.translucent {
        background: rgba(255, 255, 255, 0.4);
        border: 1.65467px solid rgba(255, 255, 255, 0.72);
        box-sizing: border-box;
        backdrop-filter: blur(3.30935px);
        border-radius: 9.92803px;
        padding: 9.92803px 16.5467px;
        a {
            color: #00AB88;
        }
    }

`;

const Buttons = ({buttons, mobAlignRight, changeRoute}) => {
    return (
        <ButtonsWrapper mobAlignRight={mobAlignRight}>
            {buttons && buttons.map((elem, index)=>{
                return(
                    
                        <motion.div className={`button ${elem?.type?.value}`}
                        whileHover={{
                            scale: 1.05,
                            transition: { ease: 'anticipate', duration: 0.200 },
                        }}
                        whileTap={{ scale: 0.95 }}
                        onTap={()=>{changeRoute(elem?.link)}}
                        >
                            <a href={`${elem?.link || 'javascript:void(0)'}`} className={elem?.type?.value == 'transparent' ? 'button2' : 'button1'}>
                                {elem.title}
                            </a>
                        </motion.div>
                    
                )
                
            })}
        </ButtonsWrapper>
    )
}
// End: Buttons component




// Start: FlashCard component
const FlashCardWrapper = styled.div`
    display: flex;
    flex-direction: row;
    cursor: pointer;

    .image-container-flashcards {
        height: 100%;
        border-radius: 12px;
        display: flex;
        align-items: baseline;
        img {
            height: auto;
            width: ${layout.reponsiveCssValue(73.85,96, 1200, 73.85, 1600, 96)};
            ${layout.screen.mob} {
                width: 96px;
            }
        }
    }

    .text-container-flashcards {
        min-width: 150px;
        margin-left: 18px;
        ${layout.screen.mob} {
            margin-left: 22px;
        }
        display: flex;
        flex-direction: column;
        gap: 8px;
        h6 {
            // color: #314235;
        }
        p {
            // color: #2F695D;
            // margin-top: 8px;
            margin-bottom: 0rem;
        }

    }
`;

export const FlashCard = ({image, title, description, link, changeRoute }) => {

    return (
        <FlashCardWrapper onClick={()=>{changeRoute(link)}}>
            <div className="image-container-flashcards">
                {image?.url && <img src={image.url}/>}
            </div>
            <div className="text-container-flashcards">
                <h6 className='small-text1 bold'>{title}</h6>
                <p className="small-text1 semibold">{description}</p>
            </div>
        </FlashCardWrapper>
    )
}
// End: FlashCard component




// Start: MediaPlayer component
export const MediaPlayer = ({mediaType, data, width, height, inView, preserveAspectRatio}) => {

    if(mediaType == 'animation')
        return(
            <div class={`media-${mediaType}-wrapper`}> 
                <Animation 
                    lottie={data}
                    inView={true}
                    onLoad={()=>{}}
                    height={height || 'auto'}
                    width={width || 'auto'}
                    preserveAspectRatio={preserveAspectRatio}
                />
            </div>
        );
    
    if(mediaType == 'image')
        return(
            <div class={`media-${mediaType}-wrapper`}> 
                <img src={data?.url} height={height || 'auto'} width={width || 'auto'}/>
            </div>
        )

    if(mediaType == 'video')
            return(
                <div class={`media-${mediaType}-wrapper`}> 
                    <ReactPlayer 
                        url={data?.url || ''}
                        className='react-player'
                        playing
                        width={width || 'auto'}
                        height= {height || 'auto'}
                        controls={false}
                        loop={true}
                        muted={true}
                        playsinline={true}
                    />
                </div>
            )
    
    return(
        <></>
    )
}
// End: MediaPlayer Component