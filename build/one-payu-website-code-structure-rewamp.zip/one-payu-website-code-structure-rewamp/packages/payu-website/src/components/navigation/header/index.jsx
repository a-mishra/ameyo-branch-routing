import React from 'react'
import {connect, styled} from 'frontity'

const Header = ({state, libraries}) => {

    let headerData = state?.nav?.header
    const Html2React = libraries.html2react.Component;

    return (
        <HeaderWrapper>
            {headerData?.content && (
                <div>
                    <Html2React html={headerData?.content?.rendered || ''} />
                </div>
            )}
        </HeaderWrapper>
    )
}

export default connect(Header)


const HeaderWrapper = styled.header`
    max-width: 1600px;
    margin-left: auto;
    margin-right: auto;
`;