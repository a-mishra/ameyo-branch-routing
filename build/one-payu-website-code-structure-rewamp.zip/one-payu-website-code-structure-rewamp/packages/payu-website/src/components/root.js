import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React, {useEffect} from "react";
import { Global, connect, styled } from "frontity";
import Switch from "@frontity/components/switch";

import Pages from './pages';
import Loading from './pages/misc/loading'
import Error from './pages/misc/error'

import Meta from './pages/misc/meta'
import Header from "./navigation/header";
import Footer from "./navigation/footer";

import { layout } from "../utils/constants";
import { getPostToRender } from "../utils/methods";

import globalStyles from "./styles/global-styles";


const Root = ({ state, actions }) => {

  const data = state.source.get(getPostToRender(state.router.link));

  useEffect(() => {
    actions?.analytics?.pageview?.()
  }, [])
  

  return (
    <>
      <Meta />

      <Global styles={globalStyles(state.theme.colors)} />

      {/* <FontFaces /> */}
      <link rel="preconnect" href="https://fonts.googleapis.com"/>
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
      <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Roboto+Slab:wght@300;400;500;700&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet"/>

      <HeadContainer>
        <Header />
      </HeadContainer>

      <Main>
        <Switch>
          <Loading when={data.isFetching} />
          <Pages when={data.isPage} />
          <Error when={data.isError} />
        </Switch>
      </Main>

      <FooterContainer>
        <Footer/>
      </FooterContainer>
    </>
  );
};

export default connect(Root);

const HeadContainer = styled.div`

`;
const FooterContainer = styled.div`
  margin-top: ${layout.reponsiveCssValue( 100, 100 ,375, 100, 1200, 100)};
  padding-top: ${layout.reponsiveCssValue( 24, 30 ,375, 24, 1200, 30)};
  width:100%;
  ${layout.screen.mob} {
    padding-top: 1.5rem;
    margin-top: 0rem;
  }
`;

const Main = styled.div`
  display: flex;
  justify-content: center;
`;