import { styled, connect } from "frontity";

const description = (
  <>
    Don&apos;t panic! Seems like you encountered an error. If this persists,
    <a href="https://payu.in"> let us know </a> or try refreshing
    your browser. You can also search for it.
  </>
);


const Error = ({ state }) => {
  const title = "Oops, something bad happened";

  return (
    <Container size="thin">
      <p className="h3 main-text">Oops! Something went wrong. Try reloading the page or get back after some time.</p>
      <a className="button2 button-text" href={state.frontity.url}>Back to homepage</a>
    </Container>
  );
};

export default connect(Error);


export const EntryTitle = styled.h1`
  margin: 0;

  @media (min-width: 700px) {
    font-size: 6.4rem !important;
  }

  @media (min-width: 1200px) {
    font-size: 8.4rem !important;
  }
`;

const IntroText = styled.div`
  margin-top: 2rem;
  line-height: 1.5;

  @media (min-width: 700px) {
    font-size: 2rem;
    margin-top: 2.5rem;
  }
`;

const maxWidths = {
  thin: "58rem",
  small: "80rem",
  medium: "100rem",
};

const getMaxWidth = (props) => maxWidths[props.size] || maxWidths["medium"];

const SectionContainer = styled.div`
  margin-left: auto;
  margin-right: auto;
  width: calc(100% - 4rem);
  max-width: ${getMaxWidth};

  @media (min-width: 700px) {
    width: calc(100% - 8rem);
  }
`;


const Container = styled(SectionContainer)`
  text-align: center;
  padding-top: 8rem;

  .main-text {
    margin-bottom: 2rem;
    max-width: 700px;
    margin-left: auto;
    margin-right: auto;
  }

  .button-text {
    margin-bottom: 2rem;
    max-width: 700px;
    margin-left: auto;
    margin-right: auto;
  }
`;
