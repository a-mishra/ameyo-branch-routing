import React, {  useRef, useEffect, useState, useLayoutEffect } from 'react'
import { connect, styled , Global, css} from 'frontity';
import {layout} from '../../../utils/constants';
import {useOnScreen, useWindowDimentions} from '../../../utils/hooks/usehooks'
import SequenceReveal from '../sequence-reveal'
import {ParallaxBox} from '../parallax-box'
import { Section, Row, Col, Container } from '../../misc/layout';

import Slider from "react-slick";
import SlickCSS from "slick-carousel/slick/slick.css";
import SlickTheme from "slick-carousel/slick/slick-theme.css";

const SectionWrapper = styled.div`
    min-height: 300px;
    position: relative;
    padding-bottom: 3rem;

    .section-inner {
        position: relative;
    }
    
    .section-inner.small {
        margin: 0px 1.5rem;
    }

    .backdrop {
        position: absolute;
        background: rgba(255, 255, 255, 0.4);
        border: 2px solid rgba(255, 255, 255, 0.72);
        box-sizing: border-box;
        backdrop-filter: blur(4px);
        /* Note: backdrop-filter has minimal browser support */

        border-radius: 28px;
    }

    .backdrop.first {
        width: 92%;
        height: 300px;
        z-index: -1;
        left: 4%;
        bottom: -1.5rem;
    }

    .backdrop.second {
        width: 84%;
        height: 300px;
        z-index: -2;
        left: 8%;
        bottom: -2.5rem;
    }

    .white-bkg {
        background: #FFFFFF;
        border-radius: 28px;
        z-index: 30;
        padding: 78px 48px 16px 48px;
    }

    .top-section {
        padding: 0px 62px;
        display: flex;

        .texts {
            flex: 3;
        }

        .logos {
            display: flex;
            flex: 5;
            align-items: center;
            justify-content: center;

            .logocontainer {
                width: 90%;
            }
            
        }

    }

    .swiper-section {
        padding: 0px 48px;
        width: 100%;
        margin-top: 2rem;
        .swiper-card {
            display: flex;
            .profile-container {
                flex: 3;
                margin: 0px 32px; 
                position: relative;
                aspect-ratio: 7/8;

                .image-green-background {
                    position: absolute;
                    bottom: 0px;
                    // background: linear-gradient(349.06deg, #1268B3 -76.74%, rgba(255, 255, 255, 0) 91.9%), #CFE4BF;
                    background: linear-gradient(349.06deg, #1268B3 -100%, rgba(255, 255, 255, 0) 50%), #CFE4BF;
                    opacity: 0.5;
                    backdrop-filter: blur(200px);
                    border-radius: 28px;
                    width: 100%;
                    aspect-ratio: 7/6;
                }

                .details-container {
                    position: absolute;
                    top: 0px;
                    width: 100%;
                    /* aspect-ratio: 1/1; */
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    flex-direction: column;

                    img {
                        width: 72%;
                        height: auto;
                    }

                    .text-container {
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        margin-top: 2rem;
                        p {
                            margin-top: 0.5rem;
                        }
                    }
                }
            }

            .text-and-cards-container {
                display:flex;
                flex: 6;
                padding: 0px 16px;
                flex-direction: column;

                .texts {
                    display: flex;
                    align-items: start;
                    justify-content: start;
                    flex-direction: column;
                    flex-grow: 1;
                    p {
                        margin-top: 1rem;
                    }
                }

                .texts.center {
                    justify-content: center;
                }

                .small-cards {
                    align-items: center;
                    display: flex;
                    flex-direction: row;
                    justify-content: flex-end;

                    .small-cards-heading {
                        display: flex;
                        align-item: center;
                        justify-content: center;
                        h6 {
                            color: #2F695D;
                        }
                    }

                    .small-cards-items {
                        display: flex;
                        flex-direction: row;
                        margin-left: 1rem;
                    }
                }
            }
        }

        .slick-dots {
            position: relative;
            bottom: -25px;
            padding-top: 1.5rem;
            padding-bottom: 1rem;
            
            ul {
                margin-top: 0px;
                li {
                    border: 2px solid #BFDFBA;
                    width: 40px;
                    height: 0px;
                    border-radius: 2px;
                    button {
                        width: 40px;
                    }
                }

                li.slick-active {
                    border: 2px solid #00AB88;
                }
            }
        }
        
    }
`;


const sliderDesktopSettings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    appendDots: dots => (
        <div>
          <ul> {dots} </ul>
        </div>
      )
  }


const SectionTestimonials = ({state, actions, data, libraries}) =>  {

    const ref = useRef(null)
    const [onScreen, portionInView] = useOnScreen(ref, "0px");

    useEffect(() => {
        actions.intraPageLinks.update(data?.section?.internalLink, portionInView);
        return () => {
            actions.intraPageLinks.update(data?.section?.internalLink, 0);
        }
    }, [portionInView])

    const windowDimentions = useWindowDimentions();


    const Html2React = libraries.html2react.Component;


    return (
        <>
        <Global styles={css([SlickCSS, SlickTheme ])} />
    <SectionWrapper ref={ref}>
        <ParallaxBox fadeOut={false} easing={'backInOut'}>
            <SequenceReveal sequence={0} inView={onScreen}>
                <Section padding={'level3'} debug={layout.constants.debug}  id={data?.section?.internalLink}>
                    <div className={`section-inner ${data && data.logo && data.logo.length > 0 ? '': 'small'}`}  >
                        <div className="white-bkg">
                            <div className="top-section">
                                <div className="texts">
                                    <Row>
                                        <Col sm={12} ><h3>{data.heading}</h3></Col>
                                        <Col sm={12} ><p className={'large'}>{data.description}</p></Col>
                                    </Row>
                                </div>
                                
                                {
                                    data && data.logo && data.logo.length > 0 && 
                                    <div className="logos">
                                        <div className="logocontainer">
                                            <Icons icons={data.logo}/>
                                        </div>
                                    </div>
                                }
                                

                            </div>

                            <div className="swiper-section">
                                <Slider {...sliderDesktopSettings}>
                                    {
                                        data && data.cards && data.cards.map((elem, index)=>(
                                            <div>
                                                <div className="swiper-card">
                                                    <div className="profile-container">
                                                        <div className="image-green-background"></div>
                                                        <div className="details-container">
                                                            <img src={elem?.image?.url} />
                                                            <div className="text-container">
                                                                <h6>{elem.personName}</h6>
                                                                <p>{elem.personOccupatioin}</p>
                                                            </div>
                                                        </div>
                                                        
                                                    </div>

                                                    <div className="text-and-cards-container">
                                                        <div className={`texts ${elem.smallCards && elem.smallCards.length > 0 ? '': 'center'}`}>
                                                            <h4>{elem.heading}</h4>
                                                            <p>{elem.description}</p>
                                                        </div>

                                                        <div className="small-cards">
                                                            <div className="small-cards-heading">
                                                                <h6>{<Html2React html={elem?.smallCardsHeading || ''} />}</h6>
                                                            </div>
                                                            <div className="small-cards-items">
                                                                {elem.smallCards && elem.smallCards.map((item, index)=>(
                                                                    <SmallCard image={item.image} title={item.heading} description={item.description} link={item.link}/>
                                                                ))}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        ))
                                    }
                                </Slider>
                            </div>

                        </div>

                        <div className="backdrop first"></div>
                        <div className="backdrop second"></div>
                    </div>
                </Section>
            </SequenceReveal>
        </ParallaxBox>
    </SectionWrapper>
    </>
    )

}

export default connect(SectionTestimonials)


// Start : Icons component

const IconsWrapper = styled.div`
display: flex;
justify-content: center;
align-items: center;

`;

const Logo = styled.div`
max-height: 2rem;
margin-left: 48px;
`;


const Icons = ({icons}) => {
    return (
        <IconsWrapper>
            {icons && icons.map((elem)=>{
                return(
                    <Logo>
                        <img src={elem?.image?.url} alt={elem?.image?.name}/>
                    </Logo>
                )
                
            })}
        </IconsWrapper>
    )
}

// End : Icons component



// Start : SmallCard component

const SmallCardWrapper = styled.div`
    display: flex;
    flex-direction: row;

    .image-container {
        height: 100%;
        border-radius: 12px;
        img {
            height: auto;
            width: 78px;
        }
    }

    .text-container {
        min-width: 150px;
        margin-left: 18px;
    }
`;

export const SmallCard = ({image, title, description, link }) => {

    return (
        <SmallCardWrapper>
            <div className="image-container">
                {image?.url && <img src={image.url}/>}
            </div>
            <div className="text-container">
                <h6>{title}</h6>
                <p className="small">{description}</p>
            </div>
        </SmallCardWrapper>
    )
}

// End : SmallCard component
