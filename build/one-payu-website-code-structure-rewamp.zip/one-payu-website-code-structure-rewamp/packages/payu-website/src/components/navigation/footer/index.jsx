import React from 'react'
import {connect} from 'frontity'

// get config for the post slug of footer component
// get the data for the footer post
// render that data in the footer --- preprocessor will come in action before render and crete the footer component


const Footer = ({state, libraries}) => {

    let footerData = state?.nav?.footer
    const Html2React = libraries.html2react.Component;

    return (
        <footer>
            {footerData?.content && (
                <div>
                    <Html2React html={footerData?.content?.rendered || ''} />
                </div>
            )}
        </footer>
    )
}

export default connect(Footer)
