 import { homeConfig, constants } from './constants';
 import localForage from "localforage";
  
  // Using config()
  localForage.config({
    // driver: [
    //   localForage.INDEXEDDB,
    //   localForage.LOCALSTORAGE,
    //   localForage.WEBSQL,
    // ],
    name: 'myApp',     // These fields
    version: 1.0,      // are totally optional
  });

export const URLObject = (link) => {
    let url = new URL(constants.links.payu.payu+link || '');
    return url;
}

export const getCurrentNavigationMenu = (link) => {
    let url = URLObject(link);
    let pathname = url.pathname;
    pathname = pathname.split('/');
    pathname = pathname.filter((item)=>{ return item!=""});
    return pathname && pathname.length > 0 && pathname[0] || homeConfig.menu.name ;
 }
    

export const getQueryStringParameterByName = (name, link) => {
    let url = URLObject(link);
    return url.searchParams.get(name);
}
 

export const getPostToRender =  ( link ) => {
    let url = URLObject(link);
    let pathname = url.pathname;
    pathname = pathname.split('/');
    pathname = pathname.filter((item)=>{ return item!=""});
    if(pathname.length > 0) {
      // console.log('rendering : ',`/${pathname[pathname.length - 1]}` )
      return `/${pathname[pathname.length - 1]}`;
    } else  {
      // console.log('rendering : ',homeConfig.page.slug )
      return homeConfig.page.slug;
    }

};
 

export const getLocalState = key => {
    try {
      const state = localStorage.getItem(key);
      if (state === null) {
        return undefined;
      }
      return state;
    } catch (err) {
      return undefined;
    }
  };
  
  export const setLocalState = (key, value) => {
    try {
      const state = JSON.stringify(value);
      localStorage.setItem(key, state);
    } catch {
      // ignore write errors
    }
  };


export const getDataFromNetworkOrLocalStorage = (key) => {
    let media = getLocalState(key);
    if(media) {
        return media;
    }
    else {
        // fetch media data 
        fetch(key)
        .then(response => response.json())
        .then(data => {
            // console.log(data);
            setLocalState(key, data);
            return data;
        })
        .catch((error) => {
            console.error('Error:', error);
            return undefined;
        });
    }
}

export const getAnimDimentions = (animSize, windowWidth, freewidth=true) => {
  let dimentions = {
    width: 0,
    height: 0
  }

  const sizeMaps = {
    '640x800' : {
      mob: {
        width: 320,
        height: 400
      },
      xxl: {
        width: 640,
        height: 800
      },
      lg: {
        width: 492,
        height: 615
      }
    },

    '580x540' : {
      mob: {
        width: 318,
        height: 300
      },
      lg: {
        width: 440,
        height: 410
      },
      xxl: {
        width: 580,
        height: 540
      }
    },

    '630x500' : {
      mob: {
        width: 330,
        height: 340
      },
      lg: {
        width: 484,
        height: 384
      },
      xxl: {
        width: 630,
        height: 500
      }
    }
  }

  if(sizeMaps?.[animSize]) {
    dimentions.height = Math.min(Math.max( (sizeMaps?.[animSize]?.xxl?.height / 1600) * windowWidth , sizeMaps?.[animSize]?.lg?.height), sizeMaps?.[animSize]?.xxl?.height );
    if(!freewidth) {
      dimentions.width = Math.min(Math.max( (sizeMaps?.[animSize]?.xxl?.width / 1600) * windowWidth , sizeMaps?.[animSize]?.lg?.width), sizeMaps?.[animSize]?.xxl?.width );
    }
    if(windowWidth < 992) {
      // dimentions.width = 320;
      dimentions.height = sizeMaps?.[animSize]?.mob?.height;
      if(!freewidth) {
        dimentions.width = sizeMaps?.[animSize]?.mob?.width;
      }
    }
  }


  // switch (animSize) {
  //   case '640x800':
  //     // dimentions.width = Math.min(Math.max( (640 / 1600) * windowWidth , 492), 640 );
  //     dimentions.height = Math.min(Math.max( (800 / 1600) * windowWidth , 615), 800 );
      
  //     if(windowWidth < 992) {
  //       // dimentions.width = 320;
  //       dimentions.height = 400;
  //     }
  //     break;

  //   case '580x540':
  //     // dimentions.width = Math.min(Math.max( (580 / 1600) * windowWidth , 440), 580 );
  //     dimentions.height = Math.min(Math.max( (540 / 1600) * windowWidth , 410), 540 );
      
  //     if(windowWidth < 992) {
  //       // dimentions.width = 318;
  //       dimentions.height = 300;
  //     }
  //     break;

  //   case '630x500':
  //     // dimentions.width = Math.min(Math.max( (630 / 1600) * windowWidth , 484), 630 );
  //     dimentions.height = Math.min(Math.max( (500 / 1600) * windowWidth , 384), 500 );
      
  //     if(windowWidth < 992) {
  //       // dimentions.width = 330;
  //       dimentions.height = 340;
  //     }
  //     break;

  //   default:
  //     break;
  // }

  return dimentions;
}