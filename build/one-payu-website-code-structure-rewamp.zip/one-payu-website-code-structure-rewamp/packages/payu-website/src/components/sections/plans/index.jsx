import React, {  useRef, useEffect, useState, useLayoutEffect } from 'react'
import { connect, styled , Global, css} from 'frontity';
import {layout, SectionAnimation} from '../../../utils/constants';
import {useOnScreen, useWindowDimentions, useContainerDimensions, useType} from '../../../utils/hooks/usehooks'
import { Section, Container } from '../../misc/layout';
import { motion, useMotionValue, useAnimation } from "framer-motion";
import ThreadImage from './backgroundImage.png';


const BackgroundMediaAnimation = {
    hidden: { opacity: 0, scale: 1, y: 0 },
    show: {
        opacity: 1,
        scale: 1,
        y: 0
    },
    transition: (n, longDelay=false) => ({
        ease: 'anticipate',
        duration: longDelay ? 0.8 : 0.5, 
        delay: (longDelay ? 0.8 : 0.5)*(n) - 0.1*n, 
    })
}

const SectionWrapper = styled.div`
position: relative;
overflow-x: clip;

.section-container {
    ${layout.screen.mob} {
        padding-left: 0px;
        padding-right: 0px;
    }
}


.section-inner {
    .text-cards-container {
        display: flex;
        flex-direction: column;
        .texts {
            margin-bottom: 4rem;
            .texts-heading {
                color: #0E342C;
            }
            .texts-description {
                margin-top: ${layout.reponsiveCssValue(4, 19, 1200, 2, 1600, 19)};
            }

            ${layout.screen.mob} {
                padding-left: ${layout.constants.mobile_padding['level4'] || '0rem'};
                padding-right: ${layout.constants.mobile_padding['level4'] || '0rem'};

                margin-bottom: 3.5rem;
                
                .texts-heading {
                    margin: 0rem;
                }

                .texts-description {
                    margin-top: 1.5rem;
                }
            }
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(2, auto);
            grid-column-gap: ${layout.reponsiveCssValue( 44, 58,1200, 44, 1600, 58)};
            grid-row-gap: ${layout.reponsiveCssValue( 44, 58,1200, 44, 1600, 58)};

            ${layout.screen.mob} {
                grid-template-columns: repeat(1, auto);
                grid-column-gap: ${layout.reponsiveCssValue( 26, 44,375, 26, 1200, 44)};
                grid-row-gap: ${layout.reponsiveCssValue( 26, 44,375, 26, 1200, 44)};
            }
        }
    }
}

.thread-image {
    position: absolute;
    top: 0px;
    z-index: -1;
    ${layout.screen.mob} {
        display: none;
    }
}
`;

const SectionPlans = ({state, actions, data, libraries}) =>  {
    const ref = useRef(null)
    const [onScreen, portionInView, viewed] = useOnScreen(ref, "0px");
    const Html2React = libraries.html2react.Component;
    const deviceType = useType();

    useEffect(() => {
        actions.intraPageLinks.update(data?.section?.internalLink, portionInView);
        return () => {
            actions.intraPageLinks.update(data?.section?.internalLink, 0);
        }
    }, [portionInView])

    const [sectionHeight, setsectionHeight] = useState(0);

    const handleResize = () => {
        if(ref.current) {
            setsectionHeight(ref.current.offsetHeight)
        }
    }
    
    useEffect(() => {
        // console.log('data in Section Plans:', data);
        handleResize();
        window.addEventListener("resize", handleResize)
        window.addEventListener("orientationchange", handleResize)
        
        return () => {
        window.removeEventListener("resize", handleResize)
        window.removeEventListener("orientationchange", handleResize)
        }
    }, [])


    return (
        <>
            <SectionWrapper  id={data?.section?.internalLink} threadMaxHeight={sectionHeight}>
                <Section padding={'level4'} className='section-container'>
                    <motion.div 
                        className="section-inner"
                        ref={ref}
                        variants={SectionAnimation}
                        initial={'hidden'}
                        animate={viewed ? 'show' : 'hidden'}
                        transition={{
                            ...SectionAnimation.transition(0, true)
                        }}
                        onAnimationComplete={handleResize}
                    >
    
                        <div className="text-cards-container"> 
                            <div className="texts">
                                <h2 className={`${deviceType=='mobile'? 'h1':'h2'} texts-heading`}>{data.heading}</h2>
                                <p className={`${deviceType=='mobile'? 'body1':'body1'} texts-description`}>{data.description}</p>
                            </div>

                            <motion.div
                                className='cards'
                            >
                                 {data && data.card && data.card.map((elem, index) => (
                                            <>
                                                <Card index={index} data={elem} viewed={viewed} variant={ index%2 == 0 ? "dark" : "light"} deviceType={deviceType}/>
                                            </>
                                        )
                                    )
                                 }
                            </motion.div>
                        </div>

                    </motion.div>
                </Section>

                <motion.div 
                    className="thread-image"
                    variants={BackgroundMediaAnimation}
                    initial={'hidden'}
                    animate={viewed ? 'show' : 'hidden'}
                    transition={{
                        ...BackgroundMediaAnimation.transition(1)
                    }}
                >
                    <img src={ThreadImage} />
                </motion.div>

            </SectionWrapper>
        </>
    )
}

export default connect(SectionPlans)


const CardsAnimation = {
    show : {
        opacity: 1.1,
        y: 0,
        scale: 1,
      },
      hidden: {
        opacity: 0,
        y: 60
      },
      hover: {
        opacity: 1.1,
        y: -8,
        transition: { duration: 0.2, delay: 0 }
      },
}

const CardWrapper = styled.div`

    .card {
        background: rgba(255, 255, 255, 0.4);
        border: 2px solid rgba(255, 255, 255, 0.72);
        box-sizing: border-box;
        backdrop-filter: blur(9px);
        border-radius: ${layout.reponsiveCssValue(19, 26, 1200, 19, 1600, 28)};
        margin-top: ${layout.reponsiveCssValue( 60, 80,1200, 60, 1600, 80)};

        ${layout.screen.mob} {
            margin-top: 0px;
            border-radius: 28px;
        }

        &.light {
        background: #ffffff;
        margin-top: 0px;
        }
    }

    .card-texts {
        display: flex;
        flex-direction: column;
        flex-grow: 1;
        position:relative;
        padding-top: ${layout.reponsiveCssValue(32, 44, 1200, 32, 1600, 44)};
        padding-bottom: ${layout.reponsiveCssValue(32, 44, 1200, 32, 1600, 44)};
        padding-left: ${layout.reponsiveCssValue(35, 48, 1200, 35, 1600, 48)};
        padding-right: ${layout.reponsiveCssValue(35, 48, 1200, 35, 1600, 48)};

        .card-heading {
            color: #0E342C;
        }
        .card-description {
            color: #2F695D;
            margin-top: 47px;
        }

        .price {
            margin-top: 6.9px;
            
            .main  {
                color: #0E342C;
                ${layout.screen.mob} {
                    font-family: 'Roboto Slab';
                    font-style: normal;
                    font-weight: 500;
                    font-size: 44px;
                    line-height: 159%
                }
            }
            .subtext {
                color: #96A5A2;
                margin-left: 8px;

                ${layout.screen.mob} {
                    display: block;
                    margin-left: 28px;
                }
            }
        }

        .link-wrapper {
            width: fit-content;
        }
      }

`;
const Card = (props) => {
const [animationCompleted, setanimationCompleted] = useState(false)
    return(
        <CardWrapper>
        <motion.div
            whileHover={'hover'}
            variants={CardsAnimation}
            className={`card ${props.variant}`}
            initial={'hidden'}
            animate={props.viewed ? 'show' : 'hidden'}
            transition={
                animationCompleted ? 
                {
                    transition: { duration: 0.2, delay: 0 }
                }
                : {
                    ...SectionAnimation.transition(props.index+1, false)
                }
            }
            onAnimationComplete={()=>setanimationCompleted(true)}
            >
            <div className="card-texts">
                <h4 className={`${props.deviceType=='mobile'? 'h3':'h4'} card-heading`}>{props.data?.heading}</h4>
                <p className={`${props.deviceType=='mobile'? 'body2':'body1'} card-description`}>{props.data?.description}</p>
                <div className='price'>
                    <span className='h1 main'>{props.data?.price?.main}</span>
                    <span className={`${props.deviceType=='mobile'? 'body3':'small-text1 semibold '} subtext`}>{props.data?.price?.subtext}</span>
                </div>

                <div className ='list'>
                    <List data={props.data?.list}/>
                </div>
                
                {
                    props.data?.button?.title && 
                    <motion.a
                    className="link-wrapper"
                    href={props.data?.button?.link || 'javascript::void(0)'}
                    whileHover={{
                        scale: 1.02,
                        transition: { ease: 'anticipate', duration: 0.200 },
                    }}
                    whileTap={{ scale: 0.98 }}
                >
                    <p className="button2">{props.data?.button?.title}</p>
                </motion.a>
                }
            </div>
        </motion.div>
        </CardWrapper>
    )
}

const StyledList = styled.ul`
margin-top: ${layout.reponsiveCssValue(36, 45, 1200, 45, 1600, 36)};
margin-bottom: ${layout.reponsiveCssValue(36, 45, 1200, 45, 1600, 36)};
li {
    display: flex;
    .list-style-icon {
        width: 28.17px;
        height: 28.17px;
        border-radius: 50%;
        background: #EAEFEC;
        display: flex;
    }
    .h7 {
        margin-left: 18.79px;
        display: flex;
        flex: 1;
    }
    .h7 {
        color: #2F695D;
    }


    &:not(:last-child) {
        margin-bottom: ${layout.reponsiveCssValue(21.54, 24, 1200, 24, 1600, 21.54)};
    }

}


`;

const List = (props) => {

    return(
        <StyledList>
            {
                props.data && props.data.map((elem, index)=>(
                    <li>
                        <span className='list-style-icon'></span><span className="h7">{elem?.title}</span>
                    </li>
                ))
            }
        </StyledList>
    )
}