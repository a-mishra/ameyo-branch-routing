import React, {  useRef, useEffect, useState, useLayoutEffect, forwardRef, useImperativeHandle } from 'react'
import { connect, styled } from 'frontity';
import IconTitleCard from './iconTitleCard'
import LottieAnimation from '../../misc/widget/lottie/lottie';
import { useInterval } from "usehooks-ts";
import ParallaxItem from '../parallax-item';
import {layout} from '../../../utils/constants';
import {useOnScreen, useWindowDimentions} from '../../../utils/hooks/usehooks'
import {
  useViewportScroll,
  useTransform,
  useSpring,
  motion,
  AnimatePresence,
  useAnimation
} from "framer-motion";
import SequenceReveal from '../sequence-reveal'
import {ParallaxBox} from '../parallax-box'

import Slider from "react-slick";
import SlickCSS from "slick-carousel/slick/slick.css";
import SlickTheme from "slick-carousel/slick/slick-theme.css";

import chalk from 'chalk';
import logSymbols from 'log-symbols';

import { Container, Row, Col, Section, MobileOnly, BelowLargeScreen } from "../../misc/layout";


const SectionProductFeatures = ({state, actions, data, libraries}) =>  {

    const [count, setCount] = useState(1);
    const [delay, setDelay] = useState(data?.cards?.settings && data?.cards?.settings?.cardSwitchInterval ? Number(data?.cards?.settings?.cardSwitchInterval)*1000 :  10000 );
    const [isPlaying, setPlaying] = useState(true);

    const ref = useRef(null)
    const [onScreen, portionInView] = useOnScreen(ref, "0px");

    useEffect(() => {
        actions.intraPageLinks.update(data?.section?.internalLink, portionInView);
        return () => {
            actions.intraPageLinks.update(data?.section?.internalLink, 0);
        }
    }, [portionInView])

    useEffect(() => {
        console.log(`Product Features`,data)
    }, [])

    const windowDimentions = useWindowDimentions();

    const animationFixedHeightContainer = useRef(null);

    useInterval(
        () => {
            let range = data?.cards?.data && data?.cards?.data.length;
            if(range)
            setCount((count % range) + 1);
        },
        // Delay in milliseconds or null to stop it
        isPlaying ? delay : null
    );

    const handleIconCardSelection = (index) => {
        setCount(index+1)
    }

    const Html2React = libraries.html2react.Component;

    const [animLoaded, setanimLoaded] = useState(false);
    const handleAnimationLoaded = (isLoaded=true) => {
        setanimLoaded(isLoaded)
        // console.log(chalk`
        // ${logSymbols.success} {green.bold Animation Loaded}
        // `);
        animationFixedHeightContainer && animationFixedHeightContainer.current.getChildHeight();
    }

    useEffect(() => {
        setanimLoaded(false)
    }, [count])

    const sliderMobileSettings = {
        className: "center",
        centerMode: true,
        infinite: true,
        // centerPadding: "1.2rem",
        slidesToShow: 1,
        speed: 500,
        swipeToSlide: true,
        nextArrow: <></>,
        prevArrow: <></>
      };

      const settings = {
        className: "center",
        centerMode: true,
        infinite: true,
        centerPadding: "60px",
        slidesToShow: 3,
        speed: 500
      };

    return (
    <StyledSection ref={ref}>
        <ParallaxBox fadeOut={false} easing={'easeInOut'}>
            <SequenceReveal sequence={0} inView={onScreen}>
                <Container padding={'level4'} debug={layout.constants.debug}>
                    <Row gap={'1rem'}>
                        <Col xs={12} sm={12} md={12} lg={6} xl={6} xxl={6} centered={true} >
                            <ParallaxItem>
                                <HeadingWrapper>
                                    <SequenceReveal sequence={1} inView={onScreen}>
                                        <h1>{<Html2React html={data?.heading} />}</h1>
                                    </SequenceReveal>
                                    <SequenceReveal sequence={1} inView={onScreen}>
                                        <p>{<Html2React html={data?.subheading} />}</p>
                                    </SequenceReveal>
                                    
                                    <SequenceReveal sequence={2} inView={onScreen}>
                                        <StyledRow>
                                        {
                                            data && data.cards && data.cards.data &&data.cards.data.map((elem, index)=>(
                                                <Col><IconTitleCard title={elem?.title}  icon={elem.icon} onClick={()=>{handleIconCardSelection(index)}} url={elem.url} isActive={count-1 == index? true: false}/></Col>
                                            ))
                                        }
                                        </StyledRow>
                                    </SequenceReveal>
                                    
                                </HeadingWrapper>
                            </ParallaxItem>
                        </Col>
                        {/* animation container */}
                        <Col xs={12} sm={12} md={12} lg={6} xl={6} xxl={6} centered={true}>
                        <HoldHeight ref={animationFixedHeightContainer}>
                            <SequenceReveal sequence={3} inView={onScreen}>
                                <AnimatePresence exitBeforeEnter>
                                
                                    <motion.div
                                        key={count}
                                        animate={{ opacity: 1, y: -30 }}
                                        initial={{ opacity: 0, y: 0 }}
                                        exit={{ opacity: 0, y: 30 }}
                                        transition={{ duration: 0.8 }}
                                        // initial={{ opacity: 0 }}
                                        // whileInView={{ opacity: 1 }}
                                        // viewport={{ once: true }}
                                    >
                                        {
                                            data?.cards?.data && data?.cards?.data.length > 0 && data?.cards?.data[count-1]?.lottie?.media?.id && 
                                            <AnimationWrapper>
                                                <LottieAnimation 
                                                    lottie={data.cards.data[count-1].lottie.media.url} 
                                                    loopStartFrame={data.cards.data[count-1].lottie.settings.loopStartFrame} 
                                                    onHover={false} 
                                                    autoPlay={true} 
                                                    autoPlayLoop={true}
                                                    unInterruptedPlay={false}
                                                    height={windowDimentions.width > layout.breakpoints.b5 ? "667px" : "auto"} 
                                                    // width={"600px"} 
                                                    onScreenOffset={"-200px"}
                                                    debug={false}
                                                    onLoad={handleAnimationLoaded}
                                                    childComponent = {
                                                        <>
                                                            <AnimationTextWrapper>
                                                                <h3>
                                                                    {/* {<Html2React html={data?.cards?.data[count-1]?.animationTextHeading} />} */}
                                                                    {data?.cards?.data[count-1]?.animationTextHeading}
                                                                </h3>
                                                                <p>
                                                                    {/* {<Html2React html={data?.cards?.data[count-1]?.animationSubTextHeading} />} */}
                                                                    {data?.cards?.data[count-1]?.animationTextSubHeading}
                                                                </p>
                                                            </AnimationTextWrapper>
                                                        </>
                                                    }
                                                />
                                                
                                            </AnimationWrapper>
                                        }
                                    </motion.div>

                                </AnimatePresence>
                            </SequenceReveal>
                        </HoldHeight>

                        </Col>
                    </Row>
                    <StyledBelowLargeScreen>
                        <Slider {...sliderMobileSettings}>
                        {
                            data && data.cards && data.cards.data &&data.cards.data.map((elem, index)=>(
                                <IconTitleCard title={elem?.title}  icon={elem.icon} url={elem.url} isActive={count-1 == index? true: false}/>
                            ))
                        }
                        </Slider>

                    </StyledBelowLargeScreen>
                </Container>
            </SequenceReveal>
        </ParallaxBox>
    </StyledSection>
    )

}

export default connect(SectionProductFeatures)

const StyledSection = styled(Section)`
    margin-top: 7rem;
    padding-bottom: 2rem;
`;
const StyledRow = styled(Row)`
    ${layout.screen.xs} {
        display: none
    }

    ${layout.screen.sm} {
        display: none;
    }

    ${layout.screen.lg} {
        display: grid;
        grid-template-columns: 1fr;
        gap: 8px;
        margin-top: 36px;
    }

    ${layout.screen.xl} {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 36px;
        margin-top: 74px;
    }
`;

const StyledBelowLargeScreen = styled(BelowLargeScreen)`
    margin-top: 72px;

    .slick-slide {
        width: fit-content !important;
        margin: 0 1rem !important;
    }
`;

const HeadingWrapper = styled.div`
    padding-top: 64px;
`;


const AnimationWrapper = styled.div`
    position: relative;
    z-index: 10;
    display: flex;
    height: 100%;
    justify-content: center;
    align-items: center;

    ${layout.screen.xs} {
        margin-top: 0px;
    }
    ${layout.screen.sm} {
        margin-top: 0px;
    }
    ${layout.screen.lg} {
        margin-top: 0px;
    }
`;

const AnimationTextWrapper = styled.div`
    z-index: 20;
    width: 80%;
    padding: 4px 16px;
`;



export const HoldHeight = forwardRef((props, ref) => {
    const {children} = props;
    const wrapper = useRef(null);
    const [containerHeight, setcontainerHeight] = useState('auto');

    useImperativeHandle(ref, () => ({

        getChildHeight() {
            // console.log('getChildHeight called')

            if(wrapper) {
                // console.log(logSymbols.info, chalk`{bold height:${wrapper.current.offsetHeight}}`)
                // console.log(wrapper.current);
                setcontainerHeight(`${wrapper.current.offsetHeight}px`)
            }
        }
    
      }));


    return(
        <div ref={wrapper} style={{height: containerHeight}}>
        {children}
        </div>
    )
})


