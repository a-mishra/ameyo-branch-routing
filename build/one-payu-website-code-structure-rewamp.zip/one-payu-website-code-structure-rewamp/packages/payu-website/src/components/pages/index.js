import React, {useEffect} from "react";
import { styled, connect } from "frontity";
import Loading from "./misc/loading";
import Page from "./page";
import VerticalNav from '../navigation/verticalNav'
import {getPostToRender} from '../../utils/methods'

const Pages = ({ state, actions, libraries }) => {

  useEffect(() => {
    actions.source.fetch(getPostToRender(state.router.link));
  }, []);


  const data = state.source.get(getPostToRender(state.router.link));


  if(data.isReady) {
    const meta = state?.source?.page[data.id]?.meta;
    return (
      <Container id={"top"}>
        {meta && meta["internal-link-checkbox"] && <VerticalNav />}
        <Page  data={data}/>
      </Container>
    );
  } else {
    // if is404 : return not found
    // if isReady false return loading
    return (
      <>
        {/* <Loading /> */}
      </>
    )
  }
};

export default connect(Pages);

export const Container = styled.div`
  width: 100%;
  flex-grow: 1;

  max-width: 1600px;
  margin-left: auto;
  margin-right: auto;
  position: relative;
`;
