import React, {useRef, useState, useEffect} from 'react';
import { Player, Controls } from '@lottiefiles/react-lottie-player';
import { useCounter, useHover } from 'usehooks-ts' 
import { useOnScreen, useLottieContainerDimensions } from '../../../utils/hooks/usehooks'; 
import {styled} from 'frontity'
import { getDataFromNetworkOrLocalStorage } from '../../../utils/methods';
import { useInterval, useTimeout } from "usehooks-ts";

const Animation = ({lottie, markedFrames, setpage,resetpage, next, page, inView, onLoad, height, width , manuallySelectedPage}) => {

    const player = useRef();
    const playerWrapper = useRef();

    const { count, setCount, increment, decrement, reset } = useCounter(0);
    const [animationDirection, setanimationDirection] = useState(1);
    const [animationState, setanimationState] = useState('');
    const [isLoaded, setisLoaded] = useState(false);
    const playerDimentions = useLottieContainerDimensions(playerWrapper, isLoaded);

    const fps = 60;
    // window.mytimer = null;
    const timeToNextCard = markedFrames.map((value, index, elements)=>{
        if(elements[index+1]) {
            return (  Math.floor(((elements[index+1] - value )/ fps)*1000)  );  //ms to next part of animation
        }
        else return -1;
    });

    const handleAnimationLoaded = () => {
        setisLoaded(true);
        onLoad();
    }

    

    const onEvent = (event) => {
        // take actions for events
        switch(event) {
            case "load": 
                handleAnimationLoaded();
                break;

            case "play": 
                player?.current.setSeeker( 0 , true);
                break;

            case "frame":
                animationDirection ? increment() : decrement();
                break;

            default :
                if(['loop', 'stop', 'complete'].includes(event)) {
                    resetAnimation();
                    resetpage();
                }
                break;
        }

        // update animation state
        if(['load', 'error', 'ready', 'play', 'pause', 'stop', 'freeze', 'complete'].includes(event))
            setanimationState(event);
    }


    const resetAnimation = () => {
        player?.current.setSeeker( 0, true );
        setCount(0 );
    }

    const startAnimationFromFrame = (frameId) => {
        setCount(frameId);
        player?.current.setSeeker(frameId, true );
    }


    // useEffect(() => {

    //     startAnimationFromFrame(markedFrames[page]);

    //     return(()=>{
    //     })
    // }, [page])

    // useEffect(() => {
    //     if(inView) {
    //         startAnimationFromFrame(markedFrames[page]);
    //         clearTimeout(window.mytimer);
    //         if(timeToNextCard[manuallySelectedPage] > 0) {
    //             window.mytimer = setTimeout(() => {
    //                 next();
    //                 setnextPageandTimer();
    //             }, timeToNextCard[manuallySelectedPage]);
    //         }
    //     }
    // }, [inView])
    

    useEffect(() => {

        if(page == 0) {
            startAnimationFromFrame(markedFrames[page]);
            clearTimeout(window.mytimer);
            startAnimationFromFrame(markedFrames[manuallySelectedPage]);
            if(inView) {
                if(timeToNextCard[manuallySelectedPage] > 0) {
                    window.mytimer = setTimeout(() => {
                        next();
                        setnextPageandTimer();
                    }, timeToNextCard[manuallySelectedPage]);
                }
            }
        }

        return(()=>{
        })
    }, [page])

    useEffect(() => {

            clearTimeout(window.mytimer);
            startAnimationFromFrame(markedFrames[manuallySelectedPage]);
            // setnextPageandTimer();
            if(inView) {
                if(timeToNextCard[manuallySelectedPage] > 0) {
                    window.mytimer = setTimeout(() => {
                        next();
                        setnextPageandTimer();
                    }, timeToNextCard[manuallySelectedPage]);
                }
            }

        return(()=>{
        })
    }, [manuallySelectedPage])



    
    const setnextPageandTimer = () => {
        if(inView) {
            clearTimeout(window.mytimer);
            if(timeToNextCard[page] > 0) {
                window.mytimer = setTimeout(() => {
                    next();
                    setnextPageandTimer();
                }, timeToNextCard[page]);
            }
        }

    }

    const setPlayback = (flag) => {
        if(flag) {
            player?.current.setSeeker( markedFrames[page] , false);
            player?.current.play();
            setnextPageandTimer();
        } else {
            player?.current.pause();
            player?.current.setSeeker( markedFrames[page] , false);
        }
    }


    // useEffect(() => {
    //     setPlayback(startFromFrame) // hover off karne par animation pause ho jayega, agar shouldPlay false hai to || Agar shouldPlay true hai to hover off ka koi effect nahi aayega.
    // }, [startFromFrame])

    useEffect(() => {
        if(inView === true && isLoaded)
            setPlayback(true)
        else if(inView === false) {
            // do nothing
            // setPlayback(false)
            clearTimeout(window.mytimer);
        }
    }, [inView, isLoaded])

    // const [lottieSrc, setlottieSrc] = useState(null)
    // useEffect(() => {
    //     // setlottieSrc(getDataFromNetworkOrLocalStorage(lottie?.media?.url));
    // }, [])

    return (
        <div>
            <div ref={playerWrapper}>
                <Player
                    onEvent={onEvent}
                    ref={player}
                    autoplay={true}
                    loop={true}
                    src= {lottie?.media?.url}
                    style={{ 
                        // // height: 'auto', 
                        // height: height,
                        // width:  'auto', 
                        // // width: width && width-16 || 'auto', 
                        // maxHeight: height, 
                        // maxWidth: width && width-8

                        height:  height || 'auto',
                        width:  width || 'auto', 
                        maxHeight: '100%', 
                        maxWidth: 640,
                        overflow: 'visible'
                    }}
                    hover={false}
                    renderer="svg"
                    className="lottie-animation"
                    keepLastFrame={true}
                    rendererSettings={{
                        preserveAspectRatio: 'xMidYMid meet', // Supports the same options as the svg element's preserveAspectRatio property
                        clearCanvas: false,
                        // className: 'some-css-class-name',
                        // id: 'some-id',
                        viewBoxOnly: true
                      }}
                >
                    {/* <Controls
                        transparentTheme={true}
                        showLabels={true}
                        visible={true}
                        buttons={['play', 'repeat', 'frame', 'debug', 'snapshot', 'background', 'stop']}
                    /> */}
                </Player>
                
            </div>
            
              {
                //   isLoaded && <FauxShadowContainer width={playerDimentions && playerDimentions.svgWidth || 0}/>
              }
            
        </div>
    );
}

export default Animation;
