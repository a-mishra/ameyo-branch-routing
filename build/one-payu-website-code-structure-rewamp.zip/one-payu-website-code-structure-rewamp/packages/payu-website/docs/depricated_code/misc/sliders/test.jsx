import React, {useRef} from 'react'
import { layout } from '../../../utils/constants';
import {
    motion,
    useSpring
  } from "framer-motion";
  import {styled, connect} from 'frontity';

const Wrapper = styled.div`
    .vertical-nav-scroll {
        position: fixed;
        // top: ${layout.constants.headerHeight};
        top: 0px;
        bottom:0px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        gap: 3rem;
        margin-left: ${layout.constants.padding.level1};
        z-index: 10;
    }
`;


function TestSwiper({data}) {

    React.useEffect(()=>{
        // console.log(`data in gettingStarted Test Slider:`, data);
    }, [])
 
    const activeSlideIndex = 0;

    return (
        <div>
            {
                // data && data.cards && data.cards.map((elem, index)=>(
                //     <div className="swiper-card-wrapper" key={index}>
                //         <div className={`swiper-card ${activeSlideIndex == index ? 'active' : ''}`}>
                //             <img src={elem?.image?.url} />
                //             <div className="text-container">
                //                 <h4>{elem.heading}</h4>
                //                 <p>{elem.description}</p>
                //                 {elem.buttons && elem.buttons.length > 0 ? <Buttons buttons={elem.buttons}/> : <></>}
                //             </div>
                //         </div>
                //     </div>
                // ))
            }


        </div>
    )
}

export default TestSwiper
