import React, {  useRef, useEffect, useState, useLayoutEffect } from 'react'
import { connect, styled , Global, css} from 'frontity';
import {layout} from '../../../utils/constants';
import {useOnScreen, useWindowDimentions} from '../../../utils/hooks/usehooks'
import SequenceReveal from '../sequence-reveal'
import {ParallaxBox} from '../parallax-box'
import { Container, Section } from '../../misc/layout';
import ThreadImage from '../../../assets/images/thread.svg'
import LottieAnimation from '../../misc/widget/lottie/lottie';


const SectionWrapper = styled.div`
    position: relative;
    overflow-x: clip;

    .section-inner {
        display: flex;
        flex-direction: column;

        .text-and-card-container {
            height: calc( max(100vh - ${layout.constants.headerHeight}, 500px) );
            display: grid;
            grid-template-columns: repeat(12, 1fr);
            grid-auto-flow: row;
            gap: 2rem;
            position: relative;
            

            .animation-container {
                position: absolute;
                height: 100%;
                width: 100%;
                display: flex;
                justify-content: center;
                flex-direction: row;

                .media-wrapper {
                    height: 100%;
                    width: 33%;
                    display: flex;
                    align-content: center;
                    .margin-taker {
                        display: flex;
                        align-items: center;
                        margin-bottom: ${layout.constants.headerHeight};
                        padding-bottom: ${layout.constants.headerHeight};
                    }
                }

            }
            
            .text-container-maintext {
                grid-column:span 6;

                padding-bottom: ${layout.constants.headerHeight};
                margin-bottom: 0px;

                display: flex;
                flex:1;
                flex-direction: column;
                align-items: flex-start;
                justify-content: center;
                
                h1 {
                    max-width: min(550px, 100%);
                    margin-top: 0px;
                }
                
                p {
                    max-width: 384px;
                }

                .button-container {
                    margin-top: 1.8rem;
                }

            }

            .text-container-maintext.hero {
                margin-bottom: ${layout.constants.headerHeight};
                h1 {
                    max-width: 384px;
                }
                
            }

            .card-container {
                grid-column: span 6;
                display: flex;
                align-items: flex-end;
                justify-content: flex-end;
                flex:1;

                .flashcards-wrapper {
                    max-width: 320px;
                    display: flex;
                    flex-direction: column;
                    flex:1;
                    margin-bottom: 5rem;
                    h5 {
                        margin-bottom: 1.5rem;
                        color: #314235;
                    }
                    .flashcards-cards-container {
                        display: flex;
                        gap: 2rem;
                        flex-direction: column;
                    }
                    .flashcard-button-container {
                        margin-top: 1.8rem;
                    }
                }
            }

            .non-hero-media-container {
                grid-column: span 6;
                display: flex;
                align-items: center;
                justify-content: flex-end;
                flex:1;
                
            }
        }


        .icon-container {
            flex-grow: 0;
            width: 100%;
            margin: 0px auto;
            display: flex;
            align-items: center;
            justify-content: center;
            padding-top: 1rem;
        }
    }



    .background-media {
        position: absolute;
        height: calc( 100% - 2*${layout.constants.headerHeight});
        width: 100%;
        top: 0px;
        left: 0px;
        z-index: -2;
        display:none;
    }

`;



const SectionHero = ({state, actions, data, libraries}) =>  {

    const ref = useRef(null)
    const [onScreen, portionInView] = useOnScreen(ref, "0px");

    useEffect(() => {
        actions.intraPageLinks.update(data?.section?.internalLink, portionInView);
        return () => {
            actions.intraPageLinks.update(data?.section?.internalLink, 0);
        }
    }, [portionInView])
    
    const windowDimentions = useWindowDimentions();


    const Html2React = libraries.html2react.Component;
    const isHero = (data?.flashCards?.heading || (data?.flashCards?.cards && data?.flashCards?.cards.length > 0) )

    return (
    <>
    <SectionWrapper ref={ref}>
        <ParallaxBox fadeOut={false} easing={'backInOut'}>
            <SequenceReveal sequence={0} inView={onScreen}>
                <Container padding={'level4'} debug={layout.constants.debug}>
                        <div class="section-inner">
                            <div className="text-and-card-container">

                                {
                                  isHero && <div className="animation-container">
                                        <div className="media-wrapper">
                                            <div class="margin-taker">
                                                <MediaPlayer data={data?.media?.type?.value && data?.media?.data && data?.media?.data[data?.media?.type?.value]} mediaType={data?.media?.type?.value}/>
                                            </div>
                                        </div>
                                    </div> 
                                }

                                <div class={`text-container-maintext ${isHero && 'hero'}`}>
                                    <p className="hero-product-name">{<Html2React html={data?.productName || 'Payment links'} />}</p>
                                    <h1>
                                        {<Html2React html={data?.heading} />}
                                    </h1>
                                    <p class="">
                                        {<Html2React html={data?.description} />}
                                    </p>
                                    <div class="button-container">
                                        <Buttons buttons={data?.buttons}/>
                                    </div>
                                </div>
                                {
                                   isHero ?
                                        <div className="card-container">
                                            <div className="flashcards-wrapper">
                                                <h5>
                                                    {<Html2React html={data?.flashCards?.heading} />}
                                                </h5>
                                                <div className="flashcards-cards-container">
                                                    {
                                                        data?.flashCards?.cards && data?.flashCards?.cards.map((elem, index)=>(
                                                            <FlashCard image={elem?.image} title={elem?.heading} description={elem?.description} link={elem?.link}/>
                                                        ))
                                                    }
                                                </div>
                                                <div class="flashcard-button-container">
                                                    <Buttons buttons={[data?.flashCards?.button]}/>
                                                </div>
                                            </div>
                                        </div>
                                    :
                                        <div class="non-hero-media-container">
                                            <MediaPlayer data={data?.media?.type?.value && data?.media?.data && data?.media?.data[data?.media?.type?.value]} mediaType={data?.media?.type?.value}/>
                                        </div>
                                }
                                
                            </div>
                            
                            {
                                data && data.logo && data.logo.length > 0 && 
                                <div class="icon-container">
                                    <Icons icons={data?.logo}/>
                                </div>
                            }
                        </div>
                        
                </Container>
            </SequenceReveal>
        </ParallaxBox>
        <div className="background-media">
            <MediaPlayer data={data?.section?.background?.type?.value && data?.section?.background?.data && data?.section?.background?.data[data?.section?.background?.type?.value]} mediaType={data?.section?.background?.type?.value}/>
        </div>
    </SectionWrapper>
    </>
    )

}

export default connect(SectionHero)




// Start : Icons component

const IconsWrapper = styled.div`
display: flex;
justify-content: center;
align-items: center;

`;

const Logo = styled.div`
    max-height: 1.6rem;
    margin: 0px 1.5rem;
`;


const Icons = ({icons}) => {
    return (
        <IconsWrapper>
            {icons && icons.map((elem)=>{
                return(
                    <Logo>
                        <img src={elem?.image?.url} alt={elem?.image?.name}/>
                    </Logo>
                )
                
            })}
        </IconsWrapper>
    )
}

// End : Icons component




// Start : Buttons component

const ButtonsWrapper = styled.div`
    display: flex;
    justify-content: start;
    align-items: center;

    .button {
        cursor: pointer;
        margin-right: 12px;
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        padding: 13.2374px 26.4748px;
        border-radius: 13.2374px;

        h6 {
            font-family: Roboto Slab;
            font-style: normal;
            line-height: 22px;
            font-weight: 500;
        }
    }

    .button.dark {
        background: #00AB88;
        h6 {
            color: #FFFFFF;
        }
    }

    .button.light {
        background: #ffffff;
        h6 {
            color: #2F695D;
        }
    }


    .button.transparent {
        background: transparent;
        h6 {
            color: #2F695D;
        }
    }


    .button.translucent {
        background: rgba(255, 255, 255, 0.4);
        border: 1.65467px solid rgba(255, 255, 255, 0.72);
        box-sizing: border-box;
        backdrop-filter: blur(3.30935px);
        border-radius: 9.92803px;
        padding: 9.92803px 16.5467px;
        h6 {
            color: #00AB88;
        }
    }

`;


const Buttons = ({buttons}) => {
    return (
        <ButtonsWrapper>
            {buttons && buttons.map((elem, index)=>{
                return(
                    <div className={`button ${elem?.type?.value}`}>
                        <h6>{elem.title}</h6>
                    </div>
                )
                
            })}
        </ButtonsWrapper>
    )
}

// End : Buttons component


// Start : FlashCard component

const FlashCardWrapper = styled.div`
    display: flex;
    flex-direction: row;

    .image-container-flashcards {
        height: 100%;
        border-radius: 12px;
        display: flex;
        align-items: baseline;
        img {
            height: auto;
            width: 79.41px;
        }
    }

    .text-container-flashcards {
        min-width: 150px;
        margin-left: 18px;
        h6 {
            font-size: 10.7554px;
            line-height: 17px;
            letter-spacing: 0.827336px;
            color: #314235;
        }
        p.small {
            color: #2F695D;
            margin-top: 8px;
            margin-bottom: 0rem;
        }

    }
`;

export const FlashCard = ({image, title, description, link }) => {

    return (
        <FlashCardWrapper>
            <div className="image-container-flashcards">
                {image?.url && <img src={image.url}/>}
            </div>
            <div className="text-container-flashcards">
                <h6>{title}</h6>
                <p className="small">{description}</p>
            </div>
        </FlashCardWrapper>
    )
}

// End : FlashCard component



export const MediaPlayer = ({mediaType, data}) => {

    if(mediaType == 'animation')
        return(
            <div class={`media-${mediaType}`}> 
                <LottieAnimation 
                    lottie={data?.media?.url} 
                    loopStartFrame={data?.settings?.loopStartFrame || 1} 
                    onHover={false} 
                    autoPlay={true} 
                    autoPlayLoop={true}
                    unInterruptedPlay={false}
                    // height={windowDimentions.width > layout.breakpoints.b5 ? "667px" : "auto"} 
                    // height={'400px'}
                    // width={"600px"} 
                    onScreenOffset={"0px"}
                    debug={false}
                    onLoad={()=>{}}
                    shadow={false}
                />
            </div>
        );
    
    if(mediaType == 'image')
        return(
            <div class={`media-${mediaType}`}> 
                <img src={data?.url} />
            </div>
        )
    
    return(
        <></>
    )
}