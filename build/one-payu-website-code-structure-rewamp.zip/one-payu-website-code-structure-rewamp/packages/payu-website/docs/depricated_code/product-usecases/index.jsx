import React, {  useRef, useEffect, useState, useLayoutEffect } from 'react'
import { connect, styled , Global, css} from 'frontity';
import {layout} from '../../../utils/constants';
import {useOnScreen, useWindowDimentions} from '../../../utils/hooks/usehooks'
import SequenceReveal from '../sequence-reveal'
import {ParallaxBox} from '../parallax-box'
import { Container, Section } from '../../misc/layout';


const ButtonWrapper = styled.div`
    display: grid;
    grid-gap: 36px;
    grid-template-columns: 1fr 1fr;
    margin-top: 74px;

    @media only screen and (max-width: 1200px) and (min-width: 768px) {
        grid-template-columns: 1fr;
        margin-top: 0px;
        grid-gap: 0px;
    }


`;

const SectionWrapper = styled.div`
    .bl-bx {
        // padding-top: 64px;
        max-width: 453px;

        h3 {
            /* Hero Text */

            font-family: Roboto Slab;
            font-style: normal;
            font-weight: 500;
            font-size: 44px;
            line-height: 70px;
            /* or 159% */
            
            
            color: #141416;
        }

        p {
            font-family: SF Pro Display;
            font-style: normal;
            font-weight: normal;
            font-size: 16px;
            line-height: 26px;
            /* or 162% */
            
            letter-spacing: 1px;
            
            /* Text 2 */
            
            color: #314235;

        }
    }


    min-height: 300px;

`;

const SectionProductUsecases = ({state, actions, data, libraries}) =>  {

    const ref = useRef(null)
    const [onScreen, portionInView] = useOnScreen(ref, "0px");

    useEffect(() => {
        actions.intraPageLinks.update(data?.section?.internalLink, portionInView);
        return () => {
            actions.intraPageLinks.update(data?.section?.internalLink, 0);
        }
    }, [portionInView])

    const windowDimentions = useWindowDimentions();


    const Html2React = libraries.html2react.Component;


    return (
    <>
    <SectionWrapper ref={ref}>
        <ParallaxBox fadeOut={false} easing={'backInOut'}>
            <SequenceReveal sequence={0} inView={onScreen}>
                <StyledSection>
                    <Container>
                        <div class="container">
                            <div class="row main-section">

                                {/* heading and subheading */}
                                <div class="col-lg-12">
                                        <div class="bl-bx">
                                            <SequenceReveal sequence={1} inView={onScreen}>
                                                <h3 class="coms-title">{<Html2React html={data?.heading} />}</h3>
                                            </SequenceReveal>
                                            <SequenceReveal sequence={2} inView={onScreen}>
                                                <p class="coms-subtitle">{<Html2React html={data?.subheading} />}</p>
                                            </SequenceReveal>
                                            <Buttons buttons={data?.buttons}/>
                                        </div>
                                </div>
                                <WhatsNewSection cards={data?.cards}/>
                            </div>
                            <div class="row">
                                <Icons icons={data?.icons}/>
                            </div>
                        </div>

                        
                    </Container>
                </StyledSection>
            </SequenceReveal>
        </ParallaxBox>
    </SectionWrapper>
    </>
    )

}

export default connect(SectionProductUsecases)


const StyledSection = styled(Section)`

    margin-top: 0rem;

    .main-section {
        position: relative;
        min-height: calc( 100vh - 148px );
    }

    .coms-title {
        font-size: 2.25rem;
        line-height: 3.625rem;
        color:  #0E342C;
        font-family: 'Roboto Slab';
        margin-bottom: 24px;
        
        font-family: Roboto Slab;
        font-style: normal;
        font-weight: 500;
        font-size: 23.1654px;
        line-height: 36px;
        color: #141416;
        

        .cs-hgl-text {
            color: #2F695D;
        }
    }
    
    .coms-subtitle {
        font-family: SF Pro Display;
        font-style: normal;
        font-weight: 400;
        font-size: 1rem;
        line-height: 1.625rem;
        letter-spacing: 0.827336311340332px;
        color:  #314235;

        font-family: SF Pro Display;
        font-size: 17px;
        font-style: normal;
        font-weight: 400;
        line-height: 26px;
        letter-spacing: 0.827336311340332px;
        text-align: left;

    }

    ${layout.screen.mobile} {
        padding: 7.5rem 0 0;
        position: relative;
    }

    ${layout.screen.smallScreen} {
        padding: 5.6rem 0 0;
        position: relative;
        .coms-title {
            font-size: 1.5rem;
            line-height: 1.75rem;
            margin-bottom: 1.5rem;
        }
        .coms-subtitle {
            padding-bottom: 1.25rem;
            margin-bottom: 0;
        }
    }
`;


const AnimationContainer = styled.div`
    position: relative;
    z-index: 10;
`;


export const WhatsNewSection = ({cards}) => {
    const cardsArray = cards?.data;
    return (
        <WhatsNewWrapper>
            <NewsTitle>Whats New</NewsTitle>
            <NewsCardsWrapper>
                {
                    cardsArray && cardsArray.map((elem,index)=>(<NewsCard title={elem?.title} description={elem?.description} link={elem?.link} image={elem?.icon} key={index}/>))
                }
            </NewsCardsWrapper>
            <button>
                Explore more at Blogs
            </button>
        </WhatsNewWrapper>
    )
}

const NewsCardsWrapper = styled.div`
    display:grid;
    grid-template-columns: repeat(12, minmax(0, 1fr));
    gap: 40px;
`;

const WhatsNewWrapper = styled.div`
    position: absolute;
    right: 0px;
    bottom: 0px;

    display: flex;
    flex-direction: column;
    width: fit-content;

    button {
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        padding: 12px 20px;
        
        background: rgba(255, 255, 255, 0.4);
        border: 2px solid rgba(255, 255, 255, 0.72);
        box-sizing: border-box;
        backdrop-filter: blur(4px);
        /* Note: backdrop-filter has minimal browser support */
        
        border-radius: 12px;


        /* Button 3 */

        font-family: SF Pro Display;
        font-style: normal;
        font-weight: bold;
        font-size: 14px;
        line-height: 24px;
        /* identical to box height, or 171% */

        text-align: center;
        letter-spacing: 1px;

        color: #00AB88;

        margin-top: 37px;

        width: fit-content;
    } 
`;

const NewsTitle =  styled.h5`
    /* H5 */

    font-family: Roboto Slab;
    font-style: normal;
    font-weight: 500;
    font-size: 16px;
    line-height: 26px;
    /* identical to box height, or 162% */


    /* Text 2 */

    color: #314235;
    
    margin-bottom:25px;
`;

export const NewsCard = ({image, title, description, link }) => {

    return (
        <NewsCardWrapper>
            <ImageWrapper>
                {image?.url && <img src={image.url}/>}
            </ImageWrapper>
            <TextWrapper>
                <h5>{title}</h5>
                <p>{description}</p>
            </TextWrapper>

        </NewsCardWrapper>
    )
}

const NewsCardWrapper = styled.div`

    display: flex;
    flex-direction: row;
    grid-column: span 12 / span 12;

    h5 {
        /* Subheading 4 */

        font-family: SF Pro Display;
        font-style: normal;
        font-weight: 600;
        font-size: 13px;
        line-height: 20px;
        /* identical to box height, or 154% */
        
        letter-spacing: 1px;
        
        /* Text 2 */
        
        color: #314235;
    }

    p {
        /* Small Text 2 */

font-family: SF Pro Display;
font-style: normal;
font-weight: 500;
font-size: 12px;
line-height: 20px;
/* or 167% */

letter-spacing: 1px;

/* Text 3 */

color: #2F695D;


    }

    a {
        font-family: SF Pro Display;
        font-style: normal;
        font-weight: 600;
        font-size: 1rem;
        line-height: 162%;
        /* or 150% */

        letter-spacing: 0.827336px;

        /* Accent 1 */

        color: #00AB88;
        margin-top: 16px;
        margin-bottom:72px;
    }

`;

const ImageWrapper = styled.div`
    img {
        height: auto;
        width: 96px;
    }
    height: 100%;
    border-radius: 12px;
`;

const TextWrapper = styled.div`
    width: 250px;
    margin-left: 18px;
`;


const FauxShadowContainer = styled.div`

    position: absolute;
    bottom: 19px;
    height: 12px;
    width: 100%;
    background: #b0b0b016;
    border-radius: 40%;
    z-index: -10;
    margin: 0px auto;
    box-shadow: rgba(149, 157, 165, 0.2) 0px 0px 24px;
`;



const IconsWrapper = styled.div`
display: flex;
margin-top: 72px;
justify-content: center;
align-items: center;

`;

const Logo = styled.div`
max-height:29px;
margin-left: 48px;
`;


const Icons = ({icons}) => {
    const iconsArray = icons?.data
    return (
        <IconsWrapper>
            {iconsArray && iconsArray.map((elem)=>{
                return(
                    <Logo>
                        <img src={elem?.icon?.url} alt={elem?.icon?.name}/>
                    </Logo>
                )
                
            })}
        </IconsWrapper>
    )
}


const Buttons = ({buttons}) => {
    const buttonsArray = buttons?.data
    return(
        <ButtonsWrapper>
            {buttonsArray && buttonsArray.map((elem, index)=>{
                if(index%2) {
                    return(
                        <ButtonLight>{elem.title}</ButtonLight>
                        
                    )
                } else return(
                    <ButtonDark>{elem.title}</ButtonDark>
                )
            })}
        </ButtonsWrapper>
    )
}

const ButtonsWrapper = styled.div`
    display: flex;
    justify-content: flex-start;
`;

const ButtonLight = styled.button`

/* H5 */

font-family: Roboto Slab;
font-style: normal;
font-weight: 500;
font-size: 16px;
line-height: 26px;
/* identical to box height, or 162% */


color: #2F695D;


/* Inside Auto Layout */

flex: none;
order: 0;
flex-grow: 0;
margin: 0px 10px;


display: flex;
flex-direction: row;
justify-content: center;
align-items: center;
padding: 16px 32px;

background: #ffffff;
border-radius: 16px;
`;


const ButtonDark = styled.button`

/* H5 */

font-family: Roboto Slab;
font-style: normal;
font-weight: 500;
font-size: 16px;
line-height: 26px;
/* identical to box height, or 162% */


color: #FFFFFF;


/* Inside Auto Layout */

flex: none;
order: 0;
flex-grow: 0;
margin: 0px 10px;


display: flex;
flex-direction: row;
justify-content: center;
align-items: center;
padding: 16px 32px;

background: #00AB88;
border-radius: 16px;
`;