import * as React from "react";
import { useRef, useEffect, useState } from "react";
import { motion, useMotionValue, useAnimation } from "framer-motion";
import {styled} from 'frontity'
import {layout} from '../../../utils/constants';
import { useWindowDimentions } from "../../../utils/hooks/usehooks";


function useContainerConstraints(ref) {
  const [constraints, setConstraints] = useState({
    top: 0,
    bottom: 0,
    left: 0,
    right: 0
  });

  const setData = () => {
    const element = ref.current;
    const viewportHeight = element?.offsetHeight;
    const contentHeight = element?.firstChild?.offsetHeight;
    const viewportWidth = element?.offsetWidth;
    const contentWidth = element?.firstChild?.offsetWidth;

    setConstraints({
      top: viewportHeight - contentHeight,
      bottom: 0,
      left: viewportWidth - contentWidth,
      right: 0
    });
  }

  useEffect(() => {
    ref.current && setData();
    window.addEventListener("resize", setData)
    window.addEventListener("orientationchange", setData)
    return () => {
      window.removeEventListener("resize", setData)
      window.removeEventListener("orientationchange", setData)
    }
  }, []);

  return constraints;
}


export const Swiper = ({data, sectionWrapperWidth, viewed}) => {
  const x = useMotionValue(0);
  let animControls = useAnimation();
  const [page, setpage] = useState(0);

  const [itemsMargin, setitemsMargin] = useState(0); // |<card>0.5<card>0.5<card>|
  const [itemWidth, setitemWidth] = useState(0);

  const [enableNav, setenableNav] = useState(data?.length <=2 ? false : true);
  const [animationCompleted, setanimationCompleted] = useState(false);
  
  const [swipeConfidenceThreshold, setswipeConfidenceThreshold] = useState(1000);

  const containerRef = useRef(null);
  const { top, bottom, left, right } = useContainerConstraints(containerRef);
  const {windowWidth, windowHeight} = useWindowDimentions();

  const scrollRef = useRef(null);

  const scrollToPage = (newpage) => {

  if(newpage > data.length - 1) {
    newpage = data.length - 1
  }
  if(newpage < 0) {
    newpage = 0;
  }
  
  const element = containerRef?.current;
  const containerWidth = element?.offsetWidth;

  const boundingBox = element?.getBoundingClientRect();
  const markerLeft = boundingBox?.left;
  const markerRight = boundingBox?.right;
  const markerHorizontalCenter = boundingBox?.left + 0.5 * containerWidth;

  const scrollElem = scrollRef?.current;
  let scrollOffset = window?.innerWidth && (window?.innerWidth < layout.breakpoints.md) ? -24 : 0;
  let traslation_x_Value = (scrollElem?.children?.[newpage]?.getBoundingClientRect()?.left || 0) - markerLeft + scrollOffset ;

    setpage(newpage);
    translateX(
      traslation_x_Value ,
      1
    );

  };


  function handleWheel_X(event) {
    // event.preventDefault();
  }

  const translateX = (delta, direction) => {
    const newX = x.get() - delta * direction;
    const clampedX = newX;
    x.stop();
    x.start(function () {
      animControls.start({ x: clampedX, transition: { duration: 0.5 } });
    });
  };

  const swipePower = (offset, velocity) => {
    return Math.abs(offset) * velocity;
  };

  const paginate = (newDirection) => {
    scrollToPage(page + newDirection);
  };

  const initialSetup = () => {
    setitemsMargin(sectionWrapperWidth*0.03);
    setitemWidth(sectionWrapperWidth*0.485);

    if(window.innerWidth < layout.breakpoints.md ) {
      if (sectionWrapperWidth < layout.breakpoints.md) {
        if(data?.length >1) {
          setenableNav(true);
        }
      }
    }
    
  }

  useEffect(() => {
    scrollToPage(page||0)
  }, [page])

  useEffect(() => {
    initialSetup();
  }, [sectionWrapperWidth])

  const CardAnimations = {
    show : {
      opacity: 1.1,
      y: 0,
      scale: 1,
    },
    hidden: {
      opacity: 0,
      y: 60
    },
    hover: {
      opacity: 1.1,
      y: -8,
      transition: { duration: 0.2, delay: 0 }
    },
    outOfScroll: {
      opacity: 1.1,
      y: 0,
      scale: 0.8,
      transition: { duration: 0.2, delay: 0 }
    },
    inScroll: {
      opacity: 1.1,
      y: 0,
      scale: 1,
      transition: { duration: 0.2, delay: 0 }
    }
  };



  return (
    <Wrapper itemsMargin={itemsMargin} sectionWrapperWidth={sectionWrapperWidth} itemWidth={itemWidth} enableNav={enableNav}>
      <div className="swiper-container" ref={containerRef} onWheel={handleWheel_X}>
        <motion.div
          drag={enableNav && "x"}
          dragConstraints={{ top, bottom, left, right }}
          className="scrollable"
          style={{ x }}
          animate={animControls}
          ref={scrollRef}
          dragElastic={1}
          onDragEnd={(e, { offset, velocity }) => {
            const swipe = swipePower(offset.x, velocity.x);
            if (swipe < -swipeConfidenceThreshold) {
              paginate(1);
            } else if (swipe > swipeConfidenceThreshold) {
              paginate(-1);
            }
          }}
          dragMomentum={false}
          transition={{
            x: { type: "spring", stiffness: 300, damping: 10 },
          }}
          
        >
          {data && data.map((elem, index) => (
                  <motion.div
                    onTap={(event) => {
                      event.preventDefault();
                      event.stopPropagation()
                      if(window?.innerWidth && (window?.innerWidth < layout.breakpoints.md) )
                        scrollToPage(index);
                    }}
                    whileHover={'hover'}
                    variants={CardAnimations}
                    className={`swiper-card ${page == index && "active"}`}
                    initial={'hidden'}
                    animate={viewed ? (  animationCompleted ? (Math.abs(page-index)<=1 ? 'inScroll' : 'outOfScroll') : 'show') : 'hidden'}
                    transition={animationCompleted ? { duration: 0.2, delay: 0 } :{ 
                      duration: 0.5, 
                      delay: (0.5)*(index) - 0.1*index + 0.5 
                    }}
                    onAnimationComplete={()=>{setanimationCompleted(true)}}
                  >
                    <div className="card-texts">
                      <h5 className="h5">{elem.title}</h5>
                      <p className="body2">{elem.description}</p>
                      {
                          elem.linkText && 
                          // <a href={elem.link}><p>{elem.linkText}</p></a>
                          <motion.a
                            className="link-wrapper"
                            href={elem.link || 'javascript::void(0)'}
                            whileHover={{
                                scale: 1.05,
                                transition: { ease: 'anticipate', duration: 0.200 },
                            }}
                            whileTap={{ scale: 0.98 }}
                        >
                            <p className="button2">{elem.linkText}</p>
                        </motion.a>
                      }
                    </div>
                  </motion.div>
          ))}
        </motion.div>
      </div>
      
    </Wrapper>
  );
};


const Wrapper = styled.div`

  position: relative;
  display: flex;
  justify-content: center;
  
  visibility: visible;
  display: block;
  // ${layout.screen.mob} {
  //     visibility: hidden;
  //     display: none;
  // }
  
  .swiper-container-wrapper {
    padding: 0px 40px;
  }
  .swiper-container {
    overflow: hidden;
    display: flex;
    flex-direction: row;
    margin: 0px auto;
    padding: 0 ${(props)=>(props.itemsMargin)}px;
    width: ${(props)=>(props.sectionWrapperWidth + 1*props.itemsMargin)}px;
    ${layout.screen.mob} {
      width: ${(props)=>(props.sectionWrapperWidth)}px;
    }
    position: relative;
    ${layout.screen.md} {
      padding: 0px 0px;
    }
  }
  
  .scrollable {
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    padding-bottom: 48px;
    padding-top: 24px;
    height: 100%;
    // gap: ${(props)=>(props.itemsMargin)}px; // flex->gap safari <14.1 fix
    position: relative;

    ${layout.screen.mob} {
      padding-bottom: 0rem;
      padding-top: 3rem;
    }
  }

  .scrollable > div {
    &:not(:last-child) {
        margin-right: ${(props)=>(props.itemsMargin)}px; // flex->gap safari <14.1 fix
    }
  }

  .swiper-card {

    ${layout.screen.mob} {
      min-width: 300px;
    }
    
    background: rgba(255, 255, 255, 0.4);
    border: 2px solid rgba(255, 255, 255, 0.72);
    box-sizing: border-box;
    backdrop-filter: blur(9px);
    border-radius: 23px;

    &.active {
      background: #ffffff;
    }

    &:hover {
      // background: #ffffff;
    }

    display: flex;
    position: relative;
    width: ${(props)=>(props.itemWidth)}px;
    align-self: stretch;
    flex-direction: column;
        
      .card-texts {
        display: flex;
        flex-direction: column;
        flex-grow: 1;
        position:relative;
       // padding: 54px 30px 91px 34px; 45 28 28 28
        padding-top: ${layout.reponsiveCssValue(36, 54, 1440, 45, 1600, 54)};
        padding-bottom: ${layout.reponsiveCssValue(90, 130, 1440, 108, 1600, 130)};
        padding-left: ${layout.reponsiveCssValue(24, 34, 1440, 30, 1600, 34)};
        padding-right: ${layout.reponsiveCssValue(24, 30, 1440, 28, 1600, 34)};

        // margin-top: ${layout.reponsiveCssValue(24, 36, 1440, 29.95, 1600, 36)};
        // padding-bottom: ${layout.reponsiveCssValue(36, 52, 1440, 42, 1600, 52)};

        h1,h2,h3,h4,h5,h6 {
            font-family: "Roboto Slab";
            font-size: ${layout.reponsiveCssValue(13, 20, 1440, 16.5467, 1600, 20)};
            ${layout.screen.mob} {
              font-size: 14px;
            }
            // color: #0E342C;
            color: #000000;
        }
        p {
          margin-top: ${layout.reponsiveCssValue(12, 36, 1440, 15.72, 1600, 19)};
          color: #2F695D;
        }

        a {
          position: absolute;
          // bottom: 32px;
          bottom: ${layout.reponsiveCssValue(24, 34, 1440, 30, 1600, 34)};

          p {
            color: #00AB88;
            font-weight: 600;
          }
        }
      }
    
  }
  
}
`;

