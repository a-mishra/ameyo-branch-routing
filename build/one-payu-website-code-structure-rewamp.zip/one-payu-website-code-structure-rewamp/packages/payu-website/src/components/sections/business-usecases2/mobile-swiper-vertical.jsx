import * as React from "react";
import { useRef, useEffect, useState } from "react";
import { motion, useMotionValue, useAnimation } from "framer-motion";
// import { clamp, snap } from "@popmotion/popcorn";
import { InView } from "react-intersection-observer";
import {styled} from 'frontity'
import {layout} from '../../../utils/constants';
import { Container } from '../../misc/layout';

import NavArrowLeftIcon from '../../../assets/icons/arrow-left.svg'

// import NavArrowLeftIcon from '../../../assets/icons/nav_arrow_left.svg'
import NavArrowRightIcon from '../../../assets/icons/nav_arrow_right.svg'
import { useWindowDimentions } from "../../../utils/hooks/usehooks";



function useContainerHeight(ref) {
  const [height, setHeight] = useState(96*3);

  const setData = () => {
    const element = ref.current;
    setHeight(96*3);
  }

  useEffect(() => {
    ref.current && setData();
    window.addEventListener("resize", setData)
    window.addEventListener("orientationchange", setData)
    return () => {
      window.removeEventListener("resize", setData)
      window.removeEventListener("orientationchange", setData)
    }
  }, []);

  return height;
}



export const VerticalMobileSwiper = ({data, sectionWrapperWidth, viewed}) => {
  const x = useMotionValue(0);
  const y = useMotionValue(0);

  let animControls = useAnimation();
  const [page, setpage] = useState(0);

  const [itemsMargin, setitemsMargin] = useState(0); 
  /* ___
    <card>
    0.5
    <card>
    0.5
    <card>
    __
  */

  const [itemWidth, setitemWidth] = useState(0);
  const [itemHeight, setitemHeight] = useState(0);

  const [enableNav, setenableNav] = useState(false);
  const [animationCompleted, setanimationCompleted] = useState(false);
  const [swipeConfidenceThreshold, setswipeConfidenceThreshold] = useState(1000);

  const containerRef = useRef(null);
  // const containerHeight = useContainerHeight(containerRef);
  const [containerHeight, setcontainerHeight ] = useState(96*3+40*2);

 


  const scrollRef = useRef(null);

  const calcContainerHeight = () => {
    const scrollElem = scrollRef?.current;
    // console.log('scrollElem?.children?.[page]', scrollElem?.children )
    let temp_height = scrollElem?.children?.[page]?.getBoundingClientRect()?.height;
    temp_height = temp_height+ scrollElem?.children?.[page+1]?.height || 0 + scrollElem?.children?.[page+2]?.height || 0 + 2*40;
    
    enableNav ? setcontainerHeight(Math.max(96*3+40*2, temp_height)) : setcontainerHeight(0);
    
  }

  const scrollToPage = (newpage) => {

    // console.log(newpage);
    if(newpage > data.length - 1) {
      newpage = data.length - 1
    }
    if(newpage < 0) {
      newpage = 0;
    }
    if(newpage == 0) {
      calcContainerHeight()
    }
    
    const element = containerRef?.current;
    const containerWidth = element?.offsetWidth;

    const boundingBox = element?.getBoundingClientRect();
    // console.log('bounding box', boundingBox );

    const markerLeft = boundingBox?.left;
    const markerRight = boundingBox?.right;
    const markerTop = boundingBox?.top;
    const markerBottom = boundingBox?.bottom;

    const scrollElem = scrollRef?.current;
    let scrollOffset = 0;

    // console.log(scrollElem?.children?.[newpage]?.getBoundingClientRect()?.top)
    let traslation_y_Value = (scrollElem?.children?.[newpage]?.getBoundingClientRect()?.top || 0) - markerTop + scrollOffset ;

    setpage(newpage);
    translateY(
      traslation_y_Value ,
      1
    );

  };


  const translateY = (delta, direction) => {
    const newY = y.get() - delta * direction;
    const clampedY = newY;
    y.stop();
    y.start(function () {
      animControls.start({ y: clampedY, transition: { duration: 0.5 } });
    });
  };


  const paginate = (newDirection) => {
    scrollToPage(page + newDirection);
  };

  const initialSetup = () => {
    setitemsMargin(sectionWrapperWidth * 0.1);
    setitemWidth(sectionWrapperWidth);
    calcContainerHeight();

    if(data.length > 3) {
      setenableNav(true)
    } 
    scrollToPage(0)
  }

  useEffect(() => {
    scrollToPage(page||0)
  }, [page])

  useEffect(() => {
    // console.log('Section width changed to', sectionWrapperWidth);
    initialSetup();
  }, [sectionWrapperWidth])

  const CardAnimations = {
    show : {
      opacity: 1,
      y: 0,
      scale: 1,
    },
    hidden: {
      opacity: 0,
      y: 0
    },
    hover: {

    },
    outOfScroll: {
      opacity: 0,
      y: 0,
      scale: 1,
      transition: { duration: 0.250, delay: 0 }
    },
    inScroll: {
      opacity: 1,
      y: 0,
      scale: 1,
      transition: { duration: 0.650, delay: 0 }
    }
  };

  const ImageAnimation = {
    viewed: {

    },
    hover: {
      y: -4,
      zIndex: 10 
    }
  };

  const NavAnimations = {
    showLeft : {
      opacity: 1,
      x: 2
    },
    showRight : {
      opacity: 1,
      x: -2
    },
    hiddenLeft: {
      opacity: 0,
      x: 4
    },
    hiddenRight: {
      opacity: 0,
      x: -4
    },
  }

  return (
    <Wrapper itemsMargin={itemsMargin} sectionWrapperWidth={sectionWrapperWidth} itemWidth={itemWidth} enableNav={enableNav}>
      <div className="swiper-container" style={{height: containerHeight || '100%'}} ref={containerRef} >
        <motion.div
        // drag='y'
          className="scrollable"
          style={{ y }}
          animate={animControls}
          ref={scrollRef}
          transition={{
            y: { type: "spring", stiffness: 300, damping: 10 },
          }}          
          
        >
          {data && data.map((elem, index) => (
                  <motion.div
                    onTap={(event) => {
                      //event.preventDefault();
                      event.stopPropagation()
                      scrollToPage(index);
                    }}
                    whileHover={'hover'}
                    variants={CardAnimations}
                    className={`small-card ${page == index && "active"}`}
                    initial={'hidden'}
                    animate={viewed ? (  animationCompleted ? ((index-page)<0 || index-page >= 3 ? 'outOfScroll' : 'inScroll') : 'show') : 'hidden'}
                    transition={{ 
                      duration: 0.5, 
                      delay: (0.5)*(index) - 0.1*index + 0.5 
                    }}
                    onAnimationComplete={()=>{
                      setanimationCompleted(true);
                      if(index ==2)
                        setTimeout(() => {
                          calcContainerHeight()
                        }, 2500);
                        
                      }}
                  >

                          <div className="image-wrapper">
                              {elem?.image?.url && <motion.img 
                                variants={ImageAnimation}
                                src={elem?.image?.url} 
                              />}
                          </div>
                          <div className="card-texts">
                              <h3 className="h5">{elem?.heading}</h3>
                              {elem?.description && <p className="body2">{elem?.description}</p>}
                              {
                                  elem?.link?.text && 
                                  <motion.a 
                                    href={elem?.link?.url}
                                    whileHover={{
                                      zIndex: 10,
                                      scale:1.05,
                                      x: 4
                                    }}
                                    className="button2"
                                  >
                                      {elem?.link?.text}
                                  </motion.a>
                              }
                          </div>

                  </motion.div>
          ))}
        </motion.div>
      </div>
      { enableNav && <motion.div className="navigation-wrapper">
        <NavButtons onClick={paginate} isFirstSlide={page==0} isLastSlide={page==data.length-1} />
        </motion.div> }
    </Wrapper>
  );
};


const Wrapper = styled.div`

  position: relative;
  display: flex;
  justify-content: center;
  
  visibility: hidden;
  display: none;
  ${layout.screen.mob} {
      visibility: visible;
      display: block;
  }
  
  .swiper-container {
    //border: solid 1px black;
    overflow: hidden;
    display: flex;
    flex-direction: row;
    margin: 0px auto;
    width: ${(props)=>(props.sectionWrapperWidth)}px;
    position: relative;
  }
  
  .scrollable {
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    height: 100%;
    // gap: ${(props)=>(props.itemsMargin)}px;
    position: relative;

    gap: 40px;    
    background: transparent;
    flex-direction: column;


  }

  .navigation-wrapper {
    width: ${(props)=>(props.sectionWrapperWidth)}px;
    margin: 0 auto;
    margin-top: ${layout.reponsiveCssValue(36, 42, 375, 40 , 992, 42)};
  }


      .small-card {
        // height: 96px;
        // border: solid 1px black;

          display: flex;
          flex-direction: row;
          gap: ${layout.reponsiveCssValue(20, 48, 375, 20, 922, 48)};

          .image-wrapper {
            aspect-ratio: 1/1;
            width:auto;
            height: ${layout.reponsiveCssValue(96, 150, 375, 96, 922, 150)};
            justify-content: flex-start;
            
            img {
              object-fit: contain;
              width: 100%;
              height: auto;
              max-width: 100%;
              max-height: 100%;
            }
          }

          .card-texts {
            display: flex;
            flex-direction: column;
            flex-grow: 1;
            position:relative;

            h1,h2,h3,h4,h5,h6 {
                // font-family: "Roboto Slab";
                // font-size: ${layout.reponsiveCssValue(13, 20, 1440, 16.5467, 1600, 20)};
                ${layout.screen.mob} {
                  // font-size: 16px;
                }
                // color: #0E342C;
            }
            p {
              margin-top: ${layout.reponsiveCssValue(8, 16, 375, 8, 992, 16)};
              // color: #2F695D;
              // ${layout.screen.mob} {
              //   font-size: 14px;
              // }
            }
    
            a {
              p {
                color: #00AB88;
                font-weight: 600;
              }
            }


      }
  
}
`;



// Start : Buttons component

const NavButtonsWrapper = styled.div`
    display: flex;
    justify-content: space-between;
    align-items: center;

    .button {
        cursor: pointer;
        width: 36px;
        height: 36px;
        ${layout.screen.mob} {
          width: 48px;
          height: 48px;
        }
        background: rgba(255, 255, 255, 0.72);
        opacity: 0.8;
        box-shadow: inset 1.65467px 1.65467px 1.65467px rgba(255, 255, 255, 0.25);
        backdrop-filter: blur(26.4748px);
        border-radius: 50%;
        display: flex;
        justify-content: center;
        align-items: center;
    
        background: rgb(255, 255, 255);
        box-shadow: rgb(255 255 255 / 25%) 2px 2px 2px inset;
        backdrop-filter: blur(32px);
        border-radius: 50%;
        transform: none;
        opacity: 1;

        img {
            height: 14px;
            width: auto;
            ${layout.screen.mob} {
              height: 17px;
            }
        }

    }

    .button.left {
    }

    .button.right {
        img {
            transform: rotate(180deg);
        }
    }

    .button.inactive {
        cursor: not-allowed;
        opacity: 0.5;

        background: rgba(255, 255, 255, 0.72);
        opacity: 0.8;
        box-shadow: inset 2px 2px 2px rgba(255, 255, 255, 0.25);
        backdrop-filter: blur(32px);
        /* Note: backdrop-filter has minimal browser support */

        border-radius: 50%;
    }

`;


const NavButtons = ({onClick, isFirstSlide, isLastSlide}) => {
    return (
        <NavButtonsWrapper>
              <motion.div 
                className={`button left ${isFirstSlide ? 'inactive': ''}`} 
                onClick={()=>onClick(-1)} 
                whileHover={isFirstSlide ? {} :{
                  scale: 1.1,
                  transition: { ease: 'anticipate', duration: 0.200 },
                }}
                whileTap={isFirstSlide ? {} : { scale: 0.9 }}
              >
                  <img src={NavArrowLeftIcon}/>
              </motion.div>

              <motion.div 
                className={`button right ${isLastSlide ? 'inactive': ''}`} 
                onClick={()=>onClick(1)}
                whileHover={isLastSlide ? {} :{
                  scale: 1.1,
                  transition: { ease: 'anticipate', duration: 0.200 },
                }}
                whileTap={isLastSlide ? {} : { scale: 0.9 }}
              >
                  <img src={NavArrowLeftIcon}/>
              </motion.div>
        </NavButtonsWrapper>
    )
}

// End : NavButtons component
