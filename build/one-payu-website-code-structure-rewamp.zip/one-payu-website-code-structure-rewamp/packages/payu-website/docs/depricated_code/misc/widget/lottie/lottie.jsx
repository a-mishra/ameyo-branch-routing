import React, {useRef, useState, useEffect} from 'react';
import { Player, Controls } from '@lottiefiles/react-lottie-player';
import { useCounter, useHover } from 'usehooks-ts' 
import { useOnScreen, useLottieContainerDimensions } from '../../../../utils/hooks/usehooks'; 
import {styled} from 'frontity'
/**
 * lottie: object | string (link to lottie file or lottie json object )
 * loopStartFrame: number (default 0) (frame number from where animation loop shall start)
 * onHover: boolean (if the animation shall play on hover)
 * autoPlay: boolean (play animation till loopStartFrame, when animation is in view)
 * autoPlayLoop: boolean (to loop the animation if autoplay == true)
 * unInterruptedPlay: boolean (if true hover interafction would not pause the animation, if false looped autoplay can be paused by hover interaction)
 * shouldPlay: boolean (to get the playback controls outside the LottieAnimation) (if true animation shall play uninterrupted)
 * loopCompleteEvent: fn (callback function when a loop is completed) (such that outside entity can know if the loop is completed and would be able to change shouldPlay on the basiss of this callback)
 * width: string
 * height: string
 * onScreenOffset: string (offset margin for IntersectionObserver,  for -ve values animation trigger would be postponed, for +ve values animation trigger would be preponed)
 * debug: boolean (disply and controls for debugging purpose)
 */
const LottieAnimation = ({lottie, loopStartFrame, onHover, autoPlay, autoPlayLoop, unInterruptedPlay, shouldPlay, loopCompleteEvent, height, width, onScreenOffset,  debug, childComponent, onLoad, shadow=true }) => {

    const player = useRef();
    const playerWrapper = useRef();
    const hoverRef = useRef();
    const isHover = useHover(hoverRef);
    const [onScreen, portionInView] = useOnScreen(playerWrapper, onScreenOffset || "0px");

    const { count, setCount, increment, decrement, reset } = useCounter(0);
    const [animationDirection, setanimationDirection] = useState(1);
    const [animationState, setanimationState] = useState('');
    const [initalRenderCompleted, setinitalRenderCompleted] = useState(false)
    const [isLoaded, setisLoaded] = useState(false);
    const playerDimentions = useLottieContainerDimensions(playerWrapper, isLoaded);


    const onEvent = (event) => {
        // take actions for events
        switch(event) {
            case "load": 
                if((onScreen === true || isHover === true) && (autoPlay === true || shouldPlay === true)) {
                    setPlayback(true);
                }
                setisLoaded(true);
                onLoad();
                break;

            case "play": 
                if(initalRenderCompleted) {
                    player?.current.setSeeker((loopStartFrame || 0 ), true);
                }
                break;

            case "frame":
                animationDirection ? increment() : decrement();
                if(count >=(loopStartFrame || 0 ) && initalRenderCompleted == false) {
                    setinitalRenderCompleted(true);
                }
                break;

            default :
                if(['loop', 'stop', 'complete'].includes(event)) {
                    loopCompleteEvent && loopCompleteEvent(event)
                    resetAnimation();
                }
                break;
        }

        // update animation state
        if(['load', 'error', 'ready', 'play', 'pause', 'stop', 'freeze', 'complete'].includes(event))
            setanimationState(event);
    }


    const resetAnimation = () => {
        if(initalRenderCompleted) {
            player?.current.setSeeker((loopStartFrame || 0 ), isHover || shouldPlay === true || ( autoPlay && autoPlayLoop));
        }
        setCount((loopStartFrame || 0 ));
    }

    const setPlayback = (value) => {
        if(value) {
            if(initalRenderCompleted) {
                player?.current.setSeeker(count, value);
                player?.current.play();
            }
            else
                player?.current.play();
        } else {
            player?.current.pause();
        }
    }


    useEffect(() => {
        if(onHover)
            if((!isHover && !(shouldPlay === true) && (!autoPlay || !unInterruptedPlay)) || isHover) 
                setPlayback(isHover) // hover off karne par animation pause ho jayega, agar shouldPlay false hai to || Agar shouldPlay true hai to hover off ka koi effect nahi aayega.
    }, [isHover])

    useEffect(() => {
        if(shouldPlay === true)
            setPlayback(true)
        else if(shouldPlay === false)
            setPlayback(false)
        // In case of undefined or null do nothing
    }, [shouldPlay])

    useEffect(() => {
        if(onScreen){
            if(autoPlay && (!initalRenderCompleted || autoPlayLoop)) {
                setPlayback(true)
            }
        } else {
            setPlayback(false)
        }
    }, [onScreen])

    return (
        <div ref={hoverRef}>
            <div ref={playerWrapper}>
                <Player
                    onEvent={onEvent}
                    ref={player}
                    autoplay={false}
                    loop={true}
                    src= {lottie}
                    style={{ height: height || 'auto', width: width || 'fit-content' }}
                    hover={false}
                    renderer="svg"
                    className="test"
                    keepLastFrame={true}
                    rendererSettings={{
                        preserveAspectRatio: 'xMidYMid slice', // Supports the same options as the svg element's preserveAspectRatio property
                        clearCanvas: false,
                        className: 'some-css-class-name',
                        id: 'some-id',
                      }}
                >
                    {debug && <Controls
                        transparentTheme={true}
                        showLabels={true}
                        visible={true}
                        buttons={['play', 'repeat', 'frame', 'debug', 'snapshot', 'background', 'stop']}
                    />}
                </Player>
                
            </div>
            
              {
                  isLoaded &&
                    <ChildComponentWrapper width={playerDimentions && playerDimentions.width || 0}>
                        <Wrapper2 width={playerDimentions && playerDimentions.svgWidth || 0}>
                            <RenderChild child={childComponent}/>
                            {shadow && <FauxShadowContainer   width={playerDimentions && playerDimentions.svgWidth || 0}/>}
                        </Wrapper2>
                    </ChildComponentWrapper>

              }  
            



        {debug && <ul>
                        <li>Animation State : {animationState}</li>
                        <li>Animation Direction: {animationDirection}</li>
                        <li>Frame: {count}</li>
                        <li>InitialRenderCompleted: {String(initalRenderCompleted)}</li>
                        <li>isHover: {String(isHover)}</li>
                        <li>loopStartFrame: {loopStartFrame}</li>
                        <li>onHover: {String(onHover)}</li>
                        <li>autoPlay: {String(autoPlay)}</li>
                        <li>autoPlayLoop: {String(autoPlayLoop)}</li>
                        <li>unInterruptedPlay: {String(unInterruptedPlay)}</li>
                        <li>shouldPlay: {String(shouldPlay)}</li>
                        <li>height: {height}</li>
                        <li>width: {width}</li>
                        <li>onScreenOffset: {onScreenOffset}</li>
                        <li>onScreen: {String(onScreen)}</li>
                    </ul>
            }
        </div>
    );
}

export default LottieAnimation;


const ChildComponentWrapper = styled.div`
    width: ${(props) => props.width}px;

    position: absolute;
    bottom:0px;
    left:0px;
    
    display: flex;
    justify-content: center;
`

const Wrapper2 = styled.div`
    width: ${(props) => props.width}px;
    display: flex;
    justify-content: center;

    h3 {
        font-family: Roboto Slab;
        font-style: normal;
        font-weight: 500;
        font-size: calc( 11px + (26px - 11px) * ((${(props) => props.width} - 250) / (672 - 250)) );
        
        // calc([minimum size] + ([maximum size] - [minimum size]) * ((100vw - [minimum viewport width]) / ([maximum viewport width] - [minimum viewport width])));
        line-height: 163%;
        color: #0E342C;
    }

    p {
        font-family: 'Open Sans', serif;
        font-style: normal;
        font-weight: 400;
        font-size: calc( 9px + (16px - 9px) * ((${(props) => props.width} - 250) / (672 - 250)) );
        line-height: 163%;
        letter-spacing: calc( 0.2px + (0.825px - 0.5px) * ((${(props) => props.width} - 250) / (672 - 250)) );
        color: #2F695D;
    }
`
const RenderChild = (props) => {
	return (
        <>
            {props.child}
        </>
	)
}
const FauxShadowContainer = styled.div`
    position: absolute;
    bottom: -72px;
    height: 24px;
    width: 80%;
    background: #DDE2DF5c;
    border-radius: 50%;
    z-index: -10;
    margin: 0px auto;
    // filter: drop-shadow(0px 72px 4px #DDE2DF);

    position: absolute;
    bottom: -72px;
    height: 18px;
    width: calc( ${(props) => props.width}px * 0.8 );
    background: #b0b0b016;
    border-radius: 40%;
    z-index: -10;
    margin: 0px auto;
    box-shadow: rgba(149, 157, 165, 0.2) 0px 0px 24px;
`;