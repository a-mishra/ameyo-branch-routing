import { styled, connect, loadable } from "frontity";


const Page = ({ state, libraries, data}) => {
    // Load the page, but only if the data is ready.

      // Get the data of the page.
      const page = state.source.page[data.id];
        if(page) {

          // Get the html2react component.
          const Html2React = libraries.html2react.Component;

          // Get all categories
          const allCategories = state.source.category;

          /**
           * The item's categories is an array of each category id
           * So, we'll look up the details of each category in allCategories
           */
          const categories =
            page.categories && page.categories.map((catId) => allCategories[catId]);

          // Get all tags
          const allTags = state.source.tag;

          /**
           * The item's categories is an array of each tag id
           * So, we'll look up the details of each tag in allTags
           */
          return (
            <div>
              {page.content && (
                <div >
                    <Html2React html={page.content.rendered} />
                </div>
              )}
            </div>
          )
        }
    
};

export default connect(Page);