import React, {  useRef, useEffect, useState, useLayoutEffect } from 'react'
import { connect, styled , Global, css} from 'frontity';
import {layout} from '../../../utils/constants';
import {useOnScreen, useWindowDimentions} from '../../../utils/hooks/usehooks'
import { Section, Row, Col, Container } from '../../misc/layout';
import { motion, useMotionValue, useAnimation, AnimatePresence } from "framer-motion";
import Card from './card'

const StackedSwiper = (props) => {
    const [index, setIndex] = useState(0)
    const [exitX, setExitX] = useState("100%");
    const [height, setheight] = useState(700);
    const [width, setwidth] = useState(props.width);
    const NumberOfSliders = props?.data?.cards?.length  || 1;
    const [exitDirection, setexitDirection] = useState(-1)

    const handleUpdateHeight = (newHeight) => {
        setheight(newHeight);
    }


    return (
            <motion.div
                style={{ 
                    // width: '100%', 
                    // height: 1000, 
                    position: "relative",
                    height: height,
                    margin: "0 auto",
                }}
            >
                <AnimatePresence initial={false}>
                    {NumberOfSliders > 2 && <Card
                        key={index+exitDirection*2 < 0 ? NumberOfSliders + (index+exitDirection*2) :( index+exitDirection*2 >= NumberOfSliders ? index+exitDirection*2-NumberOfSliders  : index+exitDirection*2 ) }
                        initial={{ scale: 0, y: 0, opacity: 0 }}
                        // animate={{ scale: (0.80), y: Math.min(((1-.8)*height)/2+30+10, 120), opacity: (1/3), zIndex: 10 }}
                        animate={{ scale: (0.80), y:((0.1)*height)+50, opacity: (1/3), zIndex: 10 }}
                        transition={{
                            scale: { duration: 0.800 },
                            opacity: { duration: 0.200 },
                            zIndex: {duration: 0.2}

                        }}
                        // transition={{
                        //     type: "spring",
                        //     stiffness: 30,
                        //     damping: 20000,
                        //     //todo optimise spring for ease transition, else use easeout
                        //         mass: 8.1,
                        //         tension: 180,
                        //         friction: 78,
                        //     opacity: { duration: 0.2 },
                        //     scale: { duration: 0.4 },
                        // }}
                        data={props.data}
                        width={props.width}
                        height={height}
                        index={index+exitDirection*2 < 0 ? NumberOfSliders + (index+exitDirection*2) :( index+exitDirection*2 >= NumberOfSliders ? index+exitDirection*2-NumberOfSliders  : index+exitDirection*2 ) }

                    />}
                    { NumberOfSliders > 1 && <Card
                        key={index+exitDirection < 0 ? NumberOfSliders + (index+exitDirection) :( index+exitDirection >= NumberOfSliders ? index+exitDirection-NumberOfSliders  : index+exitDirection ) }
                        // key={index+exitDirection}
                        initial={{ scale: 0, y:(0) , opacity: 0 }}
                        // animate={{ scale: (0.90), y: Math.min(((1-.9)*height)/2+24, 60), opacity: (0.75), zIndex: 20 }}
                        animate={{ scale: (0.90), y: ((0.05)*height)+30, opacity: (0.75), zIndex: 20 }}
                        transition={{
                            scale: { duration: 0.800 },
                            opacity: { duration: 0.200 },
                            zIndex: {duration: 0.2}
                        }}
                        // transition={{
                        //     type: "spring",
                        //     stiffness: 30,
                        //     damping: 20000,
                        //     //todo optimise spring for ease transition, else use easeout
                        //         mass: 8.1,
                        //         tension: 180,
                        //         friction: 78,
                        //     opacity: { duration: 0.2 },
                        //     scale: { duration: 0.4 },
                        // }}
                        data={props.data}
                        width={props.width}
                        height={height}
                        index={index+exitDirection < 0 ? NumberOfSliders + (index+exitDirection) :( index+exitDirection >= NumberOfSliders ? index+exitDirection-NumberOfSliders  : index+exitDirection ) }
                        // index={index+exitDirection}
                        exitX={exitX}
                        setExitX={setExitX}
                        setexitDirection={setexitDirection}
                    />}
                    <Card
                        key={index}
                        animate={{ scale: 1, y: 0, opacity: 1, zIndex: 30 }}
                        transition={{
                            // type: "spring",
                            // stiffness: 30,
                            // damping: 20000,
                            // //todo optimise spring for ease transition, else use easeout
                            //     mass: 8.1,
                            //     tension: 180,
                            //     friction: 78,
                            opacity: { duration: 0.8 },
                            scale: { duration: 0.5 },
                            zIndex: {duration: 0.5}
                        }}
                        exitX={exitX}
                        setExitX={setExitX}
                        index={index}
                        setIndex={(newIndex)=>{
                            // console.log('index changed to :', newIndex),
                            setIndex(newIndex)}
                        }
                        drag="x"
                        data={props.data}
                        updateHeight={handleUpdateHeight}
                        isTopCard={true}
                        width={props.width}
                        setexitDirection={setexitDirection}
                    />
                </AnimatePresence>
            </motion.div>
    )
}

export default StackedSwiper;


const SectionWrapper = styled.div`

`;