import { connect, decode } from "frontity";
import { getCurrentNavigationMenu, getPostToRender } from '../../../utils/methods';
import {Helmet} from "react-helmet";
import { homeConfig } from "../../../utils/constants";

const Meta = ({state}) => {

  const menu = getCurrentNavigationMenu(state.router.link);
  const post = getPostToRender(state.router.link);
  let data = state.source.get(post)
  let siteTitle = `${state.frontity.title}`;
  
  if(menu != homeConfig.menu.name ) {
    if (data.isPostType) {
      // Add titles to posts and pages, using the title and ending with the Blog Name.
      // 1. Get the post entity from the state and get its title.
      const postTitle = state.source[data.type][data.id].title.rendered;
      // 2. Remove any HTML tags found in the title.
      const cleanTitle = decode(postTitle);
      // 3. Render the proper title.
      siteTitle = `${cleanTitle} - ${state.frontity.title}`;
    } else if(!!menu) {
      siteTitle = `${menu} - ${state.frontity.title}`;
    }
  }


  return (
    <Helmet>
        <meta charSet="utf-8" />
        <title>{siteTitle}</title>
        <link rel="canonical" href={state.frontity.url} />
    </Helmet>
  );
};

export default connect(Meta);
