import React, { useRef, useEffect, useState, useLayoutEffect } from "react";
import {
  useViewportScroll,
  useTransform,
  useSpring,
  motion,
  AnimatePresence,
  useAnimation
} from "framer-motion";


export default function SequenceReveal({
  children,
  className,
  sequence = 0,
  inView
}) {


    const controls = useAnimation()

    // useEffect(() => {
    //     console.log(inView)
    //     if(inView) {
    //         controls.start(i => ({
    //             opacity: 1,
    //             transition: { delay: i * 0.3 },
    //         }))
    //     }
    // }, [])


    // useEffect(() => {
    //             console.log(inView)

    //     if(inView) {
    //         controls.start(i => ({
    //             opacity: 1,
    //             transition: { delay: i * 0.3 },
    //         }))
    //     }
    // }, [inView])

  const springConfig = {
    damping: 100,
    stiffness: 100,
    mass: 3
  };

  const motionStyles = useSpring(
    springConfig
  );

  return (
    <AnimatePresence>
    {/* {inView && ( */}
        <motion.div 
            // custom={sequence}
            initial={{opacity: 0}}
            // animate={controls}
            style={motionStyles}
            // transition={{
            //     opacity: { ease: "cubic-bezier(0.0, 0.0, 1.0, 1.0)" },
            //     layout: { duration: 0.3 }
            // }}
            animate={{
                opacity: 1,
                transition: { delay: sequence * 0.3 },
            }}
            exit={{ opacity: 0 }}


        >
            {children}
        </motion.div>
    {/* )} */}
    </AnimatePresence>
  );
}
