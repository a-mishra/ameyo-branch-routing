import React, {  useRef, useEffect, useState, useLayoutEffect } from 'react'
import { connect, styled , Global, css} from 'frontity';
import {layout, SectionAnimation} from '../../../utils/constants';
import {useOnScreen, useWindowDimentions, useContainerDimensions} from '../../../utils/hooks/usehooks'
import { Section, Row, Col, Container } from '../../misc/layout';
import { motion, useMotionValue, useAnimation } from "framer-motion";


const SectionWrapper = styled.div`
    min-height: 300px;
    position: relative;
    overflow-x: clip;

    .section-container {

        ${layout.screen.mob} {
            padding-left: 0px;
            padding-right: 0px;
        }
    }
    
    .section-inner {
        background: #FFFFFF;
        border-radius: 28px;
        ${layout.screen.mob} {
            border-radius: 12px;
        }
        display: flex;
        flex-direction : row;

        ${layout.screen.mob} {
            flex-direction: column;
        }

        padding-top: ${layout.reponsiveCssValue(48,115, 1200, 82, 1600, 115)};
        padding-bottom: ${layout.reponsiveCssValue(48,115, 1200, 82, 1600, 115)};
        padding-left: ${layout.reponsiveCssValue(64,130, 1200, 96, 1600, 130 )};
        padding-right: ${layout.reponsiveCssValue(64,130, 1200, 96, 1600, 130)};
        
        ${layout.screen.mob} {
            padding-top: ${layout.reponsiveCssValue(20,48, 375, 64, 992, 48)};
            padding-bottom: ${layout.reponsiveCssValue(20,48, 375, 64, 992, 48)};
            padding-left: ${layout.reponsiveCssValue(27,64, 375, 28, 992,64 )};
            padding-right: ${layout.reponsiveCssValue(27,64, 375, 28, 992,64 )};
        }

        .image-container {
            flex: 4;
            height: inherit;
            position: relative;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-evenly;
            display: grid;
            grid-template-columns: 1fr 1fr;
            align-items: center;
            justify-items: center;

            ${layout.screen.mob} {
                display: none;
            }
            img {
                height: ${layout.reponsiveCssValue(58, 83, 1200, 62, 1600, 83)};
                width: auto;
                margin: 0px 16px;
            }
            
        }
        .text-button-container {
            display: flex;
            flex-direction: column;
            flex: 4;
            
            .texts {
                h1,h2,h3,h4,h5,h6 {
                    color: #141416;
                    margin: 0px;
                }

                h2 {
                    display: block;
                }

                h3 {
                    display: none;
                }

                ${layout.screen.mob} {
                    h2 {
                        display: none;
                    }
                    h3 {
                        display: block;
                    }
                }

                p {
                    margin-top: 1rem;
                    color: #2F695D;
                }
                // margin-bottom: ${layout.reponsiveCssValue(24,33, 1440, 28, 1600,33 )};
            
            }
            
            .link-wrapper {
                margin-top: 40px;
                font-family: Open Sans;
font-style: normal;
font-weight: 600;
font-size: 13.2374px;
line-height: 20px;
/* or 150% */

letter-spacing: 0.827336px;

/* Accent 1 */

color: #00AB88;
            }

            .buttons-wrapper {
                display: flex;
                flex-direction: row;
                gap: 1.5rem;
            }

            .image-container-mobile {
                display: none;
                grid-template-columns: 1fr 1fr 1fr;
                row-gap: 28px;
                column-gap: 42px;


                ${layout.screen.mob} {
                    display: grid;

                    margin-top: 62px;
                    margin-bottom: 12px;

                }
            }

        }
    }


`;


const SectionPopularPlugins = ({state, actions, data, libraries}) =>  {

    const ref = useRef(null)
    const [onScreen, portionInView, viewed] = useOnScreen(ref, "0px");
    const Html2React = libraries.html2react.Component;


    useEffect(() => {
        actions.intraPageLinks.update(data?.section?.internalLink, portionInView);
        return () => {
            actions.intraPageLinks.update(data?.section?.internalLink, 0);
        }
    }, [portionInView])


    return (
        <>
            <SectionWrapper id={data?.section?.internalLink}>
                <Section padding={'level4'} className={'section-container'}>
                    <motion.div 
                        className="section-inner"
                        ref={ref}
                        variants={SectionAnimation}
                        initial={'hidden'}
                        animate={viewed ? 'show' : 'hidden'}
                        transition={{
                            ...SectionAnimation.transition(0, true)
                        }}
                    >
                        <div className="text-button-container">
                            <div className="texts">
                                <h3><Html2React html={data?.heading || ''} /></h3>
                                <h2><Html2React html={data?.heading || ''} /></h2>
                                <p><Html2React html={data?.description || ''} /></p>
                            </div>

                            <div className="image-container-mobile">
                            {
                                data?.logo?.map((elem,index)=>(
                                    <a href={`${elem?.url|| 'javascript:void(0)'}`}>
                                    <motion.img 
                                        className={'image-item'}
                                        alt={elem?.image?.name}
                                        src={elem?.image?.url}
                                        whileHover={{
                                            scale: 1.02,
                                            y: -4,
                                            transition: { ease: 'anticipate', duration: 0.200 },
                                        }}
                                        whileTap={{ scale: 0.98 }}
                                    >
                                    </motion.img>
                                    </a>
                                ))

                            }
                            </div>
                            
                            <motion.a
                                className="link-wrapper"
                                variants={SectionAnimation}
                                initial={{x: 16, opacity: 0}}
                                animate={viewed ? {x:0, opacity: 1} : {}}
                                href={data?.link?.url || 'javascript::void(0)'}
                                whileHover={{
                                    scale: 1.02,
                                    x: 8,
                                    transition: { ease: 'anticipate', duration: 0.200 },
                                }}
                                whileTap={{ scale: 0.98 }}
                            >
                               {data?.link?.text}
                            </motion.a>
                        </div>

                        <div className="image-container">
                            {
                                data?.logo?.map((elem,index)=>(
                                    <a href={`${elem?.url|| 'javascript:void(0)'}`}>
                                    <motion.img 
                                        className={'image-item'}
                                        alt={elem?.image?.name}
                                        src={elem?.image?.url}
                                        whileHover={{
                                            scale: 1.02,
                                            y: -4,
                                            transition: { ease: 'anticipate', duration: 0.200 },
                                        }}
                                        whileTap={{ scale: 0.98 }}
                                    >
                                    </motion.img>
                                    </a>
                                    
                                ))

                            }
                        </div>
                        
                    </motion.div>
                </Section>
            </SectionWrapper>
        </>
    )

}

export default connect(SectionPopularPlugins)

