import React, {useRef} from 'react'
import { layout } from '../../../utils/constants';
import {
    motion,
    useSpring
  } from "framer-motion";
  import {styled, connect} from 'frontity';
import { Container } from '../../misc/layout';

const Wrapper = styled.div`
    z-index: 10;
    background: #F8F8F8;
    p {
        color: #3B3D41;
    }
    h6 {
        font-family: Roboto;
        font-style: normal;
        font-weight: 500;
        font-size: 11.5827px;
        line-height: 14px;
        letter-spacing: 0.827336px;
        color: #000000;
    }

    .bottom-border {
        border-bottom: 0.827336px solid #9fa4ad78;
    }

    .inner-section {
        padding-top: ${layout.reponsiveCssValue(48, 64, 1440, 52, 1600, 64)};
        padding-bottom: ${layout.reponsiveCssValue(48, 64, 1440, 52, 1600, 64)};
        padding-left: 0rem;
        padding-right: 0rem;

        ${layout.screen.mob} {
            padding-top: ${layout.reponsiveCssValue(48, 64, 375, 61, 993, 48)};
            padding-bottom: ${layout.reponsiveCssValue(58, 78, 375, 77, 993, 64)};
        }
        
        .section1 {
            display: flex;
            align-items: flex-start;
            // justify-content: flex-start;
            justify-content: space-between;
            flex-direction: row;
            flex-wrap: wrap;
            padding-bottom: 4rem;

            .links-column {
                display: flex;
                align-items: flex-start;
                justify-content: flex-start;
                flex-direction: column;
                flex: 2;
                flex-basis: 150px;

                .links-collection {
                    margin-bottom: 1.5rem;
                    h6 {
                        margin-bottom: 11px;
                    }
                    p {
                        margin-bottom: 10px;
                    }
                }
            }

            .right-section {
                display: flex;
                flex:  5;
                flex-direction: column;
                flex-basis: 300px;

                p {
                    font-family: SF Pro Display;
                    font-style: normal;
                    font-weight: normal;
                    font-size: 16.6667px;
                    line-height: 192%;
                    letter-spacing: 1px;
                    color: #314235;

                    ${layout.screen.mob} {
                        font-family: SF Pro Display;
                        font-style: normal;
                        font-weight: normal;
                        font-size: 13px;
                        line-height: 177%;
                        letter-spacing: 1px;
                    }
                    
                }
                
                img {
                    margin-top: 36px;
                    width: 70px;
                    height: auto;
                }
            }
        }

        

        .language-downloads {
            display: flex;
            flex-direction: row;

            padding: 15px 0;

            .downloads {
                display: flex;
                flex-grow: 1;
                justify-content: flex-end;
                align-items: center;
                flex-direction: row;
                gap: 2rem;
                
                
                .download-link-wrapper {
                    display: flex;
                    flex-direction: row;
                    align-items: center;

                    .block {
                        width: 24px;
                        height: 24px;
                        background: #C4C4C4;
                        border-radius: 4px;
                        margin-right: 18px;
                    }
                    .a {
                    
                    }
                }


            }
        }

        .logos-disclaimer {
            display: flex;
            flex-direction: row;



            padding: 15px 0 0 0;


            ${layout.screen.mob} {
                flex-direction: column-reverse;
                align-content: center;
                justify-content: center;
            }
            .logos {
                display: flex;
                justify-content: flex-start;
                ${layout.screen.mob} {
                    justify-content: center;
                    margin-top: 32px;
                }
            }

            .disclaimer {
                display: flex;
                flex-grow: 1;
                justify-content: flex-end;
                align-items: flex-end;
                .text-wrapper {
                    padding-right: 0.75rem;
                }
                ${layout.screen.mob} {
                    display: none;
                }
                a {
                    color: inherit;
                    font-size: inherit;
                    font-family: inherit;
                    font-style: inherit;
                    font-weight: inherit;
                    line-height: inherit;
                }
            }

            .disclaimer-mobile {
                display: none;
                text-align: center;
                ${layout.screen.mob} {
                    display: flex;
                    justify-content: center;
                }

                p {

                    // line-height: 200%;
                    // color: #3B3D41;

                    font-family: SF Pro Display;
                    font-style: normal;
                    font-weight: normal;
                    font-size: 13px;
                    line-height: 177%;
                    letter-spacing: 1px;
                    a {
                        color: inherit;
                        font-size: inherit;
                        font-family: inherit;
                        font-style: inherit;
                        font-weight: inherit;
                        line-height: inherit;
                    }
                }



            }

        }
    }

`;


const TestFooter = ({ state, data, actions, libraries}) => {

    const Html2React = libraries.html2react.Component;
 
    return (
        <Wrapper>
            {
                // data && data.cards && data.cards.map((elem, index)=>(
                //     <div className="swiper-card-wrapper" key={index}>
                //         <div className={`swiper-card ${activeSlideIndex == index ? 'active' : ''}`}>
                //             <img src={elem?.image?.url} />
                //             <div className="text-container">
                //                 <h4>{elem.heading}</h4>
                //                 <p>{elem.description}</p>
                //                 {elem.buttons && elem.buttons.length > 0 ? <Buttons buttons={elem.buttons}/> : <></>}
                //             </div>
                //         </div>
                //     </div>
                // ))
            }

            <Container padding={'level1'}>
                <div className="inner-section">
                    <div className="section1 bottom-border">
                        
                            {
                                data?.linkColumns?.map((elem, index)=>(
                                    <div className="links-column">
                                        {
                                            elem?.linksCollections?.map((elem,index)=>(
                                                <div className="links-collection">
                                                    <h6>{elem?.heading}</h6>
                                                    {
                                                        elem?.links?.map((elem,index)=>(
                                                            <a href={elem.link || 'javascript:void(0)'}><p className="small">{elem.linkText || ''}</p></a>
                                                        ))
                                                    }
                                                </div>
                                            ))
                                        }
                                    </div>
                                ))
                            }
                        

                        <div className="right-section">
                            <p>{data?.sectionRight?.description}</p>
                            <img src={data?.sectionRight?.image?.url || ''}/>
                        </div>

                    </div>
                    

                    {/* <div className="language-downloads bottom-border">
                        <div className="language"></div>

                        {
                            data?.featuredDownloads?.length > 0 && 
                            <div className="downloads">
                                <h6>Featured Downloads</h6>
                                {
                                    data?.featuredDownloads?.map((elem, index)=>(
                                        <span className="download-link-wrapper">
                                            <span className="block"></span>
                                            <a href={elem.link || 'javascript:void(0)'}><p className="small">{elem.linkText || ''}</p></a>
                                        </span>
                                    ))
                                }
                            </div>
                        }
                    </div> */}

                    <div className="logos-disclaimer">
                        <div className="logos">
                            {data?.socialLinks?.map((elem, index)=>(
                                <Logo image={elem.image} altText={elem.altText} link={elem.link}/>
                            )
                            )}
                        </div>
                        <div className="disclaimer">
                            <div className="text-wrapper">
                                <p class="small">{<Html2React html={data?.desclaimerText || ''} />}</p>
                            </div>
                        </div>
                        <div className="disclaimer-mobile">
                            <div className="text-wrapper">
                                <p>{<Html2React html={data?.desclaimerTextMobile || data?.['desclaimerText Mobile']  || ''} />}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </Container>




        </Wrapper>
    )
}

export default connect(TestFooter)



const LogoWrapper = styled.span`
    padding-right: 6px;
    img {
        width: 18px;
        height: 18px;
    }
`;

const Logo = ({link, image, altText}) => {
    return (
        <LogoWrapper>
            <a href={link || 'javascript:void(0)'}>
                <img src={image?.url} alt={altText || ''}/>
            </a>
        </LogoWrapper>
    )
}