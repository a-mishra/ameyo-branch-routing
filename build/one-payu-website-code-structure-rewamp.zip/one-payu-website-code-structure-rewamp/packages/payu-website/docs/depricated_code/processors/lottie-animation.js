import React from 'react'
import LottieAnimation from '../components/misc/widget/lottie/lottie'

const AnimationWrapper = (props) => {
    return (
        <LottieAnimation
            lottie={props.media.url} 
            loopStartFrame={Number(props && props.settings && props.settings.loopStartFrame)> 0 ? Number(props && props.settings && props.settings.loopStartFrame) : 1} 
            onHover={props && props.settings && props.settings.onHover || false} 
            autoPlay={props && props.settings && props.settings.autoPlay || false} 
            autoPlayLoop={props && props.settings && props.settings.autoPlayLoop || false}
            unInterruptedPlay={props && props.settings && props.settings.unInterruptedPlay || false}
            height={Number(props && props.settings && props.settings.height) > 0 ? `${Number(props && props.settings && props.settings.height)}px`: 'auto'} 
            width={Number(props && props.settings && props.settings.width) > 0 ? `${Number(props && props.settings && props.settings.width)}px`: 'auto'} 
            onScreenOffset={`${props && props.settings && props.settings.onScreenOffset || '0' }px`}
            debug={props && props.settings && props.settings.debug || false}
        />
    )
}


const lottie_animation = {
    name: 'lottie-animation',
    priority: 20,
    test: ({ component, props }) => component === "div" && props.className.split(" ").includes("opw-lottie-animation"),
    processor: ({ node,props }) => {

      const data = JSON.parse(node && node.children && node.children[0] && node.children[0].children && node.children[0].children[0] && node.children[0].children[0].content || '{}') ;

      const id = data && data.id || '';
      const media = data && data.media  || {};
      const settings = data && data.settings || {} ;

        return {
          component: AnimationWrapper,
          props: { id, media, settings },
        }
      },
}

export default lottie_animation;