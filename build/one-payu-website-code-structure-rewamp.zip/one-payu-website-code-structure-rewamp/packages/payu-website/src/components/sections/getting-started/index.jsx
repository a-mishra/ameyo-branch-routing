import React, {  useRef, useEffect, useState, useLayoutEffect } from 'react'
import { connect, styled , Global, css} from 'frontity';
import {layout, SectionAnimation} from '../../../utils/constants';
import {useOnScreen, useWindowDimentions, useContainerDimensions} from '../../../utils/hooks/usehooks'
import { Section, Row, Col, Container } from '../../misc/layout';
import { motion, useMotionValue, useAnimation } from "framer-motion";
import { Swiper } from './Swiper'

const SectionWrapper = styled.div`
    min-height: 300px;
    position: relative;
    overflow-x: clip;
    
    .texts {
        margin-bottom: 4rem;
        ${layout.screen.mob} {
            margin-bottom: 3.5rem;
        }
        p {
            margin-top: 1rem;
        }
    }
`;


const SectionGettingStarted = ({state, actions, data, libraries}) =>  {

    const ref = useRef(null)
    const [onScreen, portionInView, viewed] = useOnScreen(ref, "0px");
    const Html2React = libraries.html2react.Component;
    const [sectionWidth , setSectionWidth] = useState(0);

    useEffect(() => {
        actions.intraPageLinks.update(data?.section?.internalLink, portionInView);
        return () => {
            actions.intraPageLinks.update(data?.section?.internalLink, 0);
        }
    }, [portionInView])

    const handleAnimationCompleted = () => {
        let innerWidth = ref?.current?.clientWidth;
        setSectionWidth(innerWidth);
    }

    useEffect(() => {
        handleAnimationCompleted();
        window.addEventListener("resize", handleAnimationCompleted)
        window.addEventListener("orientationchange", handleAnimationCompleted)
        
        return () => {
          window.removeEventListener("resize", handleAnimationCompleted)
          window.removeEventListener("orientationchange", handleAnimationCompleted)
        }
      }, []);
    

    return (
        <>
            <SectionWrapper id={data?.section?.internalLink}>
                <Section style={{marginBottom: 'unset', minHeight:'unset'}}  padding={'level4'}  >
                    <motion.div 
                        className="texts"
                        ref={ref}
                        variants={SectionAnimation}
                        initial={'hidden'}
                        animate={viewed ? 'show' : 'hidden'}
                        transition={{
                            ...SectionAnimation.transition(0, true)
                        }}
                        // onAnimationComplete={handleAnimationCompleted}
                        // onAnimationEnd={handleAnimationCompleted}
                    >
                        <h3 className='h2'>{data.heading}</h3>
                        {data.description && <p className='body2'>{data.description}</p>}
                    </motion.div>
                </Section>
                <Swiper data={data && data.cards || []}  sectionWidth={sectionWidth} viewed={viewed}/>
            </SectionWrapper>
        </>
    )

}

export default connect(SectionGettingStarted)




