import React, {  useRef, useEffect, useState, useLayoutEffect } from 'react'
import { connect, styled , Global, css} from 'frontity';
import {layout, SectionAnimation} from '../../../utils/constants';
import {useOnScreen, useWindowDimentions, useContainerDimensions} from '../../../utils/hooks/usehooks'
import { Section, Row, Col, Container } from '../../misc/layout';
import { motion, useMotionValue, useAnimation, AnimatePresence } from "framer-motion";
import Animation from './animation';
import { useInterval } from "usehooks-ts";
import MobileAnimationContainer from './mobile-animation-container';
import { Swiper } from './Swiper';
import {getAnimDimentions} from '../../../utils/methods';


const SectionWrapper = styled.div`
    min-height: 300px;
    position: relative;
    overflow-x: clip;
    height: 100%;

    .section-container {
        // ${layout.screen.md} {
            padding-top: 0px;
        // }

        padding-bottom: 48px;
        ${layout.screen.mob} {
            padding-bottom: 0px;
        }
    }

    // height: ${(props)=>(props.animHeight)}px;
    ${layout.screen.mob} {
        height: unset;
    }
    
    .section-inner {
        display: flex;
        flex-direction: row;
        position: relative;
        height: ${(props)=>(props.animHeight)}px;
        ${layout.screen.mob} {
            height: unset;
        }

        .text-cards-container {
            width: 50%;
            //min-height: ${layout.reponsiveCssValue(354, 470, 1200, 354, 1600, 470)};
            ${layout.screen.mob} {
                width: 100%;
            }

            .texts {
                // max-width: 550px;
                ${layout.screen.mob} {
                    max-width: 100%;
                }
                justify-content: center;
                align-items: flex-start;
                display: flex;
                flex: 1;
                flex-direction: column;

                p {
                    margin-top: 0.5rem;
                }
                margin-bottom: ${layout.reponsiveCssValue(40, 74, 1440, 60, 1600, 74)};
                margin-top: ${layout.reponsiveCssValue(42, 80, 1440, 72, 1600, 80)};
                padding-top: ${layout.reponsiveCssValue(42, 80, 1440, 72, 1600, 80)};

                ${layout.screen.mob} {
                    // margin-bottom: ${layout.reponsiveCssValue(24, 48, 375, 24, 1400, 48)};
                    margin-top: 0px;
                    margin-bottom: 0px;
                    padding-top: 0px;
                }
            }
            .cards-container-wrapper {
                display: flex;
                align-items: flex-start;
                min-height: ${layout.reponsiveCssValue(250, 370, 1440, 300, 1600, 370)};
                
                

                ${layout.screen.mob} {
                    display: none;
                }
                

                &.headless {
                    height: 100%;
                    min-height: ${layout.reponsiveCssValue(250, 370, 1440, 300, 1600, 370)};
                    align-items: center;
                }
                .cards-container {
                    display: flex;
                    justify-content: space-evenly;
                    align-items: flex-start;
                    flex-direction: row;
                    flex-wrap: wrap;
                    column-gap: ${layout.reponsiveCssValue(12, 16, 1200, 12, 1600, 16)};
                    row-gap: ${layout.reponsiveCssValue(36.93, 48, 1200, 36.93, 1600, 48)};
                    margin-top: 0rem;
                    display: grid;
                    grid-template-columns: ${(props)=>(props.isLarge ? '1fr' : '1fr 1fr')};
                    align-items: center;
                    justify-items: center;
                }
            }
            

        }

        .animation-container {

            flex: 1;
            display: flex;
            justify-content: flex-end;
            align-items: flex-end;

            position: absolute;
            left: 50%;
            top: 0;
            bottom: 0;
            right: 0;
            overflow: none;

            ${layout.screen.mob} {
                display: none;
            }
            
            .animation-wrapper {
                position: absolute;
                top:0;
                bottom: 0;
                left: 0;
                right: 0;

                overflow: visible;
                .xyz {
                    position: absolute;
                    top:50%;
                    transform: translate(0%, -50%);
                    width: 100%;
                    display: flex;
                    justify-content: flex-end;
                    align-items: flex-end;
                }
            }
        }



    }

    .thread-image {
        width: 100%;
        position: absolute;
        top: 5rem;
        z-index: -1;
    }

`;


const SectionProductFeatures = ({state, actions, data, libraries}) =>  {

    const ref = useRef(null)
    const [onScreen, portionInView, viewed] = useOnScreen(ref, "0px");

    const TextCardsContainerRef = useRef(null);
    const [ containerTextCardDimentionFlag, setcontainerTextCardDimentionFlag] = useState(false);
    const TextCardContainerDimention = useContainerDimensions(TextCardsContainerRef, containerTextCardDimentionFlag);

    const Html2React = libraries.html2react.Component;

    const [page, setpage] = useState(0);
    const [delay, setDelay] = useState(data?.settings?.cardSwitchInterval ? Number(data?.settings?.cardSwitchInterval)*1000 :  10000 );
    const [timerRunning, setTimerRunning] = useState(true);

    useInterval(
        () => {
            let range = data?.buttons?.length ;
            if(range)
                setpage(((page+1) % range));
        },
        timerRunning ? delay : null
    );

    useEffect(() => {
        setTimerRunning(onScreen);
    }, [onScreen])

    const handleIconCardSelection = (index) => {
        setCount(index+1)
    }

    useEffect(() => {
        actions.intraPageLinks.update(data?.section?.internalLink, portionInView);
        return () => {
            actions.intraPageLinks.update(data?.section?.internalLink, 0);
        }
    }, [portionInView])


    const reCalculateContainerWidth = () => {
        setcontainerTextCardDimentionFlag(!containerTextCardDimentionFlag);
    }


    const [windowWidth, setwindowWidth] = useState(0);
    const [animWidth, setanimWidth] = useState(0);
    const [animHeight, setanimHeight] = useState(0);
        const handleResize = () => {
        if(window?.innerWidth) {
            setwindowWidth(window.innerWidth);
            let animDimentions = getAnimDimentions('640x800', window.innerWidth);
            setanimWidth(animDimentions.width);
            setanimHeight(animDimentions.height);
        }
    }

    useEffect(() => {
        handleResize();
        window.addEventListener("resize", handleResize)
        window.addEventListener("orientationchange", handleResize)
        
        return () => {
        window.removeEventListener("resize", handleResize)
        window.removeEventListener("orientationchange", handleResize)
        }
    }, [])

    const isLarge = data?.settings?.cardSize?.value == 'large' ? true : false 

    return (
        <>
            <SectionWrapper id={data?.section?.internalLink} animHeight={animHeight} isLarge={isLarge}>
                <Section padding={'level4'} className="section-container section-features">
                            <motion.div 
                                className="section-inner"
                                ref={ref}
                            >

                                <div 
                                    className="text-cards-container"
                                    ref={TextCardsContainerRef}
                                > 
                                    {
                                    (data?.heading || data?.description) &&
                                    <motion.div className="texts"
                                        variants={SectionAnimation}
                                        initial={'hidden'}
                                        animate={viewed ? 'show' : 'hidden'}
                                        transition={{ 
                                            // duration: 0.8, 
                                            // delay: 0.0, 
                                            ...SectionAnimation.transition(0, true)
                                        }}
                                    >
                                        <h2 className="h2">{<Html2React html={data?.heading || ''} />}</h2>
                                        <p className="body2">{<Html2React html={data?.description || ''} />}</p>
                                    </motion.div>
                                    }

                                    <MobileAnimationContainer  animWidth={animWidth} animHeight={animHeight} viewed={viewed} data={data} onScreen={onScreen} page={page} />

                                    <div className={`cards-container-wrapper ${(data?.heading || data?.description) ? '' : 'headless'}`}>
                                        <motion.div 
                                            className={'cards-container'}
                                            variants={SectionAnimation}
                                            initial={'hidden'}
                                            animate={viewed ? 'show' : 'hidden'}
                                            transition={{ 
                                                // duration: 0.5, 
                                                // delay: 0.7,
                                                ...SectionAnimation.transition(1)
                                            }}
                                            onAnimationComplete={reCalculateContainerWidth}
                                            onAnimationEnd={reCalculateContainerWidth}
                                        >
                                            {data?.buttons?.map((elem, index)=>(
                                                <Card 
                                                {...elem} 
                                                page={page} 
                                                index={index} 
                                                onClick={()=>{setpage(index)}}
                                                isLarge={isLarge}
                                                setTimerRunning={setTimerRunning}
                                                />
                                            ))}
                                        </motion.div>
                                    </div>

                                </div>

                                <motion.div className="animation-container"
                                    variants={SectionAnimation}
                                    initial={'hidden'}
                                    animate={viewed ? 'show' : 'hidden'}
                                    transition={{ 
                                        // duration: 0.5, 
                                        // delay: 1.1,
                                        ...SectionAnimation.transition(2)
                                    }}
                                >
                                    <motion.div className="animation-wrapper"
                                        variants={SectionAnimation}
                                        initial={{x:0}}
                                        animate={{x:TextCardContainerDimention.width*.075}}
                                        transition={{ 
                                            duration: 0.2, 
                                        }}
                                    >

                                            {data?.buttons?.map((elem, index)=>(
                                                <div className="xyz">
                                                <AnimatePresence>
                                                    {page == (index) && (
                                                        <motion.div
                                                            initial={{
                                                                opacity: 0, y: 60, scale: 0.95, 
                                                            }}
                                                            animate={{ opacity: 1, y:0, scale: 1 ,
                                                                transition: {
                                                                    delay: 0.7,
                                                                    duration: 0.8
                                                                }
                                                            }}
                                                            exit={{ opacity: 0, y: 60, scale: 0.95 ,
                                                                transition: {
                                                                    delay: 0,
                                                                    duration: 0.8
                                                                } 
                                                            }}
                                                            
                                                        >
                                                            <Animation 
                                                                {...elem}
                                                                lottie={elem?.media?.data?.animation}
                                                                animationText={elem?.media?.data}
                                                                inView={onScreen}
                                                                onLoad={()=>{}}
                                                                // height={TextCardContainerDimention.height}
                                                                // width={TextCardContainerDimention.width}
                                                                height={animHeight || 'auto'}
                                                                width={animWidth || 'auto'}
                                                            />
                                                        </motion.div>
                                                    )}
                                                </AnimatePresence>
                                                </div>
                                            ))}

                                    </motion.div>
                                    
                                </motion.div>

                            </motion.div>
                </Section>
                <Container>
                    <motion.div
                    variants={SectionAnimation}
                    initial={'hidden'}
                    animate={viewed ? 'show' : 'hidden'}
                    transition={{ 
                        // duration: 0.5, 
                        // delay: 1.1,
                        ...SectionAnimation.transition(2)
                    }}>
                        <Swiper data={data && data.buttons || []} page={page} setpage={setpage}/>
                    </motion.div>
                </Container>
            </SectionWrapper>
        </>
    )

}

export default connect(SectionProductFeatures)



const CardWrapper = styled.div`
    display: flex;
    flex-grow: 1;
    // flex-basis: ${(props)=>(props.isLarge ? '400px' : '200px')};
    height: 100%;
    width: 100%;

    .card {

        background-color: rgba(255, 255, 255, 0.4);
        border: solid 2px rgba(255, 255, 255, 0.72);
        border-radius: ${layout.reponsiveCssValue(12, 20, 1440, 16, 1600, 20)};
        box-sizing: border-box;
        cursor: pointer;
        max-width: ${layout.reponsiveCssValue(360, 528, 1440, 440, 1600, 528)};
        opacity: 1;//0.72;
        padding-left: ${layout.reponsiveCssValue(12, 20, 1440, 16, 1600, 20)};
        padding-right: ${layout.reponsiveCssValue(12, 20, 1440, 16, 1600, 20)};
        padding-top: ${layout.reponsiveCssValue(10, 15, 1440, 12, 1600, 15)};
        padding-bottom: ${layout.reponsiveCssValue(10, 15, 1440, 12, 1600, 15)};
        display: flex;
        flex-direction: row;
        align-items: center;
        flex-grow: 1;
        // gap: 12px; // flex->gap safari <14.1 fix

        &.islarge {
            padding-right: 100px;
        }

        .icon {
            width: ${layout.reponsiveCssValue(48, 66, 1440, 55, 1600, 66)};
            height: ${layout.reponsiveCssValue(48, 66, 1440, 55, 1600, 66)};
            border: solid 1px white;
            background: #ffffffdd;
            border-radius: 50%;
        
            display: flex;
            justify-content: center;
            align-items: center;

            img {
                width: ${layout.reponsiveCssValue(27, 35, 1200, 27, 1600, 35)};
            }
        }
        
        .card-texts {
            display: flex;
            flex: 1;
            align-items: center;
            opacity: 1;
            &:hover {
                opacity: 1;
            }

            h3 {
                color: #2F695D;
            }

            &.large {

            }
            transition: opacity 0.2s ease-in;
        }
    }

    .card > div {
        &:not(:last-child) {
            margin-right: 12px; // flex->gap safari <14.1 fix
        }
    }

    .active {
        .card-texts {
            opacity: 1;
            h3 {
                color: #1D6F5E;
            }
        }
    }



`;

const Card = ({card, index, page, onClick, isLarge, setTimerRunning}) => {
    const CardsAnimations = {
        hidden: { opacity: 0.2, scale: 0.9 },
        show: {
            opacity: 1,
            //0.72
            scale: 1,
            backgroundColor: 'rgba(255  255 255 0.4)',
            transition: {
                staggerChildren: 0.1,
                delayChildren: 0.3,
            },
            border: '2px solid rgba(255 255 255 .9)'
        },
        showActive: {
            opacity: 1,
            scale: 1,
            // boxShadow: 'rgba(186 223 197 .4) 0px 8px 24px',
            boxShadow: 'rgba(186 223 197 .3) 0px 16px 24px 0px',
            zIndex: 10,
            color: '#fff',
            backdropFilter: 'blur(4px)',
            backgroundColor: 'rgba(255 255 255 0.6)',
            border: '2px solid rgba(255 255 255 0.72)'
        }
    }

    const CardsNumberedIconAnimation = {
        active: {
            scale: 1.1,
            background: '#00AB88',
        },
        inactive: {
            background: '#ffffffdd',
        }
    }
    return (
        <CardWrapper isLarge={isLarge}>
            <motion.div
                onTap={(event) => {
                        event.preventDefault();
                        event.stopPropagation()
                        onClick();
                    }}
                onHoverStart={(event)=>{
                    // event.preventDefault();
                    // event.stopPropagation();
                    // onClick();
                    // setTimerRunning(false);
                }}
                onHoverEnd={()=>{
                    // setTimerRunning(true);
                }}
                whileHover={{
                    scale: 1.05,
                    // boxShadow: 'rgba(20 20 22 .16) 0px 8px 24px',
                    boxShadow: 'rgba(186 223 197 .4) 0px 16px 24px 0px',
                    zIndex: 20,
                    transition: { ease: 'anticipate', duration: 0.250 },
                    backdropFilter: 'blur(4px)',
                    opacity: 1,
                    }}
                whileTap={{ scale: 0.95 }}
                className={`card ${page==index && 'active'} ${isLarge == true && 'islarge'}`}
                variants={CardsAnimations}
                initial={'hidden'}
                animate={page==index ? 'showActive' : 'show'}
                transition={{ duration: 0.250, delay: 0.0 }}
            >
                {card?.icon?.url && <div className="icon">
                    <img src={card?.icon?.url} />
                </div>
                }
                <div className="card-texts">
                    {
                        isLarge ?
                            <h3 className="h5">{card?.title}</h3>
                        :
                            <h3 className="h6">{card?.title}</h3>
                    }
                    
                </div>

            </motion.div>
        </CardWrapper>

    )
}