import React, {  useRef, useEffect, useState, useLayoutEffect } from 'react'
import { connect, styled , Global, css} from 'frontity';
import { useInterval } from "usehooks-ts";
import {layout} from '../../../utils/constants';
import {useOnScreen, useWindowDimentions} from '../../../utils/hooks/usehooks'
import SequenceReveal from '../sequence-reveal'
import {ParallaxBox} from '../parallax-box'

import Slider from "react-slick";
import SlickCSS from "slick-carousel/slick/slick.css";
import SlickTheme from "slick-carousel/slick/slick-theme.css";
import { NavArrow } from '../../../utils/icons';

import NavArrowLeftIcon from '../../../assets/icons/nav_arrow_left.svg'
import NavArrowRightIcon from '../../../assets/icons/nav_arrow_right.svg'
import { Container, Section } from '../../misc/layout';

const ButtonWrapper = styled.div`
    display: grid;
    grid-gap: 36px;
    grid-template-columns: 1fr 1fr;
    margin-top: 74px;

    @media only screen and (max-width: 1200px) and (min-width: 768px) {
        grid-template-columns: 1fr;
        margin-top: 0px;
        grid-gap: 0px;
    }


`;

const SectionWrapper = styled.div`
    .bl-bx {
        // padding-top: 64px;
    }


    min-height: 300px;

`;

const NavArrowWrapper = styled.div`
    cursor: pointer;
    width: 36px;
    height: 36px;
    background: rgba(255, 255, 255, 0.72);
    opacity: 0.48;
    box-shadow: inset 1.65467px 1.65467px 1.65467px rgba(255, 255, 255, 0.25);
    backdrop-filter: blur(26.4748px);
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;

    img {
        height: 14px;
        width: auto;
    }
`;

export const NextArrowButton = (props) => {

    const handleClick = (event) => {
        event.stopPropagation();
        event.preventDefault();
        props.onClick();
    }

    return(
        <NavArrowWrapper className="slick-arrow slick-prev" onClick={handleClick}>
            <img src={NavArrowLeftIcon}/>
        </NavArrowWrapper>
    )
}

export const PrevArrowButton = (props) => {
    const handleClick = (event) => {
        event.stopPropagation();
        event.preventDefault();
        props.onClick();
    }
    return(
        <NavArrowWrapper className="slick-arrow slick-next" onClick={handleClick}>
            <img src={NavArrowRightIcon}/>
        </NavArrowWrapper>
    )
}

const SectionBusinessUsecases = ({state, actions, data, libraries}) =>  {

    const [count, setCount] = useState(1);
    const [delay, setDelay] = useState(data?.cards?.settings && data?.cards?.settings?.cardSwitchInterval ? Number(data?.cards?.settings?.cardSwitchInterval)*1000 :  10000 );
    const [isPlaying, setPlaying] = useState(true);

    const ref = useRef(null);
    const [onScreen, portionInView] = useOnScreen(ref, "0px");

    useEffect(() => {
        actions.intraPageLinks.update(data?.section?.internalLink, portionInView);
        return () => {
            actions.intraPageLinks.update(data?.section?.internalLink, 0);
        }
    }, [portionInView])

    const windowDimentions = useWindowDimentions();

    useInterval(
        () => {
            let range = data?.cards?.data && data?.cards?.data.length;
            if(range)
            setCount((count % range) + 1);
        },
        // Delay in milliseconds or null to stop it
        isPlaying ? delay : null
    );

    const Html2React = libraries.html2react.Component;


    const sliderDesktop = useRef(null);
  const sliderMobile = useRef(null);


  const nextSlide = () => {
    sliderMobile && sliderMobile.current.slickNext();
  }

  const prevSlide = () => {
    sliderMobile && sliderMobile.current.slickPrev();
  }



  const sliderDesktopSettings = {
    dots: false,
    infinite: true,
    slidesToShow: 3,
    slidesToScroll: 1,
    nextArrow: <NextArrowButton onClick={prevSlide} />,
    prevArrow: <PrevArrowButton onClick={nextSlide} />,
    speed: 1000,
    easing: 'easeInOut',
    adaptiveHeight: false,
    swipeToSlide: true,
    responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 3,
            infinite: true,
            dots: true
          }
        },
        {
          breakpoint: 600,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 2,
            initialSlide: 2
          }
        },
        {
          breakpoint: 480,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1
          }
        }
      ]
  }

  const sliderMobileSettings = {
    dots: true,
    infinite: true,
    slidesToShow: 3,
    slidesToScroll: 1,
    dots: false,
    speed: 500,
    fade: true,
    swipeToSlide: true,
    vertical: true,
    verticalSwiping: true,
    variableWidth: true,
  }

    return (
    <>
    <Global styles={css([SlickCSS, SlickTheme ])} />


    <SectionWrapper ref={ref}>
    {/* // easing = "easeInOut", // [number, number, number, number] | "linear" | "easeIn" |
  //"easeOut" | "easeInOut" | "circIn" | "circOut" | "circInOut" | "backIn" | "backOut" |
  //"backInOut" | "anticipate" | EasingFunction; */}
        <ParallaxBox fadeOut={false} easing={'backInOut'}>
            <SequenceReveal sequence={0} inView={onScreen}>
                <StyledSection>
                        <div class="container">
                            <div class="row">

                                {/* heading and subheading */}
                                <Container>
                                <div class="col-lg-12">
                                        <div class="bl-bx">
                                            <SequenceReveal sequence={1} inView={onScreen}>
                                                <h3 class="coms-title">{<Html2React html={data?.heading} />}</h3>
                                            </SequenceReveal>
                                            <SequenceReveal sequence={2} inView={onScreen}>
                                                <p class="coms-subtitle">{<Html2React html={data?.subheading} />}</p>
                                            </SequenceReveal>
                                            
                                        </div>
                                </div>
                                </Container>
                                
                                <div class="col-lg-12">
                                    <SequenceReveal sequence={3} inView={onScreen}>
                                        <SliderWrapperDesktop>
                                            <Slider {...sliderDesktopSettings} ref={sliderDesktop}>
                                                {
                                                    data && data.cards && data.cards.data &&data.cards.data.map((elem, index)=>(
                                                        <BusinessCard title={elem?.title}  description={elem?.description} image={elem.icon} link={elem.link}/>
                                                    ))
                                                }
                                            </Slider>
                                        </SliderWrapperDesktop>
                                        <SliderWrapperMobile>
                                            <Slider {...sliderMobileSettings} ref={sliderMobile}>
                                                {
                                                    data && data.cards && data.cards.data &&data.cards.data.map((elem, index)=>(
                                                        <BusinessCard title={elem?.title}  description={elem?.description} image={elem.icon} link={elem.link}/>
                                                    ))
                                                }
                                            </Slider>
                                            <div>
                                                <button onClick={prevSlide}>Previous</button>
                                                <button onClick={nextSlide}>Next</button>
                                            </div>
                                        </SliderWrapperMobile>
                                    </SequenceReveal>
                                </div>


                            </div>
                        </div>
                </StyledSection>
            </SequenceReveal>
        </ParallaxBox>
    </SectionWrapper>
    </>
    )

}

export default connect(SectionBusinessUsecases)


const NavContainer = styled.div`

`;

const NavButtonWrapper = styled.div`

`;


const StyledSection = styled(Section)`
    // padding: 3rem 0px;
    position: relative;
    min-height: 600px;

    .coms-title {
        font-size: 2.25rem;
        line-height: 3.625rem;
        color:  #0E342C;
        font-family: 'Roboto Slab';
        margin-bottom: 24px;
        
        font-family: Roboto Slab;
        font-style: normal;
        font-weight: 500;
        font-size: 23.1654px;
        line-height: 36px;
        color: #141416;
        

        .cs-hgl-text {
            color: #2F695D;
        }
    }
    
    .coms-subtitle {
        font-family: SF Pro Display;
        font-style: normal;
        font-weight: 400;
        font-size: 1rem;
        line-height: 1.625rem;
        letter-spacing: 0.827336311340332px;
        color:  #314235;

        font-family: SF Pro Display;
font-size: 17px;
font-style: normal;
font-weight: 400;
line-height: 26px;
letter-spacing: 0.827336311340332px;
text-align: left;
// margin-bottom: 56px;
    }

    ${layout.screen.mobile} {
        padding: 7.5rem 0 0;
        position: relative;
    }

    ${layout.screen.smallScreen} {
        padding: 5.6rem 0 0;
        position: relative;
        .coms-title {
            font-size: 1.5rem;
            line-height: 1.75rem;
            margin-bottom: 1.5rem;
        }
        .coms-subtitle {
            padding-bottom: 1.25rem;
            margin-bottom: 0;
        }
    }
`;


const AnimationContainer = styled.div`
    position: relative;
    z-index: 10;
`;



const AnimationTextWrapper = styled.div`
    z-index: 20;
    width: 80%;
    padding: 4px 16px;
`;

const SliderWrapperDesktop = styled.div`
    display: block;
    margin-top: 56px !important;
    .slick-list {
        margin: 0px 1rem!important;
    }

    .slick-prev:before {
        content: ''!important;
    }
    .slick-next:before {
        content: ''!important;
    }


    ${layout.screen.xs} {
        display: none;
    }

    ${layout.screen.sm} {
        display: block;
    }


`;

const SliderWrapperMobile = styled.div`
    display:none;
    margin: 56px auto !important;

    ${layout.screen.xs} {
        display: block;
    }
    
    ${layout.screen.sm} {
        display: none;
    }
`;

export const BusinessCard = ({image, title, description, link }) => {
    return (
        <BusinessCardWrapper>
            <ImageWrapper>
                {image?.url && <img src={image.url}/>}
            </ImageWrapper>
            <h3>{title}</h3>
            <p>{description}</p>
            {
                link && 
                <a href={link}>{'EXPLORE >'}</a>
            }

            <FauxShadowContainer/>
        </BusinessCardWrapper>
    )
}

const BusinessCardWrapper = styled.div`

    display: flex;
    flex-direction: column;
    position: relative;

    // width: min( 100%, 330px );

    max-width: min( 100%, 350px );
    margin: auto;
    padding: 0px 1.5rem;

    h3 {
        font-family: Roboto Slab;
        font-style: normal;
        font-weight: 500;
        font-size: 1.25rem;
        line-height: 162%;
        /* identical to box height, or 160% */


        /* Dark Green */

        color: #0E342C;
        margin-top: 30px;
    }

    p {
        font-family: SF Pro Display;
font-style: normal;
font-weight: normal;
font-size: 1rem;
line-height: 162%;
/* or 162% */

letter-spacing: 0.827336px;

/* Text 3 */

color: #2F695D;
margin-top: 16px;
min-height: 100px;

    }

    a {
        font-family: SF Pro Display;
font-style: normal;
font-weight: 600;
font-size: 13px;
line-height: 162%;
/* or 150% */

letter-spacing: 0.827336px;

/* Accent 1 */

color: #00AB88;
margin-top: 16px;
margin-bottom:72px;
    }



`;

const ImageWrapper = styled.div`
display: flex;
juustify-content: center;
align-items: center;
place-self: center;
max-width: 100%;
img {
    max-width: min( 296px, 100% );
    height: auto;
    width: auto
}
`;


const FauxShadowContainer = styled.div`

    position: absolute;
    bottom: 19px;
    height: 12px;
    width: calc( 100% - 3rem);
    background: #b0b0b016;
    border-radius: 40%;
    z-index: -10;
    margin: 0px auto;
    box-shadow: rgba(149, 157, 165, 0.2) 0px 0px 24px;
`;

