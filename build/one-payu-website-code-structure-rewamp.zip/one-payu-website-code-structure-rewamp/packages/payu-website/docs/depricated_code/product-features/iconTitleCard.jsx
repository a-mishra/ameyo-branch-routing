import React from 'react'
import { styled, connect } from 'frontity';
import {layout, colors} from '../../../utils/constants';

const WhiteCircle = styled.div`
    width: 54px;
    height: 54px;
    border: solid 1px white;
    background: #ffffffdd;
    border-radius: 50%;

    display: flex;
    justify-content: center;
    align-items: center;

    img {
        width: 32px;
    }

    
`;


const IconTitleCard = ({url, title, icon, isActive, state,libraries, onClick}) => {
    const Html2React = libraries.html2react.Component;

    return (
        <ButtonContainer className={isActive ? 'active' : ''} isActive={isActive} onClick={onClick}>
            <a href="javascript:void(0)" class="com-btn outline-btn outline-icon-btn w-auto align-items-center justify-content-left">
                <i class="btn-icon">
                    <WhiteCircle><img src={icon && icon.url} /></WhiteCircle>
                </i>
                <span>{<Html2React html={title} />}
                </span>
            </a>
        </ButtonContainer>
    )
}

export default connect(IconTitleCard)

const ButtonContainer = styled.div`
width: fit-content;
    .com-btn {
        display: flex;
        width: auto;
        min-width: 254px;
        padding: 1rem 1rem;
        color: #fff;
        font-size: 16px;
        line-height: 26px;
        text-decoration: none;
        margin-bottom: 12px;
        text-align: center;
        font-family: 'Roboto Slab', serif;
        -webkit-transition: 0.4s ease-in-out;
        transition: 0.4s ease-in-out;

        background: rgba(255, 255, 255, 0.4);
        border: 1.65467px solid #FFFFFF;
        box-sizing: border-box;
        border-radius: 20px;
        width: fit-content;

        ${layout.screen.xs} {
            border-radius: 28px;
            margin: auto 0.5rem;
            background: rgba(255, 255, 255, 0.6);
            border: 2px solid rgba(255, 255, 255, 0.72);
            box-sizing: border-box;
            backdrop-filter: blur(4px);
            border-radius: 28px;
        }

        ${layout.screen.small} {
            border-radius: 28px;
            margin: auto 0.5rem;
            background: rgba(255, 255, 255, 0.6);
            border: 2px solid rgba(255, 255, 255, 0.72);
            box-sizing: border-box;
            backdrop-filter: blur(4px);
            border-radius: 28px;
        }


        ${layout.screen.lg} {
            margin: auto auto;
            border-radius: 20px;
            padding: 1rem 1rem;
            background: rgba(255, 255, 255, 0.4);
            border: 1.65467px solid #FFFFFF;
            box-sizing: border-box;
            border-radius: 20px;

        }


        :hover {
            color: #fff;
        }
        ${props => props.isActive && 'color: #fff;backdrop-filter: blur(4px);box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;'}


        &.com-btn-secondary {
            background: #fff;
            color: #2F695D;
        }

        &.outline-btn {
            background: rgba(255, 255, 255, 0.4);
            border:rgba(255, 255, 255, 0.72) 2px solid;
            color: #00AB88;
            font-size: 0.875rem;
            line-height: 1.5rem;
            letter-spacing: 0;
            font-weight: 700;
            padding: 0.75rem 0.75rem;
            border-radius: 0.75rem;
            font-family: 'Roboto Slab', serif;
            &:hover {
                background: #ffffff;
                color: #2F695D;
            }
            ${props => props.isActive && 'background: #ffffff; color: #2F695D;'}
        }

        &.outline-icon-btn {
            font-size: 16px;
            line-height: 26px;
            letter-spacing: 0;
            font-weight: 500;
            max-width: 500px;

            ${layout.screen.sm} {
                max-width: 300px;
            }
            ${layout.screen.lg} {
                max-width: 350px;
            }
            ${layout.screen.xl} {
                max-width: 450px;
            }
            ${layout.screen.xxl} {
                max-width: 500px;
            }


            text-align: left;
            // margin-bottom: 48px;
            font-family: 'Roboto Slab', serif;
            color: #2F695D;
            opacity: 72%;
            background: rgba(255, 255, 255, 0.4);

            font-family: Roboto Slab;
            font-style: normal;
            font-weight: 500;
            font-size: 13.2374px;
            line-height: 22px;
            /* or 162% */


            color: #2F695D;

            opacity: 0.72;
            &:hover {
                background: rgba(255, 255, 255, 0.6);
                color: #1D6F5E;
                opacity: 100%;
            }
            ${props => props.isActive && 'background: rgba(255, 255, 255, 0.6); color: #1D6F5E; opacity: 100%; backdrop-filter: blur(3.30935px);'}

            .btn-icon {
                margin-right: 16px;
            }
        }

        &.link-text-btn {
            color: #00AB88;
            background: none;
            border: none;
            border: none;
            padding: 0;
            margin: 0;
        }
        
    }

    .comp-slide-button {
        .swiper {
            // width: 600px;
            // height: 300px;
            margin: 0;
        }
        &.scroll-wrap-mob {
            width: 100%;
            overflow-x: scroll;
            .button-wrap {
                width: max-content;
                a {
                    margin-bottom: 20px;
                }
            }
        }
    }

    @media (max-width: 1198px) and (min-width: 1025px) {
        .com-btn {
            padding: 1rem 1.500rem;
            // margin: 0 6px 0 6px;
        }
    }

    ${layout.screen.tabOnly} {
        .com-btn {
            padding: 1rem 1.500rem;
            // margin: 0 6px 0 6px;
        }
    }

    ${layout.screen.mobile} {
        .com-btn {
            padding: 1rem 1.500rem;
            // margin: 0 6px 0 6px;
        }
    }


    // this is for 767px
    ${layout.screen.smallScreen} {
        .com-btn {
            padding: 1rem 1.24rem;
            &.outline-btn {
                font-size: 0.75rem;
                line-height: 1.75rem;
                font-weight: 600;
                padding: 0.438rem 1.25rem;
            }
            &.outline-icon-btn {
                font-size: 0.875rem;
                line-height: 1.25rem;
            }
            &.link-text-btn {
            font-size: 0.875rem;
            line-height: 1.5rem;
            }
        }   
        .comp-slide-button {
            .swiper {
                width: 630px;
                // height: 300px;
                margin: 0;
            }
            &.scroll-wrap-mob {
                width: 100%;
                overflow-x: scroll;
                .button-wrap {
                    width: max-content;
                }
        }
        } 
    }


`;