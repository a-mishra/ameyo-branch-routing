import * as React from "react";
import { useRef, useEffect, useState } from "react";
import { motion, useMotionValue, useAnimation } from "framer-motion";
// import { clamp, snap } from "@popmotion/popcorn";
import { InView } from "react-intersection-observer";
import {styled} from 'frontity'
import {layout, SectionAnimation} from '../../../utils/constants';
import { Container } from '../../misc/layout';

import NavArrowLeftIcon from '../../../assets/icons/arrow-left.svg'

// import NavArrowLeftIcon from '../../../assets/icons/nav_arrow_left.svg'
import NavArrowRightIcon from '../../../assets/icons/nav_arrow_right.svg'
import { useWindowDimentions } from "../../../utils/hooks/usehooks";

// const markerOffset = ["pixel", 200]; // percent | pixel
// const itemsMargin = 16;
// const swipeConfidenceThreshold = 100;
// const inactiveCardWidth = 400;
// const activeCardWidth = 700;
// const activeCardHeight = 500;
// const inactiveCardHeight= 470;

function useContainerConstraints(ref, markerOffset) {
  const [constraints, setConstraints] = useState({
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    markerLeft: 0,
    markerRight: 0,
    markerHorizontalCenter: 0
  });

  const setData = () => {
    const element = ref.current;
    const viewportHeight = element.offsetHeight;
    const contentHeight = element.firstChild.offsetHeight;
    const viewportWidth = element.offsetWidth;
    const contentWidth = element.firstChild.offsetWidth;

    const boundingBox = element.getBoundingClientRect();
    const markerLeft =
      boundingBox.left +
      (markerOffset[0] == "pixel"
        ? markerOffset[1]
        : markerOffset[1] * viewportWidth);
    const markerRight =
      boundingBox.right -
      (markerOffset[0] == "pixel"
        ? markerOffset[1]
        : markerOffset[1] * viewportWidth);
    const markerHorizontalCenter = boundingBox.left + 0.5 * viewportWidth;

    setConstraints({
      top: viewportHeight - contentHeight,
      bottom: 0,
      left: viewportWidth - contentWidth,
      right: 0,
      markerLeft: markerLeft,
      markerRight: markerRight,
      markerHorizontalCenter: markerHorizontalCenter
    });
  }

  useEffect(() => {
    setData();
    window.addEventListener("resize", setData)
    return () => {
      window.removeEventListener("resize", setData)
    }
  }, []);

  return constraints;
}

// function useScrollConstraints(ref) {
//   const [constraints, setConstraints] = useState({
//     firstElementHeight: 0,
//     firstElementWidth: 0,
//     containerHeight: 0,
//     containerWidth: 0
//   });

//   useEffect(() => {
//     const element = ref.current;
//     const containerHeight = element.offsetHeight;
//     const containerWidth = element.offsetWidth;
//     const firstElementHeight = element.firstChild.offsetHeight;
//     const firstElementWidth = element.firstChild.offsetWidth;

//     setConstraints({
//       containerHeight: containerHeight,
//       containerWidth: containerWidth,
//       firstElementHeight: firstElementHeight,
//       firstElementWidth: firstElementWidth
//     });
//   }, []);

//   return constraints;
// }

export const Swiper = ({data, sectionWidth, viewed}) => {
  const x = useMotionValue(0);
  let animControls = useAnimation();
  const [page, setpage] = useState(0);
  const [scrollDirection, setscrollDirection] = useState(0);


  const [markerOffset, setmarkerOffset] = useState(["pixel", 24]); // percent | pixel
  const [itemsMargin, setitemsMargin] = useState(24);
  const [swipeConfidenceThreshold, setswipeConfidenceThreshold] = useState(100);
  const [inactiveCardWidth, setinactiveCardWidth] = useState(400);
  const [activeCardWidth, setactiveCardWidth] = useState(700);
  const [activeCardHeight, setactiveCardHeight] = useState(500);
  const [inactiveCardHeight, setinactiveCardHeight]= useState(470);

  const containerRef = useRef(null);
  const { top, bottom, left, right } = useContainerConstraints(containerRef, markerOffset);

  const scrollRef = useRef(null);
  // const { firstElementWidth } = useScrollConstraints(scrollRef);
  // const snapTo = snap(inactiveCardWidth + itemsMargin);


  const scrollToPage = (newpage) => {
    const element = containerRef.current;
    const containerWidth = element.offsetWidth;

    const boundingBox = element.getBoundingClientRect();
    const markerLeft =
      boundingBox.left +
      (markerOffset[0] == "pixel"
        ? markerOffset[1]
        : markerOffset[1] * containerWidth);
    const markerRight =
      boundingBox.right -
      (markerOffset[0] == "pixel"
        ? markerOffset[1]
        : markerOffset[1] * containerWidth);
    const markerHorizontalCenter = boundingBox.left + 0.5 * containerWidth;

    const scrollElem = scrollRef.current;
    let scrollOffset = 0;
    if(newpage < page) {
      // scrollOffset = -inactiveCardWidth
    }

    if(newpage > page) {
      scrollOffset = -activeCardWidth +inactiveCardWidth
    }


    let traslation_x_Value =
      scrollElem.children[newpage].getBoundingClientRect().left - markerLeft + scrollOffset ;

      if (newpage >=0 && newpage < data.length) {
        setpage(newpage);
        setscrollDirection(newpage > page ? 1 : -1 )
        translateX(
          traslation_x_Value + (newpage > page ? 0 : -1)*12 ,
          1
        );
      }

  };


  

  function handleWheel_X(event) {
    // event.preventDefault();

    // uncomment to allow scroll
    //------------------------------------------
    // const newX = x.get() - event.deltaX;
    // const clampedX = clamp(left, right, newX);
    // x.stop();
    // x.set(clampedX);
  }

  const translateX = (delta, direction) => {
    const newX = x.get() - delta * direction;
    // const clampedX = clamp(left, right, snapTo(newX) + 32);
    // const clampedX = snapTo(newX) + itemsMargin;
    const clampedX = newX;
    x.stop();
    x.start(function () {
      animControls.start({ x: clampedX, transition: { duration: 0.5 } });
    });
    // x.set(clampedX);
  };


  const swipePower = (offset, velocity) => {

    if(Math.abs(offset.x) > 2*Math.abs(offset.y) && Math.abs(velocity.x) > 2*Math.abs(velocity.y)) {
      return Math.abs(offset.x) * velocity.x;
    }
    return 0;
    
  };
  const paginate = (newDirection) => {
    scrollToPage(page + newDirection);
  };

  const setConstraints = () => {

   let width = window.innerWidth;
   let containerWidth = Math.min(width, 1600);
  
    if(width < Number(layout.breakpoints.md)) {
      let temp_sectionWidth = sectionWidth || width-64;
      setactiveCardWidth(Math.min(width-64, temp_sectionWidth));
      setinactiveCardWidth(Math.min(width-64, temp_sectionWidth));
      setmarkerOffset(['pixel', (containerWidth-temp_sectionWidth)/2])
      setactiveCardHeight(400);
      setinactiveCardHeight(380);
      x.set((containerWidth-temp_sectionWidth)/2 - itemsMargin)

    } else {
      setactiveCardWidth(770);
      setinactiveCardWidth(342);
      // setmarkerOffset(['pixel', Math.min(width, 1600)*.1]) //196 // Math.min(width, 1600)*.1
      setmarkerOffset(['pixel', (containerWidth-sectionWidth)/2]) //196 // Math.min(width, 1600)*.1 //(1600 -1332) / 2  'swiper-container'-'section or texts width'
      setactiveCardHeight(500);
      setinactiveCardHeight(454);
      x.set((containerWidth-sectionWidth)/2 - itemsMargin)
    }
    
     scrollToPage(0);
  }

  useEffect(() => {
    setConstraints();
    window.addEventListener("resize", setConstraints)
    // window.addEventListener("orientationchange", setConstraints)
    
    return () => {
      window.removeEventListener("resize", setConstraints)
      // window.removeEventListener("orientationchange", setConstraints)
    }
  }, []);

  useEffect(() => {
    setConstraints();
  }, [sectionWidth, viewed])
  

  return (
    <Wrapper activeCardHeight={activeCardHeight} itemsMargin={itemsMargin} markerOffset={markerOffset?.[1]}>
      <motion.div className="desktop-only top-slider"
        variants={SectionAnimation}
        initial={'hidden'}
        animate={viewed ? 'show' : 'hidden'}
        transition={{
            ...SectionAnimation.transition(3, false)
        }}
      >
          <div className="slider-toggles">
              <NavButtons onClick={(direction)=>{scrollToPage(page + direction);}} isFirstSlide={page == 0} isLastSlide={page == data.length -1}/>
          </div>
      </motion.div>
      <div className="swiper-container" ref={containerRef} onWheel={handleWheel_X}>
        <motion.div
          drag="x"
          dragConstraints={{ top, bottom, left, right }}
          // onDragEnd={(event, info) => console.log(info.point.x, info.point.y)}
          // onDrag={(event, info) => console.log(info.point.x, info.point.y)}
          className="scrollable"
          style={{ x }}
          animate={animControls}
          ref={scrollRef}
          dragElastic={1}
          onDragEnd={(e, { offset, velocity }) => {
            const swipe = swipePower(offset, velocity);
            if (swipe < -swipeConfidenceThreshold) {
              paginate(1);
            } else if (swipe > swipeConfidenceThreshold) {
              paginate(-1);
            }
          }}
          dragMomentum={false}
          transition={{
            x: { type: "spring", stiffness: 300, damping: 10 }
          }}
        >
          {data && data.map((elem, index) => (
                  <motion.div
                    onTap={(event) => {
                      event.stopPropagation()
                      scrollToPage(index);
                      if(page == index && elem.url) {
                        window.location.href = elem.url
                      }
                    }}
                    className={`swiper-card ${page == index && "active"}`}
                    initial={{ opacity: 0, height: `${inactiveCardHeight}px`, width: `${inactiveCardWidth}px` }}
                    animate={
                        page == index
                          ? {
                              opacity: 1,
                              height: `${activeCardHeight}px`,
                              width: `${activeCardWidth}px`,
                              margin: `0px ${itemsMargin/4}px`,
                              background: '#FFFFFF',
                              boxShadow: 'rgba(20 20 22 .16) 0px 50px 50px',
                              zIndex: 10
                            }
                          : { 
                              opacity: 1, 
                              background: '#DBE1E2', 
                              width: `${inactiveCardWidth}px`, 
                              height: `${inactiveCardHeight}px`,
                              margin: `0px ${itemsMargin/2}px`,
                            }
                    }
                    transition={{ duration: 0.5, delay: 0.0 }}
                    style={{cursor : page == index ? 'pointer' : 'grabbing'}}
                  >
                    <img src={elem?.image?.url} />
                    <motion.div className="text-container"
                    
                    >

                      <motion.div
                      initial={
                        { opacity: 0.5 }
                      }
                      animate={
                        (page == index ) 
                            ? {
                                opacity: ["50%", "0%", "0%", "10%", "50%", "100%"],
                                y: [0, 20, 10, 0]
                              }
                            :
                          (page-scrollDirection == index )? 
                            {
                              opacity: ["100%", "50%", "10%","0%", "0%", "50%" ],
                              y: [0, 10, 20, 0]
                            } :
                            {

                            }
                      }
                      transition={{ duration: 0.5, delay: 0.0 }}>
                        <h4 className="h4">{elem.heading}</h4>
                        <p className="body2">{elem.description}</p>
                        {elem.buttons && elem.buttons.length > 0 ? <Buttons buttons={elem.buttons}/> : <></>}
                      </motion.div>
                      
                    </motion.div>
                  </motion.div>
          ))}
        </motion.div>
      </div>

      <Container padding={'level4'} className="mobile-only">
          <div>
              <div className="slider-toggles">
                  <NavButtons onClick={(direction)=>{scrollToPage(page + direction);}} isFirstSlide={page == 0} isLastSlide={page == data.length -1}/>
              </div>
          </div>
      </Container>

    </Wrapper>
  );
};


const Wrapper = styled.div`

position: relative;

.mobile-only {
  display: none;
  ${layout.screen.mob} {
    display: block;
  }
}

.desktop-only {
  &.top-slider {
    position: absolute;
    top: -64px;
    right: ${(props)=>(props.markerOffset)}px;;

    .slider-toggles {
      padding: 0px 0px;
    }
  }



  ${layout.screen.mob}{
    display: none;
  }
}

  .swiper-container {
    overflow: hidden;
    display: flex;
    flex-direction: row;
    max-width: 1600px;
    margin: 0px auto;
  }
  
  .scrollable {
    display: flex;
    flex-direction: row;
    align-items: flex-end;
    padding-bottom: 100px;
    // height: 700px;
    height: ${(props)=>(props.activeCardHeight+100)}px;
  }
  
  .swiper-card {
    display: flex;
    border-radius: 16.5467px;
    margin:0px ${(props)=>(props.itemsMargin/2)}px;

    position: relative;
    img {
        transition: opacity 0.5s ease-in-out 0.5s;
        visibility:hidden;
        position: absolute;
        top: 0;
        left: 0;
        object-fit: cover;
        width: 100%;
        opacity: 0;
    }

    .text-container {
        position: absolute;
        bottom: 0px;
        padding: 1rem 3.5rem 4rem 3.5rem;
        ${layout.screen.mob} {
          padding: 1.5rem 2rem;
        }
        opacity: 0.5;

        p {
            margin-top: 0.5rem;
        }
      }
  }
  

  .active {
      transition: border-radius 0.7s ease-in 0s, margin 0.1s ease-in 0s ;
      transform: translateZ(120px) perspective(150px);
      border-radius: 9.92803px;
      .text-container {
          background: linear-gradient(0deg, rgba(255,255,255,1) 0%, rgba(255,255,255,0) 100%);
          border-radius: 0px 0px 9.92803px 9.92803px;
          opacity: 1;
          visibility: visible;
          transition: opacity 0.5s ease-in-out 0.5s; 
          padding: 1rem 4.5rem 4rem 4.5rem;
          ${layout.screen.mob} {
            padding: 1.5rem 2rem;
          }
      }
      img {
          visibility:visible;
          opacity: 1;
      }
  }


  .slider-toggles {
    position: absolute;
    bottom: 0rem;
    right: 0px;
    padding: 0rem ${layout.constants.padding.level4};

    ${layout.screen.mob} {
      width: 100%;
      padding: 0rem ${layout.constants.padding.level1};
    }
    
}
`;



// Start : Buttons component

const NavButtonsWrapper = styled.div`
    display: flex;
    justify-content: space-between;
    align-items: center;

    .button {
        cursor: pointer;
        width: 36px;
        height: 36px;
        ${layout.screen.mob} {
          width: 48px;
          height: 48px;
        }
        background: rgba(255, 255, 255, 0.72);
        opacity: 0.8;
        box-shadow: inset 1.65467px 1.65467px 1.65467px rgba(255, 255, 255, 0.25);
        backdrop-filter: blur(26.4748px);
        border-radius: 50%;
        display: flex;
        justify-content: center;
        align-items: center;
    
        background: rgb(255, 255, 255);
        box-shadow: rgb(255 255 255 / 25%) 2px 2px 2px inset;
        backdrop-filter: blur(32px);
        border-radius: 50%;
        transform: none;
        opacity: 1;

        img {
            height: 14px;
            width: auto;
            ${layout.screen.mob} {
              height: 17px;
            }
        }

    }

    .button.left {
        margin-right: 36px;
        img {
            position: relative;
            right: 1px;
        }
    }

    .button.right {
        img {
            transform: rotate(180deg);
            position: relative;
            left: 1px;
        }
    }

    .button.inactive {
        cursor: not-allowed;
        opacity: 0.5;
        background: rgba(255, 255, 255, 0.72);
        opacity: 0.8;
        box-shadow: inset 2px 2px 2px rgba(255, 255, 255, 0.25);
        backdrop-filter: blur(32px);
        /* Note: backdrop-filter has minimal browser support */

        border-radius: 50%;
    }

`;


const NavButtons = ({onClick, isFirstSlide, isLastSlide}) => {
    return (
        <NavButtonsWrapper>
            <motion.div 
              className={`button left ${isFirstSlide ? 'inactive': ''}`} 
              onClick={()=>onClick(-1)} 
              whileHover={isFirstSlide ? {} :{
                scale: 1.05,
                transition: { ease: 'anticipate', duration: 0.200 },
              }}
              whileTap={isFirstSlide ? {} : { scale: 0.9 }}
            >
                <img src={NavArrowLeftIcon}/>
            </motion.div>
            <motion.div 
              className={`button right ${isLastSlide ? 'inactive': ''}`} 
              onClick={()=>onClick(1)}
              whileHover={isLastSlide ? {} :{
                scale: 1.05,
                transition: { ease: 'anticipate', duration: 0.200 },
              }}
              whileTap={isLastSlide ? {} : { scale: 0.9 }}
            >
                <img src={NavArrowLeftIcon}/>
            </motion.div>
        </NavButtonsWrapper>
    )
}

// End : NavButtons component



// Start : Buttons component

const ButtonsWrapper = styled.div`
    display: flex;
    justify-content: start;
    align-items: center;

    margin-top: 2rem;
    margin-bottom: 1rem;

    .button {
        cursor: pointer;
        margin-right: 3rem;
        
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        padding: 16px 32px;
        border-radius: 16px;
    }

    .button.dark {
        background: #00AB88;
        h5 {
            margin: 0px 10px;
            color: #FFFFFF;
        }
    }

    .button.light {
        background: transparent;
        padding: 16px 0px;
        h5 {
            margin: 0px 10px;
            color: #2F695D;
        }
    }

`;


const Buttons = ({buttons}) => {
    return (
        <ButtonsWrapper>
            {buttons && buttons.map((elem, index)=>{
                return(
                    <div className={`button ${index%2 ? 'light' : 'dark'}`}>
                        <h5>{elem.title}</h5>
                    </div>
                )
                
            })}
        </ButtonsWrapper>
    )
}

// End : Icons component