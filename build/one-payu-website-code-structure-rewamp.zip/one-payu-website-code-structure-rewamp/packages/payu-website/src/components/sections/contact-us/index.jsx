import React, {  useRef, useEffect, useState, useLayoutEffect } from 'react'
import { connect, styled , Global, css} from 'frontity';
import {layout, SectionAnimation} from '../../../utils/constants';
import {useOnScreen, useWindowDimentions, useContainerDimensions} from '../../../utils/hooks/usehooks'
import { Section, Row, Col, Container } from '../../misc/layout';
import { motion, useMotionValue, useAnimation } from "framer-motion";

const SectionWrapper = styled.div`
    min-height: 300px;
    position: relative;
    overflow-x: clip;
    
    .section-inner {
        display: flex;
        flex-direction: row;
        background: #DBE1E2;
        border-radius: 20px;
        margin-top: 96px;

        ${layout.screen.mob} {
            flex-direction: column;
            margin-top: 5rem;
        }

        .image-container {
            position: relative;
            // padding-bottom: 3rem;
            flex: 4;
            display: flex;
            justify-content: center;



            .image-wrapper {

                // bottom: 0px;
                // left: 0px;
                // width: 100%;
                // display: flex;
                // justify-content: center;
                // position: absolute;

                display: flex;
                
                justify-content: flex-end;
                ${layout.screen.mob} {
                    justify-content: center;
                }

                img {
                    // max-width: 496px;
                    width: 90%;
                    ${layout.screen.mob} {
                        width: 90%;
                    }
                    height: auto;
                    // width: auto;
                    object-fit: cover;
                    border-radius: ${layout.reponsiveCssValue(16, 20, 1400, 16, 1600, 20)};
                    ${layout.screen.mob} {
                        border-radius: ${layout.reponsiveCssValue(20, 16, 375, 20, 1400, 16)};
                    }
                }
                
            }
            
        }

        .texts-container {
            webkit-flex: 5;
            flex: 4;

            .texts {
                h1 {
                    // color: #0E342C;
                    margin: 0;
                }
                p {
                    // color: #2F695D;
                    margin-top: ${layout.reponsiveCssValue(24, 32, 1400, 26, 1600, 32)};
                }
                margin-bottom: ${layout.reponsiveCssValue(24, 32, 1400, 26, 1600, 32)};
            }

            margin-top: ${layout.reponsiveCssValue(64, 112, 1400, 92, 1600, 112)};
            margin-bottom: ${layout.reponsiveCssValue(64, 112, 1400, 92, 1600, 112)};
            margin-right: ${layout.reponsiveCssValue(48, 76, 1400, 62, 1600, 76)};
            margin-left: ${layout.reponsiveCssValue(48, 76, 1400, 62, 1600, 76)};

            ${layout.screen.mob} {
                margin-top: 0px;
                margin-bottom: ${layout.reponsiveCssValue(83, 92, 375, 83, 1400, 92)};
                margin-right: ${layout.reponsiveCssValue(28, 62, 375, 28, 1400, 62)};
                margin-left: ${layout.reponsiveCssValue(28, 62, 375, 28, 1400, 62)};
            }
            .buttons-wrapper {
                display: flex;
                flex-direction: row;
                gap: 1.5rem;
                flex-wrap: wrap;
            }
        }
    }

`;


const SectionContactUs = ({state, actions, data, libraries}) =>  {

    const ref = useRef(null)
    const [onScreen, portionInView, viewed] = useOnScreen(ref, "0px");
    const Html2React = libraries.html2react.Component;

    useEffect(() => {
        actions.intraPageLinks.update(data?.section?.internalLink, portionInView);
        return () => {
            actions.intraPageLinks.update(data?.section?.internalLink, 0);
        }
    }, [portionInView])


    return (
        <>
    <SectionWrapper id={data?.section?.internalLink}>
        <Section padding={'level3'} paddingMob={'level0'}>
            <motion.div 
                className="section-inner"
                ref={ref}
                variants={SectionAnimation}
                initial={'hidden'}
                animate={viewed ? 'show' : 'hidden'}
                transition={{
                    ...SectionAnimation.transition(0, true)
                }}
            >
                <div className="image-container">
                    <div className="image-wrapper">
                        <motion.img 
                            initial={{y: 0, 
                                opacity: 0}}
                            animate={viewed ? {y:-96, opacity: 1} : {}}
                            transition={{
                                duration: 0.5,
                                delay: 0.5
                            }}
                            src={data?.image?.url} 
                        />
                    </div>
                </div>

                <div className="texts-container">
                    <div className="texts">
                        <h2 className='h2'>{data.heading}</h2>
                        <p class="body2">{data.description}</p>
                    </div>

                    {/* <div className="buttons">
                        <div className="buttons-container">
                            <Buttons buttons={data.buttons}/>
                        </div>
                    </div> */}

                    {data?.buttons && data?.buttons.length > 0 && 
                        <motion.div
                            className="buttons-wrapper"
                            variants={SectionAnimation}
                            initial={{x: 16, opacity: 0}}
                            animate={viewed ? {x:0, opacity: 1} : {}}
                            transition={{
                                // staggerChildren: 0.1,
                                // delayChildren: 0.3,
                                duration: 0.5,
                                // delay: 0.5
                            }}
                        >
                            {
                                data?.buttons?.map((elem, index)=>(
                                    <Button title={elem?.title} link={elem?.link} type={elem?.type?.value || 'dark'}/>
                                ))
                            }
                        </motion.div>
                    }

                </div>

            </motion.div>
        </Section>
    </SectionWrapper>
    </>
    )

}

export default connect(SectionContactUs)


// Start : Buttons component

const ButtonWrapper = styled.div`
    display: flex;
    justify-content: start;
    align-items: center;
    flex-wrap: wrap;

    .button {
        cursor: pointer;
        //margin-right: 12px;
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        // border-width: ${layout.reponsiveCssValue(1.5,2, 1440, 1.73558, 1600, 2)};
        border-width: 0px;
        border-color: rgba(255, 255, 255, 0.72);
        border-style: solid;
        padding: 13.2374px 55px;
        border-radius: 13.2374px;
        ${layout.screen.mob} {
            padding: 16px 45px;
        }
        a {
            display: flex;
            flex-direction: row;
        }

        h1, h2, h3, h4, h5, h6 {
            // font-family: Roboto Slab;
            // font-style: normal;
            // line-height: 22px;
            // font-weight: 500;
            flex: 1;
            // margin: 0 2rem;
            ${layout.screen.mob} {
                white-space: nowrap;
                // font-size: ${layout.reponsiveCssValue(1.5,2, 1440, 1.73558, 1600, 2)};
            }
        }

        img {
            width: 6px;
        }

    }

    .button.dark {
        background: #00AB88;
        
        h1, h2, h3, h4, h5, h6 {
            color: #FFFFFF;
        }
    }

    .button.light {
        background: #ffffff;
        a {
            color: #1D6F5E;
        }
        h1, h2, h3, h4, h5, h6 {
            color: #2F695D;
        }
    }


    .button.transparent {
        background: transparent;
        border-width: none;
        border-color: none;
        border-style: none;
        padding: 0px 0px;
        border-radius: none;
        

        h1, h2, h3, h4, h5, h6 {
            margin: 0 2rem;
            ${layout.screen.mob} {
                margin: 0px;
            }
            color: #1D6F5E;
        }
    }


    .button.translucent {
        background: rgba(255, 255, 255, 0.4);
        box-sizing: border-box;
        backdrop-filter: blur(3.30935px);
        h1, h2, h3, h4, h5, h6 {
            color: #1D6F5E;
        }
        
    }

`;


const Button = ({type, title, link}) => {
    return (
        <ButtonWrapper>
            <motion.div 
                className={`button ${type}`}
                whileHover={{
                    scale: 1.05,
                    transition: { ease: 'anticipate', duration: 0.200 },
                }}
                whileTap={{ scale: 0.95 }}
            >
                <a href={`${link || 'javascript:void(0)'}`}>
                    <h5 className='button1'>{title}</h5>
                </a>
            </motion.div>
        </ButtonWrapper>
    )
}

// End : Buttons component

