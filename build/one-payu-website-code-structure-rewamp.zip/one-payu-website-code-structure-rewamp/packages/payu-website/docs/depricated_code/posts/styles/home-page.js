import { css } from "frontity";
import { layout, constants } from '../../../utils/constants'

const globalStyles = (colors) =>  css`

  .wrapper { 
    display: flex;
    height: 100%;
    flex-direction: row;
    margin: 48px 24px 24px 24px;
    box-sizing: content-box;
    background: ${colors.bg.post};
    max-width:  min(calc( ( 100vw - ${constants.layout.sidebarWidth}px - 48px) ), ${constants.layout.pageContainerMaxWidth}px);

    ${layout.screen.__sm} {
      width: 100vw;
      max-width: 100%;
      display:inline-block;
      margin:0;
    }
    
  }

  .leftcolumn { 
    background: transparent;
    display: block;
    padding: 30px 40px;
    width: 100%;
    ${layout.screen.__sm} {
      padding:20px;
      float:left;
      width:100%;
      max-width:100%;
    }
  }

  .meta-footer {
    margin: 16px;
  }

  .wp-block-columns {
    display: flex;
  }

  .wp-block-column {
    flex: 1;
  }

  .list-inline-item {
        max-width: 96px;
         width: 100%;
        vertical-align: top;
        margin-bottom: 2.5px;
  }

  h1 {
    // width: 367px !important;
    // height: 96px !important;
    margin: 18px 16px 16px 0 !important;
    font-size: 40px !important;
    font-weight: bold !important;
    font-stretch: normal !important;
    font-style: normal !important;
    line-height: 1.2 !important;
    letter-spacing: normal !important;
    color: #3b3f46 !important;
  }


  .wp-block-group__inner-container {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    min-height: 100px;
    height: max-content;
    justify-content: space-around;
  }

  .wp-block-group.space-between {
    .wp-block-group__inner-container {
        justify-content: space-between;
      }
  }

  ${layout.screen.__md} {
    .wp-block-columns {
        flex-wrap: wrap;
      }

    .wp-block-column {
        min-width: 100%
      }

      .hero-image {
          display: none;
      }
  }
`;

const layoutStyles = (colors) => 
  css([
    globalStyles(colors)
  ]);

export default layoutStyles;