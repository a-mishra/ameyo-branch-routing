import React, {  useRef, useEffect, useState, useLayoutEffect } from 'react'
import { connect, styled , Global, css} from 'frontity';
import {layout, SectionAnimation} from '../../../utils/constants';
import {useOnScreen, useWindowDimentions, useContainerDimensions, useType} from '../../../utils/hooks/usehooks'
import { Section, Container } from '../../misc/layout';
import { motion, useMotionValue, useAnimation } from "framer-motion";
import DropDownIcon from '../../../assets/icons/dropdown.svg';
import DropDownReversedIcon from '../../../assets/icons/dropdown_reversed.svg';
import NavArrowLeftIcon from '../../../assets/icons/arrow-left.svg';


function useContainerConstraints(ref) {
    const [constraints, setConstraints] = useState({
      top: 0,
      bottom: 0,
      left: 0,
      right: 0
    });
  
    const setData = () => {
      const element = ref.current;
      const viewportHeight = element?.offsetHeight;
      const contentHeight = element?.firstChild?.offsetHeight;
      const viewportWidth = element?.offsetWidth;
      const contentWidth = element?.firstChild?.offsetWidth;
  
      setConstraints({
        top: viewportHeight - contentHeight,
        bottom: 0,
        left: viewportWidth - contentWidth,
        right: 0
      });
    }
  
    useEffect(() => {
      ref.current && setData();
      window.addEventListener("resize", setData)
      window.addEventListener("orientationchange", setData)
      return () => {
        window.removeEventListener("resize", setData)
        window.removeEventListener("orientationchange", setData)
      }
    }, []);
  
    return constraints;
  }

const ItemAnimation = {
    hidden: {
        opacity: 0,
        scale: 1,
        y: 20
    },
    show: {
        opacity: 1.1,
        y: 0,
        scale: 1,
    },
    hover: {
        opacity: 1.1,
        y: 0,
    },
    transition: (n) => ({
        ease: 'easeInOut',
        duration:  0.25, 
    })
}

const TableWrapper = styled.div`
    background: rgba(255, 255, 255, 0.4);
    border: 2px solid rgba(255, 255, 255, 0.72);
    border-radius: ${layout.reponsiveCssValue(20, 26.9, 1200, 20, 1600, 26.9)};
    padding-top: 40px;
    padding-right: 49px;
    padding-bottom: 90px;



    .mobile-table-wrapper {
        border-radius: ${layout.reponsiveCssValue(20, 26.9, 1200, 20, 1600, 26.9)};
        background: rgba(255, 255, 255, 1);
        padding: 0px;
        display: grid;
        grid-template-columns: repeat(1, auto);
        grid-row-gap: 0px;
        width: ${220+105*3}px;
        touch-action: [ pan-y | pan-up | pan-down ];
    }

    .navigation-wrapper {
        width: 80%;
        ${layout.screen.xs} {
            width: 90%;
        }
        margin: 21px auto;
        position: absolute;
        left: 50%;
        transform: translate(-50%, 0);
      }
`;

const layoutWidths = {
    rowTitle: 220,
    rowDataCell: 105,
}

const swipeConfidenceThreshold = 30;


export const MobileTable = ({data, deviceType, viewed}) =>  {

    const [page, setpage] = useState(0);

    const paginate = (newDirection) => {


        setpage(Math.max(0, Math.min(page + newDirection, data?.column?.length-1)));

    };

    const swipePower = (offset, velocity) => {
        if( Math.abs(velocity.x) > Math.abs(velocity.y)) {
          return Math.abs(offset.x) * velocity.x;
        }
        return 0;

        
    };

// mobile table wrapper ke width ko change karo, with transition of 500ms, whenever page changes;
    return (
        <TableWrapper>
            <motion.div
                className='mobile-table-wrapper'
                variants={ItemAnimation}
                initial={'show'}
                animate={{width: layoutWidths.rowTitle+(3-page)*layoutWidths.rowDataCell}}
                transition={{
                    ...ItemAnimation.transition(1)
                }}
                onPan={(e, info) => {
                    // console.log('onPan')
                    // console.log(info)
                }}
                onPanStart={(e, info) => {
                    // console.log('onPanStart')
                    // console.log(info)
                }}
                onPanEnd={(e, info) => {
                    const swipe = swipePower(info.offset, info.velocity);
                    if (swipe < -swipeConfidenceThreshold) {
                        paginate(1);
                    } else if (swipe > swipeConfidenceThreshold) {
                        paginate(-1);
                    }
                }}
                
            >

                <Header data={data?.column} viewed={viewed} deviceType={deviceType} page={page} />
                {data?.row?.map((elem, index) => (
                            <>
                                {<Row index={index} data={elem} viewed={viewed} deviceType={deviceType} numberOfColumns={data?.column?.length} isLastRow={index+1 == data?.row?.length ? true : false} isFirstRow={index==0 ? true : false} page={page} paginate={paginate}/>}
                            </>
                        )
                    )
                }
            </motion.div>
            <motion.div className="navigation-wrapper">
                <NavButtons onClick={paginate} isFirstSlide={page==0} isLastSlide={page==data?.column?.length-1} />
            </motion.div>
        </TableWrapper>
    )
}


/**
 * Header
 */
    const Header = (props) => {

        let animControls = useAnimation();
        const x = useMotionValue(0);

        const scrollRef = useRef(null);
        const containerRef = useRef(null);

        const translateX = (delta, direction) => {
            const newX = x.get() - delta * direction;
            const clampedX = newX;
            x.stop();
            x.start(function () {
              animControls.start({ x: clampedX, transition: {
                ...ItemAnimation.transition(1)
            }});
            });
        };

        const scrollToPage = (newpage) => {

            const element = containerRef?.current;
            const containerWidth = element?.offsetWidth;
        
            const boundingBox = element?.getBoundingClientRect();
        
            const markerLeft = boundingBox?.left;
            const markerRight = boundingBox?.right;
            const markerTop = boundingBox?.top;
            const markerBottom = boundingBox?.bottom;
        
            const scrollElem = scrollRef?.current;
            let scrollOffset = 0;
        

            let traslation_x_Value = (scrollElem?.children?.[newpage]?.getBoundingClientRect()?.left || 0) - markerLeft - scrollOffset ;
            if(traslation_x_Value > 0) {
                traslation_x_Value = traslation_x_Value - (layoutWidths.rowTitle);
            }

            translateX(
              traslation_x_Value ,
              1
            );
        
        };

        useEffect(() => {
            scrollToPage(props?.page)
        }, [props.page])
        
        useEffect(() => {
            scrollToPage(props?.page)
        }, [])


        return(
            <HeaderWrapper numberOfColumns={props?.data?.length}>
                <motion.div
                className='cells-wrapper'
                ref={containerRef}
                >
                    <motion.div
                        className='data-cells scrollable'
                        style={{ x }}
                        animate={animControls}
                        ref={scrollRef}
                        transition={{
                            ...ItemAnimation.transition(1)
                        }}          
                    >
                    {
                        props?.data?.map((elem, index)=>(                            
                            <motion.span
                                className='heading-text-wrapper'
                                initial={index == props.page ? {
                                    width: layoutWidths.rowTitle + layoutWidths.rowDataCell
                                }
                                :
                                {
                                    width: layoutWidths.rowDataCell
                                }}
                                animate={
                                    index == props.page ? {
                                        width: layoutWidths.rowTitle + layoutWidths.rowDataCell
                                    }
                                    :
                                    {
                                        width: layoutWidths.rowDataCell
                                    }
                                }
                                transition={{
                                    ...ItemAnimation.transition(1)
                                }} 

                            >
                                <HeaderCell data={elem} index={index} isActive={index == props.page ? true : false}/>

                            </motion.span>
                        ))
                    }
                    </motion.div>
                </motion.div>
                    
            </HeaderWrapper>
        )
    }

    const HeaderWrapper = styled.div`
        width: 100%;
        overflow: hidden;

        .data-cells {
            overflow: hidden;
            display: flex;
            flex-direction: row;

            .heading-text-wrapper {

            }
        }
    `;


    const HeaderCell = (props) => {
        return(
            <HeaderCellWrapper isActive={ props.isActive}>
                <p className='h3 cell-title'>{props?.data?.title}</p>
            </HeaderCellWrapper>
        )
    }

    const HeaderCellWrapper = styled.div`
        justify-content: center;
        text-align: left;
        background: #fff;
        border-radius: ${layout.reponsiveCssValue(20, 26.9, 1200, 20, 1600, 26.9)};
        border-bottom-left-radius: 0px;
        border-bottom-right-radius: 0px;

        padding: 31px 27px;

        .cell-title {
            color: #0E342C;
            width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
    `;



/**
 * Row
 */
    const Row = (props) => {
        let animControls = useAnimation();
        const x = useMotionValue(0);

        const scrollRef = useRef(null);
        const containerRef = useRef(null);

        const translateX = (delta, direction) => {
            const newX = x.get() - delta * direction;
            const clampedX = newX;
            x.stop();
            x.start(function () {
              animControls.start({ x: clampedX, transition: {  ...ItemAnimation.transition(1) } });
            });
        };

        const scrollToPage = (newpage) => {
            
            const element = containerRef?.current;
            const containerWidth = element?.offsetWidth;
        
            const boundingBox = element?.getBoundingClientRect();
        
            const markerLeft = boundingBox?.left;
            const markerRight = boundingBox?.right;
            const markerTop = boundingBox?.top;
            const markerBottom = boundingBox?.bottom;
        
            const scrollElem = scrollRef?.current;
            let scrollOffset = layoutWidths.rowTitle;
        
            let traslation_x_Value = (scrollElem?.children?.[newpage]?.getBoundingClientRect()?.left || 0) - markerLeft - scrollOffset ;

            translateX(
              traslation_x_Value ,
              1
            );
        
        };

        useEffect(() => {
            props.viewed && scrollToPage(props?.page)
        }, [props.page])


        return(
            <RowWrapper isLastRow={props?.isLastRow} numberOfColumns={props?.numberOfColumns}>
                <motion.div className='cells-wrapper'
                    ref={containerRef}
                >
                    <RowTitleCell title={props?.data?.title} isLastRow={props?.isLastRow} isFirstRow={props?.isFirstRow}/>
                    
                    <motion.div
                        className='data-cells scrollable'
                        style={{ x }}
                        animate={animControls}
                        ref={scrollRef}
                        transition={{
                            ...ItemAnimation.transition(1)
                        }}
                    >
                    {
                        props?.data?.cell?.map((elem, index)=>(
                            <Cell data={elem} index={index} isLastRow={props?.isLastRow} isLastCell={props?.data?.cell?.length == index+1 ? true : false}/>
                        ))
                    }
                    </motion.div>
                    
                </motion.div>
                
            </RowWrapper>
        )
    }

    const RowWrapper = styled.div`
        .cells-wrapper {
            display: grid;
            grid-template-columns: 220px auto;
            grid-column-gap: 0px;

            .data-cells {
                display: grid;
                grid-template-columns: repeat(${(props)=>(props.numberOfColumns )},  ${layoutWidths.rowDataCell}px );
                grid-column-gap: 0px;
                z-index: 9;
            }
            
        }
    `;


    /**
     * Cell
     */
        const RowTitleCell = (props) => {
            return(
                <RowTitleCellWrapper isLastRow={props?.isLastRow} isFirstRow={props?.isFirstRow}>
                    <p className='h5 cell-title'>{props?.title}</p>
                </RowTitleCellWrapper>
            )
        }

        const RowTitleCellWrapper = styled.div`
            display: grid;
            grid-template-columns: repeat(1, auto);
            grid-row-gap: 4px;
            background: #EAEFEC;
            padding-top: ${layout.reponsiveCssValue(14, 19, 1200, 14, 1600, 19)};
            padding-bottom: ${layout.reponsiveCssValue(14, 19, 1200, 14, 1600, 19)};
            padding-left: ${layout.reponsiveCssValue(27, 43, 1200, 27, 1600, 43)};
            padding-right: ${layout.reponsiveCssValue(27, 43, 1200, 27, 1600, 43)};

            border-bottom: 0.961971px solid #BFDFBA;
            z-index: 10;

            ${(props)=>(props.isLastRow == true ? `
                border-radius: ${layout.reponsiveCssValue(20, 26.9, 1200, 20, 1600, 26.9)};
                border-top-left-radius: 0px;
                border-top-right-radius: 0px;
                border-bottom-right-radius: 0px;
                border-bottom: none;
            `:
                props.isFirstRow == true ?
                `
                    border-radius: 0px;
                    border-top-left-radius: ${layout.reponsiveCssValue(20, 26.9, 1200, 20, 1600, 26.9)};
                `
                : ``
            
            )}

            .cell-title {
                color: #0E342C;
            }

        `;


        const Cell = (props) => {
            return(
                <CellWrapper isLastRow={props?.isLastRow} isLastCell={props.isLastCell}>
                    <p className='body1 cell-title'>{props?.data?.title}</p>
                    <p className='body3 cell-subtext'>{props?.data?.subText}</p>
                    {props?.data?.image?.url && <motion.div className='image-wrapper' >
                        <img src={props?.data?.image?.url} alt={props?.data?.image?.name}></img>
                    </motion.div>}
                </CellWrapper>
            )
        }

        const CellWrapper = styled.div`
            display: grid;
            grid-template-columns: repeat(1, auto);
            grid-row-gap: 4px;

            justify-content: center;
            justify-content: center;
            text-align: center;

            background: #fff;
            padding-top: ${layout.reponsiveCssValue(14, 19, 1200, 14, 1600, 19)};
            padding-bottom: ${layout.reponsiveCssValue(17, 23, 1200, 17, 1600, 23)};
            padding-left: 21px;
            padding-right: 21px;

            border-bottom: 0.961971px solid #BFDFBA;
            border-right: 0.961971px solid #BFDFBA;

            ${(props)=>(props.isLastRow == true && props.isLastCell == true ? `
                border-radius: ${layout.reponsiveCssValue(20, 26.9, 1200, 20, 1600, 26.9)};
                border-top-left-radius: 0px;
                border-top-right-radius: 0px;
                border-bottom: none;
                border-right: none;
            `:
                props.isLastRow == true ?
                `
                    border-bottom: none;
                `
                : 
                props.isLastCell == true ? 
                `
                    border-right: none;
                `
                :
                ``

            )}

            .cell-title {
                color: #40413B;
            }

            .cell-subtext {
                color: #96A5A2;
            }

            .image-wrapper {
                margin-top: ${layout.reponsiveCssValue(4, 9, 1200, 4, 1600, 9)};
                img {
                    width: ${layout.reponsiveCssValue(69, 92, 1200, 69, 1600, 92)};
                    height: auto;
                }
                
            }
        `;




        // Start : Buttons component

const NavButtonsWrapper = styled.div`
display: flex;
justify-content: space-between;
align-items: center;

.button {
    cursor: pointer;
    width: 36px;
    height: 36px;
    ${layout.screen.mob} {
      width: 48px;
      height: 48px;
    }
    background: rgba(255, 255, 255, 0.72);
    opacity: 0.8;
    box-shadow: inset 1.65467px 1.65467px 1.65467px rgba(255, 255, 255, 0.25);
    backdrop-filter: blur(26.4748px);
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;

    background: rgb(255, 255, 255);
    box-shadow: rgb(255 255 255 / 25%) 2px 2px 2px inset;
    backdrop-filter: blur(32px);
    border-radius: 50%;
    transform: none;
    opacity: 1;

    img {
        height: 14px;
        width: auto;
        ${layout.screen.mob} {
          height: 17px;
        }
    }

}

.button.left {
}

.button.right {
    img {
        transform: rotate(180deg);
    }
}

.button.inactive {
    cursor: not-allowed;
    opacity: 0.5;

    background: rgba(255, 255, 255, 0.72);
    opacity: 0.8;
    box-shadow: inset 2px 2px 2px rgba(255, 255, 255, 0.25);
    backdrop-filter: blur(32px);
    /* Note: backdrop-filter has minimal browser support */

    border-radius: 50%;
}

`;


const NavButtons = ({onClick, isFirstSlide, isLastSlide}) => {
return (
    <NavButtonsWrapper>
          <motion.div 
            className={`button left ${isFirstSlide ? 'inactive': ''}`} 
            onClick={()=>onClick(-1)} 
            whileHover={isFirstSlide ? {} :{
              scale: 1.1,
              transition: { ease: 'anticipate', duration: 0.200 },
            }}
            whileTap={isFirstSlide ? {} : { scale: 0.9 }}
          >
              <img src={NavArrowLeftIcon}/>
          </motion.div>

          <motion.div 
            className={`button right ${isLastSlide ? 'inactive': ''}`} 
            onClick={()=>onClick(1)}
            whileHover={isLastSlide ? {} :{
              scale: 1.1,
              transition: { ease: 'anticipate', duration: 0.200 },
            }}
            whileTap={isLastSlide ? {} : { scale: 0.9 }}
          >
              <img src={NavArrowLeftIcon}/>
          </motion.div>
    </NavButtonsWrapper>
)
}

// End : NavButtons component