import React, {  useRef, useEffect, useState, useLayoutEffect } from 'react'
import { connect, styled , Global, css} from 'frontity';
import {layout, SectionAnimation} from '../../../utils/constants';
import {useOnScreen, useWindowDimentions, useContainerDimensions, useType} from '../../../utils/hooks/usehooks'
import { Section, Container } from '../../misc/layout';
import { motion, useMotionValue, useAnimation } from "framer-motion";
import DropDownIcon from '../../../assets/icons/dropdown.svg'
import DropDownReversedIcon from '../../../assets/icons/dropdown_reversed.svg'

const SectionWrapper = styled.div`
position: relative;
overflow-x: clip;

.section-container {
    ${layout.screen.mob} {
        padding-left: 0px;
        padding-right: 0px;
    }
}


.section-inner {
    .text-dropdown-conatiner {
        display: flex;
        flex-direction: column;
        .texts {
            margin-bottom: 4rem;
            .texts-heading {
                color: #0E342C;
            }
            .texts-description {
                margin-top: ${layout.reponsiveCssValue(4, 19, 1200, 2, 1600, 19)};
            }

            ${layout.screen.mob} {
                padding-left: ${layout.constants.mobile_padding['level4'] || '0rem'};
                padding-right: ${layout.constants.mobile_padding['level4'] || '0rem'};

                margin-bottom: 2.5rem;
                
                .texts-heading {
                    margin: 0rem;
                }

                .texts-description {
                    margin-top: 1.5rem;
                }
            }
        }

        .dropdown-conatiner {
            background: #FFFFFF;
            border-radius: 25.6372px;
            ${layout.screen.mob} {
                border-radius: 28px;
            }

            .items-wrapper {
                padding-top: 47px;
                padding-bottom: 36px;
                padding-left: 45px;
                padding-right: 45px;

                display: grid;
                grid-template-columns: repeat(1, auto);
                grid-row-gap: 32px;

                ${layout.screen.xs} {
                    padding-top: 40px;
                    padding-bottom: 28px;
                    padding-left: 0px;
                    padding-right: 0px;

                    grid-template-columns: repeat(1, auto);
                    grid-row-gap: 12px;
                }

            }

        }
    }
}
`;

const SectionFAQDropDown = ({state, actions, data, libraries}) =>  {
    const ref = useRef(null)
    const [onScreen, portionInView, viewed] = useOnScreen(ref, "0px");
    const Html2React = libraries.html2react.Component;
    const deviceType = useType();

    useEffect(() => {
        actions.intraPageLinks.update(data?.section?.internalLink, portionInView);
        return () => {
            actions.intraPageLinks.update(data?.section?.internalLink, 0);
        }
    }, [portionInView])

    
    useEffect(() => {
        // console.log('data in Section FAQ Dropdown:', data);
    }, [])


    return (
        <>
            <SectionWrapper  id={data?.section?.internalLink}>
                <Section padding={'level4'} className='section-container'>
                    <motion.div 
                        className="section-inner"
                        ref={ref}
                        variants={SectionAnimation}
                        initial={'hidden'}
                        animate={viewed ? 'show' : 'hidden'}
                        transition={{
                            ...SectionAnimation.transition(0, true)
                        }}
                    >
    
                        <div className="text-dropdown-conatiner"> 
                            <div className="texts">
                                <h2 className={`${deviceType=='mobile'? 'h1':'h2'} texts-heading`}>{data.heading}</h2>
                                <p className={`${deviceType=='mobile'? 'body1':'body1'} texts-description`}>{data.description}</p>
                            </div>

                            <motion.div
                                className='dropdown-conatiner'
                            >
                                <motion.div
                                    className='items-wrapper'
                                >
                                    {data && data.items && data.items.map((elem, index) => (
                                                <>
                                                    {viewed && <DropDown index={index} data={elem} viewed={viewed} deviceType={deviceType}/>}
                                                </>
                                            )
                                        )
                                    }
                                </motion.div>
                                 
                            </motion.div>
                        </div>

                    </motion.div>
                </Section>

            </SectionWrapper>
        </>
    )
}

export default connect(SectionFAQDropDown)


const ItemAnimation = {
    hidden: {
        opacity: 0,
        scale: 0.98,
        y: 20
    },
    closed: {
        opacity: 1.1,
        y: 0,
        scale: 1,
        background: '#EAEFEC88'
    },
    open: {
        opacity: 1.1,
        y: -4,
        scale: 1,
        background: '#EAEFEC'
    },
    hover: {
        opacity: 1.1,
        y: -4,
        background: '#EAEFEC'
    },
    transition: (n) => ({
        y: { type: "spring",
          damping: 10,
          mass: 0.2,
          stiffness: 150
         }, 
        ease: 'anticipate',
        duration:  0.5, 
        delay:  0.150*n + .150, 
    })
}


const DropDown = (props) => {
    const [animationCompleted, setanimationCompleted] = useState(false)
    const [isOpen, setisOpen] = useState(false)

    const toggleOpen = () => {
        setisOpen(!isOpen);
    }

    return(
        <DropDownWrapper>
            <motion.div className='item-text-wrapper'
                onTap={toggleOpen}
                variants={ItemAnimation}
                whileHover= {'hover'}
                initial={'hidden'}
                animate={props?.viewed ? (isOpen ? 'open' : 'closed') : 'hidden'}
                transition={
                    animationCompleted && props?.viewed ? 
                    {
                        transition: { duration: 0.150, delay: 0 }
                    }
                    : {
                        ...ItemAnimation.transition(props.index+1)
                    }
                }
                onAnimationComplete={()=>setanimationCompleted(true)}
            >
                <div className='question'>
                    <p className={`${props?.deviceType=='mobile'? 'h4':'h5'} question-text`}>
                        {props?.data?.question}
                    </p>
                    <motion.div className="item-image-wrapper">
                        <motion.img src={isOpen ?  DropDownReversedIcon : DropDownIcon} />
                    </motion.div>
                </div>
                {
                    isOpen && <div className='answer'>
                    <p className={`${props?.deviceType=='mobile'? 'body1':'body3'} answer-text`}>
                        {props?.data?.answer}
                    </p>
                </div>}
            </motion.div>
            
        </DropDownWrapper>
    )
}

const DropDownWrapper = styled.div`

    .item-text-wrapper {
        border-radius: 7.32492px;
        background: #EAEFEC88;
        padding: 18.5px 29px;
        opacity: 1;

        ${layout.screen.mob} {
            padding: 20px 29px 24px 41px;
        }

        .question {
            display: flex;
            flex-direction: row;
            .question-text {
                color: #314235;
            }
            p {
                width: 100%;
            }
            .item-image-wrapper {
                width: ${layout.reponsiveCssValue(14,14.65, 1200, 14, 1600, 14.65)};
                margin-left: 12px;
            }
        }
        .answer {
            .answer-text {
                color: #4F4F4F;
            }
            p {
                margin-top: 16px;
            }
        }
    
    }

    
`;