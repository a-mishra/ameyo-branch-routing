import { styled, connect, loadable } from "frontity";


const Post = ({ state, actions, libraries, data, hideTitle, displayMeta, hideFeedback }) => {
    // Load the post, but only if the data is ready.
    if(data) {


    // Get the data of the post.
    const post = state.source.post[data.id];
      if(post) {

        // Get the html2react component.
        const Html2React = libraries.html2react.Component;

        // Get all categories
        const allCategories = state.source.category;

        /**
         * The item's categories is an array of each category id
         * So, we'll look up the details of each category in allCategories
         */
        const categories =
          post.categories && post.categories.map((catId) => allCategories[catId]);

        // Get all tags
        const allTags = state.source.tag;

        /**
         * The item's categories is an array of each tag id
         * So, we'll look up the details of each tag in allTags
         */
        return (
          <div>
            {post.content && (
              <div >
                  <Html2React html={post.content.rendered} />
              </div>
            )}
          </div>
        )
      }
    
    }
};

export default connect(Post);