export const webpack = ({ config, mode, target }) => {

  // // Change the publicPath.
  // config.output.publicPath = "https://mycdn.com/";

  // const babel = config.module.rules.find(
  //   (rule) => rule.use.loader === "babel-loader"
  // ).options;

  // // Add a new plugin.
  // babel.plugins.push("my-own-babel-plugin");

  config.module.rules.push({
    /*test: /\.extension$/,*/
    test: /\.mjs$/,
    include: /node_modules/,
    type: 'javascript/auto',
    use: []
  });


  // // Change devtool option for development mode.
  // if (mode === "development") {
  //   config.devtool = "cheap-eval-source-map";
  // }

  // // Add an alias for the server.
  // if (target === "server") {
  //   config.resolve.alias["some-package"] = "other-package";
  // }

  // // Add an external for the client (both es5 and module).
  // if (target === "es5" || target === "module") {
  //   config.externals["some-package"] = "window.variable";
  // }

  // console.log({config, mode,target});

  };