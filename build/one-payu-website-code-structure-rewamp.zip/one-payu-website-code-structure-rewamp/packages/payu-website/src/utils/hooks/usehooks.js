import React, {useState, useEffect } from 'react';

export function useIsClient() {
  const [isClient, setClient] = useState(false)

  useEffect(() => {
    setClient(true)
  }, [])

  return isClient
}

export const useWindowDimentions = () => {

  const {isBrowser} = useSsr();

  const getDimensions = () => {
      let data={
        width: Math.min(1600, window.innerWidth),
        height: window.innerHeight
      }
      return data;
    }
  
    const [dimensions, setDimensions] = useState({ width: 0, height: 0 })
  
    const handleResize = () => {
      setDimensions(getDimensions())
    }

    useEffect(() => {
      if (isBrowser) {
        setDimensions(getDimensions())
      }
  
      window.addEventListener("resize", handleResize)
  
      return () => {
        window.removeEventListener("resize", handleResize)
      }
    }, [])

    useEffect(() => {
      if (isBrowser) {
        setDimensions(getDimensions())
      }

    }, [isBrowser])
  
    return dimensions;
}



export function useSsr() {
    const isDOM =
      typeof window !== 'undefined' &&
      window.document &&
      window.document.documentElement
  
    return {
      isBrowser: isDOM,
      isServer: !isDOM,
    }
  }
  
  function buildThresholdList() {
    let thresholds = [];
    let numSteps = 4;
  
    for (let i=1.0; i<=numSteps; i++) {
      let ratio = i/numSteps;
      thresholds.push(ratio);
    }
  
    thresholds.push(0);
    return thresholds;
  }

  export function useOnScreen(ref, rootMargin = "0px") {
    // State and setter for storing whether element is visible
    const [isIntersecting, setIntersecting] = useState(false);
    const [portionInView, setportionInView] = useState(0);
    const [viewed, setViewed] = useState(false);

    const options = {
      root: null,
      rootMargin: rootMargin || "0px",
      threshold: buildThresholdList()
    };

    useEffect(() => {
      const observer = new IntersectionObserver(
        ([entry]) => {
          // Update our state when observer callback fires
          setIntersecting(entry.isIntersecting);
          setportionInView(entry.intersectionRatio)
          if(entry.isIntersecting && entry.intersectionRatio > 0.1 ) {
            setViewed(true);
          }
        },
        options
      );
      if (ref.current) {
        observer.observe(ref.current);
      }
      return () => {
        observer.unobserve(ref.current);
      };
    }, []); // Empty array ensures that effect is only run on mount and unmount
    return [isIntersecting, portionInView, viewed];
  }



export const useLottieContainerDimensions = (myRef, isLoaded) => {

    const getDimensions = () => {
      let selector = "#lottie";
      let target = myRef.current.querySelector(selector);
      let data={
        width: myRef.current.offsetWidth,
        height: myRef.current.offsetHeight
      }

      if(target) {
        data.svgWidth = target.offsetWidth;
         data.svgHeight = target.offsetHeight;
      }

      return data;
    }
  
    const [dimensions, setDimensions] = useState({ width: 0, height: 0, svgWidth: 0, svgHeight:0 })
  
    const handleResize = () => {
      setDimensions(getDimensions())
    }

    useEffect(() => {
      if (myRef.current) {
        setDimensions(getDimensions())
      }
  
      window.addEventListener("resize", handleResize)
  
      return () => {
        window.removeEventListener("resize", handleResize)
      }
    }, [myRef])

    useEffect(() => {
      if (myRef.current) {
        setDimensions(getDimensions())
      }

    }, [isLoaded])
  
    return dimensions;
};

export const useContainerDimensions = (myRef, loadCounter, targetSelector) => {

  const getDimensions = () => {
    let data={
      width: myRef.current.offsetWidth || dimensions.width ,
      height: myRef.current.offsetHeight || dimensions.height
    }

    try {
      if(targetSelector) {
        let selector = targetSelector;
        let target = myRef.current.querySelector(selector);
        if(target) {
          data.target = {};
          data.target.width = target.offsetWidth;
          data.target.height = target.offsetHeight;
        }
      }
    } catch (error) {
      
    }

    return data;
  }

  const [dimensions, setDimensions] = useState({ width: 0, height: 0, target: {} })

  const handleResize = () => {
    if (myRef.current) {
      setDimensions(getDimensions())
    }
  }


  useEffect(() => {
    if (myRef.current) {
      setDimensions(getDimensions())
    }

    window.addEventListener("resize", handleResize)
    window.addEventListener("orientationchange", handleResize)
    return () => {
      window.removeEventListener("resize", handleResize)
      window.removeEventListener("orientationchange", handleResize)
    }
  }, [myRef])

  useEffect(() => {
    if (myRef.current) {
      setDimensions(getDimensions())
    }

  }, [loadCounter])

  return dimensions;
};





export function useType() {
  const [type, setType] = useState('desktop')

  const getType = () => {
    if(window?.innerWidth) {
      let mq = window.innerWidth <=992;
      if (mq == true) {
          setType("mobile");
      } else {
          setType("desktop");
      }
    }
  }

  useEffect(() => {
    getType()
    window.addEventListener("resize", getType)
    window.addEventListener("orientationchange", getType)
    
    return () => {
    window.removeEventListener("resize", getType)
    window.removeEventListener("orientationchange", getType)
    }
  }, [])

  return type
}