import React, {  useRef, useEffect, useState, useLayoutEffect } from 'react'
import { connect, styled , Global, css} from 'frontity';
import {layout, SectionAnimation} from '../../../utils/constants';
import {useOnScreen, useWindowDimentions, useContainerDimensions, useType} from '../../../utils/hooks/usehooks'
import { Section, Row, Col, Container } from '../../misc/layout';
import { motion, useMotionValue, useAnimation, useSpring } from "framer-motion";
import SectionPopularPlugins from '../popular-plugins/index'
import SectionCheckoutCards from '../checkout-cards/index'
import SectionContactUs from '../contact-us/index'
import SectionTabbedComponentFeature from '../tabbed-component-feature/index'
import SectionFAQ from '../faq/index'

const SectionWrapper = styled.div`
    min-height: 300px;
    position: relative;
    overflow-x: clip;

    .section-container {

        ${layout.screen.mob} {
            // padding-left: 0px;
            // padding-right: 0px;
        }
    }
    
    .section-inner {

        .heading-texts {
            .heading-texts-heading {
                color: #141416;
                margin: 0px;
            }

            .heading-texts-description {
                color: #314235;
                margin-top: 0.5rem;
            }
            padding-bottom: 4rem;
        }


        .cards-container {
            display: flex;
            justify-content: space-between;
            flex-direction: row;
            flex-wrap: wrap;
            gap: ${layout.reponsiveCssValue(41, 58, 1200, 41, 1600, 58 )};
            row-gap: ${layout.reponsiveCssValue(152, 160, 1200, 152, 1600, 160 )};
            padding-top: ${layout.reponsiveCssValue(36, 42, 1200, 42, 1600, 36)};

            display: grid;
            grid-template-columns: 1fr 1fr;
        }
    }

    .tabs-container {
        border-bottom: 1.11111px solid #BFDFBA80;
        padding-top: 0px;
        margin-top: 0px;
        
        .tabs-wrapper {
            // level4 offsets
            display: flex;
            gap: 72px;


            .tab {

                padding: 0px 22px;
                position: relative;
                color: #71755E;
                
                .tab-heading {
                    padding-bottom: 22px;
                    color: #71755E;
                    font-weight: 400;
                }

                &.active {
                    .tab-heading {
                        color: inherit;
                        padding-bottom: 22px;
                        font-weight: 500;
                        line-height: 127%;
                    }
                }

                .bottom-border {
                    display: block;
                    position: absolute;
                    height: 2px;
                    width: 100%;
                    background: #00AB88;
                    bottom: 0;
                    left: 0rem;
                    border-radius: 1px;
                }
            }
        }
    }

    .section-tabs-container {
        .section-container {
            margin-top: ${layout.reponsiveCssValue(64, 74, 1200, 64, 1600, 74)};
            ${layout.screen.mob} {
                margin-top: 62px;
            }
            padding-top: 0px;
        }
        .section-features {
            top: -64px;
            .section-inner {
                
                // .text-cards-container {
                //     .text {
                //         margin-bottom:0px;
                //     }

                //     .cards-container {
                //         padding-bottom: 60px;
                //     }

                // }
            }
        }
    }

`;

const tabAnimation = {
    inactive: { color: '#71755e' },
    active: {
        color: '#00AB88'
    },
    transition: () => ({
        ease: 'anticipate',
        duration: 0.2, 
        delay: 0, 
    })
}

const CardAnimation = {
    hidden: {scale: 1, y: 0 },
    show: {
        scale: 1,
        y: 0
    },
    transition: (n, longDelay=false) => ({
        ease: 'anticipate',
        duration: longDelay ? 0.8 : 0.5, 
        delay: (longDelay ? 0.8 : 0.5)*(n) - 0.1*n, 
    })
}


function useContainerConstraints(ref, markerOffset) {
    const [constraints, setConstraints] = useState({
      top: 0,
      bottom: 0,
      left: 0,
      right: 0,
      drag: true
    });
  
    const setData = () => {
      const element = ref.current;
      const viewportHeight = element.offsetHeight;
      const contentHeight = element.firstChild.offsetHeight;
      const viewportWidth = element.offsetWidth;
      const contentWidth = element.firstChild.offsetWidth;
  
    //   console.log({viewportHeight, contentHeight, viewportWidth, contentWidth, top: viewportHeight - contentHeight, bottom: 0, left: viewportWidth - contentWidth,right: 0})
      setConstraints({
        top: viewportHeight - contentHeight,
        bottom: 0,
        left: viewportWidth - contentWidth - 48,
        right: 0,
        drag: contentWidth > viewportWidth ? true : false
      });
    }
  
    useEffect(() => {
      setData();
      window.addEventListener("resize", setData)
      window.addEventListener("orientationchange", setData)
      return () => {
        window.removeEventListener("resize", setData)
        window.addEventListener("orientationchange", setData)
      }
    }, []);
  
    return constraints;
  }


const SectionTabbedComponent = ({state, actions, data, libraries}) =>  {

    const ref = useRef(null)
    const [onScreen, portionInView, viewed] = useOnScreen(ref, "0px");
    const Html2React = libraries.html2react.Component;
    const [page, setpage] = useState(0);
    const deviceType = useType();


    useEffect(() => {
        actions.intraPageLinks.update(data?.section?.internalLink, portionInView);
        return () => {
            actions.intraPageLinks.update(data?.section?.internalLink, 0);
        }
    }, [portionInView])


    // useEffect(() => {
    //     console.log(`Tabbed Component`,data)
    //     return () => {
    //     }
    // }, [])

    const springConfig = {
        damping: 100,
        stiffness: 10,
        mass: 3
    };
    
    const motionStyles = useSpring(
        springConfig
    );

    const tabcontainerRef = useRef(null);
    const { top, bottom, left, right, drag } = useContainerConstraints(tabcontainerRef);

    return (
        <>
            <SectionWrapper id={data?.section?.internalLink}>
                <div ref={ref}>

                <Section padding={'level4'} className={'section-container'}>
                    <motion.div 
                        className="section-inner"
                    >

                        <motion.div className="heading-texts"
                            variants={SectionAnimation}
                            initial={'hidden'}
                            animate={viewed ? 'show' : 'hidden'}
                            transition={{ 
                                ...SectionAnimation.transition(0, true)
                            }}
                        >
                            <h2 className={`${deviceType=='mobile'? 'h1':'h2'} heading-texts-heading`}>{<Html2React html={data?.heading || ''} />}</h2>
                            <p className={`${deviceType=='mobile'? 'body1':'body1'} heading-texts-description`}>{<Html2React html={data?.description || ''} />}</p>
                        </motion.div>

                    </motion.div>
                </Section>

                <Section padding={'level4'} className={'tabs-container'}>
                    <motion.div 
                        ref={tabcontainerRef}
                        className="tabs-wrapper"
                        drag={drag && 'x'}
                        dragConstraints={{ top, bottom, left, right }}
                        whileHover={{ cursor: "pointer" }}
                        whileDrag={{ cursor: "grabbing" }}
                        variants={tabAnimation}
                        initial={'hidden'}
                        animate={viewed ? 'show' : 'hidden'}
                        transition={{ 
                            ...tabAnimation.transition(1, false)
                        }}
                    >
                        <div style={{display: 'flex'}}>
                        {
                            data?.tabs?.map((elem,index)=>(
                                <motion.div className={`tab ${page==index && 'active'}`}
                                    variants={tabAnimation}
                                    initial={'hidden'}
                                    animate={page==index ? 'active' : 'inactive'}
                                    transition={{ 
                                        ...tabAnimation.transition(0, true)
                                    }}
                                    whileHover={
                                        {
                                            color: '#00AB88'
                                        }
                                    }
                                    onTap={()=>{
                                        setpage(index)
                                    }}
                                >
                                    <h4 className={`${deviceType=='mobile'? (page==index ? 'h3': 'h4'): (page==index ? 'h5': 'h6') } tab-heading`}>{<Html2React html={elem?.title || ''} />}</h4>
                                    {
                                        page==index && <motion.div 
                                        initial={{width: "0px", left: "-0.5rem" }}
                                        style={motionStyles}
                                        animate={{
                                            width: "100%",
                                            transition: { delay: 0 },
                                            left: "0rem"
                                        }}
                                        exit={{ width: "0%", left: "-0.5rem" }}
                                        className={"bottom-border"}
                                    />}
                                </motion.div>
                            ))
                        }

                        </div>

                    </motion.div>
                </Section>

                <motion.div className={'section-tabs-container'}>
                    {
                        data?.tabs?.[page]?.childComponent?.type?.value =="checkoutCards"
                        ?
                            <SectionCheckoutCards data={data?.tabs?.[page]?.childComponent?.data} />
                        :
                            (data?.tabs?.[page]?.childComponent?.type?.value =="popularPlugins"
                            ?
                                <SectionPopularPlugins data={data?.tabs?.[page]?.childComponent?.data} />
                            :
                                (
                                    data?.tabs?.[page]?.childComponent?.type?.value =="contactUs"
                                    ?
                                        <SectionContactUs data={data?.tabs?.[page]?.childComponent?.data} />
                                    :
                                        (
                                            data?.tabs?.[page]?.childComponent?.type?.value =="features"
                                            ?
                                                <SectionTabbedComponentFeature data={data?.tabs?.[page]?.childComponent?.data} />
                                            :
                                            (
                                                data?.tabs?.[page]?.childComponent?.type?.value =="faq"
                                                ?
                                                    <SectionFAQ data={data?.tabs?.[page]?.childComponent?.data} />
                                                :
                                                <></>
                                            )
                                        )
                                )
                            )

                    }
                </motion.div>


                </div>

            </SectionWrapper>
        </>
    )

}

export default connect(SectionTabbedComponent)