import React from 'react'
import { Global, connect} from 'frontity'

import Post from "../post";
import layoutStyles from '../styles/home-page'


const HomePage = ({ state, data }) => {
    const post = state.source.post['8973'];
    return (
        <>
          <Global styles={layoutStyles(state.theme.colors)} />
          {post && <Post data={post}/> }
        </>         
    )
}

export default connect(HomePage);