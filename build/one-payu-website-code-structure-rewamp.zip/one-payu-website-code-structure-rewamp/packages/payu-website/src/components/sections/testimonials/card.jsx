import React, {  useRef, useEffect, useState } from 'react'
import { styled } from 'frontity';

import { motion, useMotionValue, useAnimation, useTransform } from "framer-motion";
import Content from './content'

const Wrapper = styled.div`
    background: transparent;
`;


const Card = (props) => {
    const x = useMotionValue(0)
    const controls = useAnimation()


    const [localCardIndex, setLocalCardIndex] = useState(props.index);

    const handleSetLocalCardIndex = (newIndex) => {
        setLocalCardIndex(newIndex);
        handleUpdateHeight();
    }

    useEffect(() => {
        props.isTopCard && handleSetLocalCardIndex(props.index);
    
    }, [props.index])
    



    const scale = useTransform(x, [-1* Math.max(props.width, 500), 0, 1* Math.max(props.width, 500)], [0.75, 1, 0.75])
    const rotate = useTransform(x, [-1* Math.max(props.width, 500), 0, 1* Math.max(props.width, 500)], [-30, 0, 30], {
        clamp: false,
    })
    const centerOfRotation = useTransform(x, [-1* Math.max(props.width, 500), 1* Math.max(props.width, 500)], [0, 100], {
        clamp: false,
    })

    const ref = useRef(null);
    const swipeConfidenceThreshold= 10;

    const swipePower = (offset, velocity) => {
        if(Math.abs(offset.x) > Math.abs(offset.y) && Math.abs(velocity.x) > Math.abs(velocity.y)) {
            return Math.abs(offset.x) * velocity.x;
          }
          return 0;
      };

    const NumberOfSliders = props?.data?.cards?.length  || 1;

    const nextCard = () => {
        props.setExitX('-100%')
        props.setexitDirection(1)
        props.setIndex(localCardIndex + 1 >= NumberOfSliders ? 0 : localCardIndex + 1)
        setLocalCardIndex(props.index);

    }

    const prevCard = () => {
        props.setExitX('100%')
        props.setexitDirection(-1)
        props.setIndex(localCardIndex - 1 <= -1 ? NumberOfSliders-1 : localCardIndex - 1 )
        setLocalCardIndex(props.index);

    }

    const handleDragEnd = (event, info) => {
        const swipe = swipePower(info.offset, info.velocity);
        if (swipe < -swipeConfidenceThreshold) {
            nextCard();
        } else if (swipe >= swipeConfidenceThreshold) {
            prevCard();
        }
    }

    const handleUpdateHeight = () => {
        if(ref.current) {
            if(props.isTopCard) {
                props.updateHeight?.(ref.current.offsetHeight);
            }
        }
    }

    useEffect(() => {
        handleUpdateHeight();
        window.addEventListener("resize", handleUpdateHeight)
        window.addEventListener("orientationchange", handleUpdateHeight)
        
        return () => {
        window.removeEventListener("resize", handleUpdateHeight)
        window.removeEventListener("orientationchange", handleUpdateHeight)
        }
    }, [])
    
    useEffect(() => {
        handleUpdateHeight();
    }, [props.isTopCard])

    return (
        <Wrapper isLarge={props.isLarge}>
            <motion.div
                ref={ref}
                style={{
                    width: props.width || '100%',
                    // height: props.containerDimentions.height,
                    position: "absolute",
                    bottom: 0,
                    x: x,
                    rotate: rotate,
                    transformOrigin: `100% ${centerOfRotation}%`,
                    cursor: "grab",
                    margin: "0 auto"
                }}
                whileTap={{ cursor: "grabbing" }}
                drag={props.drag}
                dragConstraints={{ top: 0, right: 0, bottom: 0, left: 0 }}
                onDragEnd={handleDragEnd}
                initial={props.initial}
                animate={props.animate}
                // animate={controls}
                transition={props.transition}
                exit={{
                    x: props.exitX,
                    // x: '100%',
                    opacity: 1 ,
                    scale: 0.5,
                    zIndex: 100,
                    transition: { duration: 0.500 },
                }}
                // onAnimationComplete={handleUpdateHeight}
            >
                <motion.div
                    style={{
                        width: props.isTopCard ? '100%' : props.width,
                        height: props.isTopCard ? '100%' : props.height,
                        backgroundColor: "#fff",
                        borderRadius: 24,
                        scale: scale,
                    }}
                >
                    {props.isTopCard && <Content  data={props.data} index={localCardIndex} isTopCard={props.isTopCard} updateHeight={props.updateHeight} setCardIndex={handleSetLocalCardIndex}/>}
                </motion.div>
            </motion.div>
        </Wrapper>
    )
}

export default Card

