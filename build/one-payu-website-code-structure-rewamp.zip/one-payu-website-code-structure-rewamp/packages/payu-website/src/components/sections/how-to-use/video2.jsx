import React, {useRef, useState, useEffect} from 'react';
import ReactPlayer from 'react-player/file'
import {styled} from 'frontity'

class Video extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
        isLoaded: false,
        isPlaying: this.props.inView,
        fps: 60,
        page: this.props.page,
        manuallySelectedPage: this.props.manuallySelectedPage,
        markedSeconds : this.props.markedFrames.map((value, index, elements)=>{
                return (  Math.floor(((value )/ 60)*1000)  );  //ms to next part of animation
            })
    };
    this.player = React.createRef();
  }

  UNSAFE_componentWillReceiveProps = (nextProps) => {
      
    if (nextProps.manuallySelectedPage !== this.props.manuallySelectedPage || nextProps.manuallySelectedPage !== this.state.page ) {
        // console.log('next manually sectected: ', nextProps.manuallySelectedPage, 'props.manually selected page:', this.props.manuallySelectedPage, 'timeMap: ', this.state.markedSeconds)
      this.player.seekTo(this.state.markedSeconds[nextProps.manuallySelectedPage]/1000, 'seconds')
    }

    // if (nextProps.page !== this.props.page && nextProps.page == 0) {
    //     this.player.seekTo(0, 'seconds')

    //   }

    if (nextProps.inView !== this.props.inView) {
        this.setState({isPlaying:nextProps.inView});
    }
  }



  handleProgress = state => {
    let currentPage = this.getPageForCurrentTime(state.playedSeconds*1000);
    // if(this.props.page != currentPage) {
    //     this.props.next();
    // }
    // console.log('time:', state.playedSeconds*1000, 'currentPage:', currentPage, 'timeMap: ', this.state.markedSeconds)
    this.setState({page: currentPage});
    this.props.setPage(currentPage);
  }

  handleReady = state => {
    // console.log('classcomp Ready', state)
  }

  handleEnded = state => {
    // console.log('classcomp Ended', state)
    this.player.seekTo(0, 'seconds')
    this.props.resetPage();
  }

  getPageForCurrentTime = time => {
    for(let i = this.state.markedSeconds.length-1; i >=0; i--) {
        if(time >= this.state.markedSeconds[i]) {
            return i;
        }
    }
    return 0;
  }

  ref = player => {
    this.player = player
  }

    render () {

        return(
            <ReactPlayer 
                ref={this.ref}
                url={this.props.video?.url || ''}
                className='react-player'
                playing={this.state.isPlaying}
                width={this.props.width || 'auto'}
                height= {this.props.height || 'auto'}
                controls={false}
                loop={true}
                muted={true}
                playsinline={true}
                progressInterval={500}
                onProgress={this.handleProgress}
                onReady={this.handleLoaded}
                onEnded={this.handleReset}
            />
        )
        
    }
};

export default Video;