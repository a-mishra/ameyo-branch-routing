const postMetaHandler = {
  name: "postmeta",
  priority: 10,
  pattern: "/postmeta/:post_id",
  func: async ({ link, params, state, libraries }) => {
    
    const { post_id } = params;
    // Fetch the postmeta data from the endpoint
    const response = await libraries.source.api.get({
      endpoint: `/postmeta/${post_id}`,
    });

    // Parse the JSON to get the object
    const metaData = await response.json();

    // Add the meta to source.data
    const postmeta = state.source.data[link];

    Object.assign(postmeta, {
      items: metaData,
      isPostMeta: true,
    });

  },
};

export default postMetaHandler;