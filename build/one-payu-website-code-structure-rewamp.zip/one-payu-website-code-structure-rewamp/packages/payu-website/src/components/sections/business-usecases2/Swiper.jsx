import * as React from "react";
import { useRef, useEffect, useState } from "react";
import { motion, useMotionValue, useAnimation } from "framer-motion";
// import { clamp, snap } from "@popmotion/popcorn";
import { InView } from "react-intersection-observer";
import {styled} from 'frontity'
import {layout} from '../../../utils/constants';
import { Container } from '../../misc/layout';

import NavArrowLeftIcon from '../../../assets/icons/arrow-left.svg'
import NavArrowRightIcon from '../../../assets/icons/nav_arrow_right.svg'
import { useWindowDimentions } from "../../../utils/hooks/usehooks";



function useContainerConstraints(ref) {
  const [constraints, setConstraints] = useState({
    top: 0,
    bottom: 0,
    left: 0,
    right: 0
  });

  const setData = () => {
    const element = ref.current;
    const viewportHeight = element?.offsetHeight;
    const contentHeight = element?.firstChild?.offsetHeight;
    const viewportWidth = element?.offsetWidth;
    const contentWidth = element?.firstChild?.offsetWidth;

    setConstraints({
      top: viewportHeight - contentHeight,
      bottom: 0,
      left: viewportWidth - contentWidth,
      right: 0
    });
  }

  useEffect(() => {
    ref.current && setData();
    window.addEventListener("resize", setData)
    window.addEventListener("orientationchange", setData)
    return () => {
      window.removeEventListener("resize", setData)
      window.removeEventListener("orientationchange", setData)
    }
  }, []);

  return constraints;
}



export const Swiper = ({data, sectionWrapperWidth, viewed}) => {
  const x = useMotionValue(0);
  let animControls = useAnimation();
  const [page, setpage] = useState(1);

  const [itemsMargin, setitemsMargin] = useState(0); // |<card>0.5<card>0.5<card>|
  const [itemWidth, setitemWidth] = useState(0);

  const [enableNav, setenableNav] = useState(data?.length <=3 ? false : true);
  const [animationCompleted, setanimationCompleted] = useState(false);
  
  const [swipeConfidenceThreshold, setswipeConfidenceThreshold] = useState(1000);

  const containerRef = useRef(null);
  const { top, bottom, left, right } = useContainerConstraints(containerRef);

  const scrollRef = useRef(null);

  const scrollToPage = (newpage) => {

    if(newpage > data.length - 2) {
      newpage = data.length - 2
    }
    if(newpage < 1) {
      newpage = 1;
    }
    
    const element = containerRef?.current;
    const containerWidth = element?.offsetWidth;

    const boundingBox = element?.getBoundingClientRect();
    const markerLeft = boundingBox?.left;
    const markerRight = boundingBox?.right;
    const markerHorizontalCenter = boundingBox?.left + 0.5 * containerWidth;

    const scrollElem = scrollRef?.current;
    let scrollOffset = 0;


    let traslation_x_Value = (scrollElem?.children?.[newpage]?.getBoundingClientRect()?.left || 0) + ((scrollElem?.children?.[newpage]?.getBoundingClientRect()?.width || 0)/2) - markerHorizontalCenter + scrollOffset ;

    if(data.length <=2)
      traslation_x_Value = (scrollElem?.children?.[0]?.getBoundingClientRect()?.left || 0) - markerLeft + scrollOffset ;

    setpage(newpage);
    translateX(
      traslation_x_Value ,
      1
    );

  };


  function handleWheel_X(event) {
    //event.preventDefault();

    // TODO : enable clamped x scroll , and when number on elements in view == total elements in array, disable scroll;

    // uncomment to allow scroll
    //------------------------------------------
    // const newX = x.get() - event.deltaX;
    // const clampedX = clamp(left, right, newX);
    // x.stop();
    // x.set(clampedX);
  }

  const translateX = (delta, direction) => {
    const newX = x.get() - delta * direction;
    // const clampedX = clamp(left, right, snapTo(newX) + 32);
    // const clampedX = snapTo(newX) + itemsMargin;
    const clampedX = newX;
    x.stop();
    x.start(function () {
      animControls.start({ x: clampedX, transition: { duration: 0.5 } });
    });
    // x.set(clampedX);
  };

  const swipePower = (offset, velocity) => {
    return Math.abs(offset) * velocity;
  };

  const paginate = (newDirection) => {
    scrollToPage(page + newDirection);
  };

  const initialSetup = () => {
    setitemsMargin(sectionWrapperWidth*0.095);
    setitemWidth(sectionWrapperWidth*0.27);
  }

  useEffect(() => {
    scrollToPage(page||1)
  }, [page])

  useEffect(() => {
    initialSetup();
  }, [sectionWrapperWidth])

  const CardAnimations = {
    show : {
      opacity: 1,
      y: 0,
      scale: 1,
    },
    hidden: {
      opacity: 0,
      y: 60
    },
    hover: {
      y: -8,
      zIndex: 10 ,
      transition: { duration: 0.2, delay: 0 }
    },
    outOfScroll: {
      opacity: 0,
      y: 0,
      scale: 0.8,
      transition: { duration: 0.2, delay: 0 }
    },
    inScroll: {
      opacity: 1,
      y: 0,
      scale: 1,
      transition: { duration: 0.2, delay: 0 }
    }
  };

  const ImageAnimation = {
    viewed: {

    },
    hover: {
      // y: -4,
      // zIndex: 10 
    }
  };

  const NavAnimations = {
    showLeft : {
      opacity: 1,
      x: 2
    },
    showRight : {
      opacity: 1,
      x: -2
    },
    hiddenLeft: {
      opacity: 0,
      x: 4
    },
    hiddenRight: {
      opacity: 0,
      x: -4
    },
  }

  return (
    <Wrapper itemsMargin={itemsMargin} sectionWrapperWidth={sectionWrapperWidth} itemWidth={itemWidth} enableNav={enableNav}>
      <div className="swiper-container" ref={containerRef} onWheel={handleWheel_X}>
        <motion.div
          drag={enableNav && "x"}
          dragConstraints={{ top, bottom, left, right }}
          className="scrollable"
          style={{ x }}
          animate={animControls}
          ref={scrollRef}
          dragElastic={1}
          onDragEnd={(e, { offset, velocity }) => {
            const swipe = swipePower(offset.x, velocity.x);
            if (swipe < -swipeConfidenceThreshold) {
              paginate(1);
            } else if (swipe > swipeConfidenceThreshold) {
              paginate(-1);
            }
          }}
          dragMomentum={false}
          transition={{
            x: { type: "spring", stiffness: 300, damping: 10 },
          }}
          
        >
          {data && data.map((elem, index) => (
                  <motion.div
                    onTap={(event) => {
                      event.preventDefault();
                      event.stopPropagation()
                      scrollToPage(index);
                    }}
                    whileHover={'hover'}
                    variants={CardAnimations}
                    className={`swiper-card ${page == index && "active"}`}
                    initial={'hidden'}
                    animate={viewed ? (  animationCompleted ? (Math.abs(page-index)<=1 ? 'inScroll' : 'outOfScroll') : 'show') : 'hidden'}
                    transition={animationCompleted ? {
                       duration: 0.2, delay: 0 
                    } :{ 
                      duration: 0.5, 
                      delay: (0.5)*(index) - 0.1*index + 0.5 
                    }}
                  >
                        <div className="image-wrapper">
                            {elem?.image?.url && <motion.img 
                              variants={ImageAnimation}
                              src={elem?.image?.url} 
                            />}
                        </div>
                        <div className="card-texts">
                            <h3 className="h5">{elem?.heading}</h3>
                            <p className="body2">{elem?.description}</p>
                            {
                                elem?.link?.text && 
                                <motion.a 
                                  href={elem?.link?.url}
                                  whileHover={{
                                    zIndex: 10,
                                    scale:1.05,
                                    x: 4
                                  }}
                                  className="button2"
                                >
                                    {elem?.link?.text}
                                </motion.a>
                            }
                        </div>
                        <FauxShadowContainer/>
                  </motion.div>
          ))}
        </motion.div>
        <motion.div
            className='nav-button left'
            variants={NavAnimations}
            initial={'hidden'}
            animate={viewed ? 'showLeft' : 'hiddenLeft'}
            transition={{ 
              duration: 0.5, 
              delay: (0.5)*(3) - 0.1*3 + 0.5 
            }}
          >
            <NavButton onClick={()=>{paginate(-1)}} inactive={page<=1} type={'left'} />
        </motion.div>
        <motion.div
            className='nav-button right'
            variants={NavAnimations}
            initial={'hidden'}
            animate={viewed ? 'showRight' : 'hiddenRight'}
            transition={{ 
              duration: 0.5, 
              delay: (0.5)*(3) - 0.1*3 + 0.5 
            }}
            onAnimationComplete={()=>{setanimationCompleted(true)}}
          >
            <NavButton onClick={()=>{paginate(1)}} inactive={page>=data.length-2} type={'right'} />
        </motion.div>
      </div>
      
    </Wrapper>
  );
};


const Wrapper = styled.div`

  position: relative;
  display: flex;
  justify-content: center;
  
  visibility: visible;
  display: block;
  ${layout.screen.mob} {
      visibility: hidden;
      display: none;
  }
  
  .swiper-container-wrapper {
    padding: 0px 40px;
  }
  .swiper-container {
    overflow: hidden;
    display: flex;
    flex-direction: row;
    margin: 0px auto;
    padding: 0 ${(props)=>(props.itemsMargin)}px;
    width: ${(props)=>(props.sectionWrapperWidth + 2*props.itemsMargin)}px;
    position: relative;
  }
  
  .scrollable {
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    padding-bottom: 48px;
    padding-top: 24px;
    height: 100%;
    // gap: ${(props)=>(props.itemsMargin)}px; // flex->gap safari <14.1 fix
    position: relative;
  }

  .scrollable > div {
    &:not(:last-child) {
        margin-right: ${(props)=>(props.itemsMargin)}px; // flex->gap safari <14.1 fix
    }
  }
  
  .nav-button {
    position: absolute;
    visibility: ${(props)=>(props.enableNav ? 'visible': 'hidden')};
    top: ${(props)=>(props.itemWidth/2)}px;
    opacity: 0;
    margin: 8px;
  }

  .nav-button.left {
    left: 0px;
  }
  .nav-button.right {
    right: 0px;
  }


  .swiper-card {
    display: flex;
    position: relative;
    background: transparent;
    width: ${(props)=>(props.itemWidth)}px;
    align-self: stretch;
    flex-direction: column;

      .image-wrapper {
        aspect-ratio: 1/1;
        width:100%;
        justify-content: center;
        
        img {
          object-fit: cover;
          width: 100%;
          height: auto;
        }
      }
        
      .card-texts {
        display: flex;
        flex-direction: column;
        flex-grow: 1;
        position:relative;

        margin-top: ${layout.reponsiveCssValue(24, 36, 1440, 29.95, 1600, 36)};
        padding-bottom: ${layout.reponsiveCssValue(36, 52, 1440, 42, 1600, 52)};

        h1,h2,h3,h4,h5,h6 {
            // font-family: "Roboto Slab";
            // font-size: ${layout.reponsiveCssValue(13, 20, 1440, 16.5467, 1600, 20)};
            ${layout.screen.mob} {
              // font-size: 14px;
            }
            // color: #0E342C;
        }
        p {
          margin-top: ${layout.reponsiveCssValue(12, 36, 1440, 15.72, 1600, 19)};
          // color: #2F695D;
        }

        a {
          position: absolute;
          bottom: 0;
          p {
            color: #00AB88;
            font-weight: 600;
          }
        }
      }
    
  }
  
}
`;



const FauxShadowContainer = styled.div`
    position: absolute;
    bottom: -24px;
    height: 12px;
    width: calc( 100%);
    background: #b0b0b016;
    border-radius: 40%;
    z-index: -10;
    margin: 0px auto;
    box-shadow: rgba(149, 157, 165, 0.2) 0px 0px 24px;
`;



// Start : Buttons component

const NavButtonsWrapper = styled.div`
    display: flex;
    justify-content: space-between;
    align-items: center;

    .button {
        cursor: pointer;
        width: 36px;
        height: 36px;
        ${layout.screen.mob} {
          width: 48px;
          height: 48px;
        }
        background: rgba(255, 255, 255, 0.72);
        opacity: 0.8;
        box-shadow: inset 1.65467px 1.65467px 1.65467px rgba(255, 255, 255, 0.25);
        backdrop-filter: blur(26.4748px);
        border-radius: 50%;
        display: flex;
        justify-content: center;
        align-items: center;

        background: rgb(255, 255, 255);
        box-shadow: rgb(255 255 255 / 25%) 2px 2px 2px inset;
        backdrop-filter: blur(32px);
        border-radius: 20px;
        transform: none;
        opacity: 1;
    
        img {
            height: 14px;
            width: auto;
            ${layout.screen.mob} {
              height: 17px;
            }
        }

    }

    .button.left {
      img {
        position: relative;
        right: 1px;
      }
    }

    .button.right {
        img {
            transform: rotate(180deg);
            position: relative;
            left: 1px;
        }
    }

    .button.inactive {
        cursor: not-allowed;
        opacity: 0.5;

        background: rgba(255, 255, 255, 0.72);
        opacity: 0.8;
        box-shadow: inset 2px 2px 2px rgba(255, 255, 255, 0.25);
        backdrop-filter: blur(32px);
        /* Note: backdrop-filter has minimal browser support */

        border-radius:50%;
    }

`;


const NavButtons = ({onClick, isFirstSlide, isLastSlide}) => {
    return (
        <NavButtonsWrapper>
            { left &&
              <motion.div 
                className={`button left ${isFirstSlide ? 'inactive': ''}`} 
                onClick={()=>onClick(-1)} 
                whileHover={isFirstSlide ? {} :{
                  scale: 1.05,
                  transition: { ease: 'anticipate', duration: 0.200 },
                }}
                whileTap={isFirstSlide ? {} : { scale: 0.9 }}
              >
                  <img src={NavArrowLeftIcon}/>
              </motion.div>
            }
            { right &&
              <motion.div 
                className={`button right ${isLastSlide ? 'inactive': ''}`} 
                onClick={()=>onClick(1)}
                whileHover={isLastSlide ? {} :{
                  scale: 1.05,
                  transition: { ease: 'anticipate', duration: 0.200 },
                }}
                whileTap={isLastSlide ? {} : { scale: 0.9 }}
              >
                  <img src={NavArrowLeftIcon}/>
              </motion.div>
            }
        </NavButtonsWrapper>
    )
}

// End : NavButtons component


const NavButton = ({onClick, inactive, type}) => {
  return (
      <NavButtonsWrapper>
            <motion.div 
              className={`button ${type} ${inactive && 'inactive'}`} 
              onClick={onClick} 
              whileHover={inactive ? {} :{
                scale: 1.05,
                // transition: { ease: 'anticipate', duration: 0.200 },
              }}
              whileTap={inactive ? {} : { scale: 0.9 }}
            >
                <img src={NavArrowLeftIcon}/>
            </motion.div>
      </NavButtonsWrapper>
  )
}