import React, {useRef, useState, useEffect} from 'react';
import {styled} from 'frontity'

import { Player } from '@lottiefiles/react-lottie-player';
import { useCounter, useHover } from 'usehooks-ts' 

import { useLottieContainerDimensions } from '../../../utils/hooks/usehooks'; 

const Animation = ({lottie, inView, onLoad, height, width, preserveAspectRatio }) => {

    const player = useRef();
    const playerWrapper = useRef();

    const { count, setCount, increment, decrement, reset } = useCounter(0);
    const [animationDirection, setanimationDirection] = useState(1);
    const [animationState, setanimationState] = useState('');
    const [initalRenderCompleted, setinitalRenderCompleted] = useState(false)
    const [isLoaded, setisLoaded] = useState(false);
    const playerDimentions = useLottieContainerDimensions(playerWrapper, isLoaded);

    const loopStartFrame = lottie?.settings?.loopStartFrame || 0;
    
    const [page, setPage] = useState(0);

    const onEvent = (event) => {
        // take actions for events
        switch(event) {
            case "load": 
                if(inView) {
                    setPlayback(true);
                }
                setisLoaded(true);
                onLoad();
                break;

            case "play": 
                if(initalRenderCompleted) {
                    player?.current.setSeeker((loopStartFrame || 0 ), true);
                }
                break;

            case "frame":
                animationDirection ? increment() : decrement();
                if(count >=(loopStartFrame || 0 ) && initalRenderCompleted == false) {
                    setinitalRenderCompleted(true);
                }
                frameUpdateCheck();

                break;

            default :
                if(['loop', 'stop', 'complete'].includes(event)) {
                    resetAnimation();
                }
                break;
        }

        // update animation state
        if(['load', 'error', 'ready', 'play', 'pause', 'stop', 'freeze', 'complete'].includes(event))
            setanimationState(event);
    }

    const frameUpdateCheck = () => {

    }

    const resetAnimation = () => {
        if(initalRenderCompleted) {
            player?.current.setSeeker(loopStartFrame || 0, true );
        }
        setCount((loopStartFrame || 0 ));
    }

    const startAnimationFromFrame = (frameId) => {
        setCount(frameId);
        player?.current.setSeeker(frameId, true );
    }


    const setPlayback = (flag) => {
        if(flag) {
            if(initalRenderCompleted) {
                player?.current.setSeeker(count, flag);
                player?.current.play();
            }
            else
                player?.current.play();
        } else {
            player?.current.pause();
        }
    }


    useEffect(() => {
        if(inView === true)
            setPlayback(true)
        else if(inView === false)
            setPlayback(false)
    }, [inView])



    const [lottieSrc, setlottieSrc] = useState(null)
    useEffect(() => {
        // fetch(lottie?.media?.url, {priority: 'high'})
        // .then(response => response.json())
        // .then(data => {
        //     console.log('dart from network for animation: ', data)
        //     setlottieSrc(data);
        // });
        // setlottieSrc(getDataFromNetworkOrLocalStorage(lottie?.media?.url));
    }, [])




    return (
        <Wrapper playerDimentions={playerDimentions}>
            <div ref={playerWrapper}>
                <Player
                    onEvent={onEvent}
                    ref={player}
                    autoplay={true}
                    loop={true}
                    src= {lottie?.media?.url}
                    // src= {lottieSrc}
                    style={{ 
                        height:  height || 'auto',
                        width:  width || 'auto', 
                        maxHeight: 620, 
                        maxWidth: 1920
                    }}
                    hover={false}
                    renderer="svg"
                    className="lottie-animation"
                    keepLastFrame={false}
                    rendererSettings={{
                        preserveAspectRatio: preserveAspectRatio || 'xMidYMid slice', // Supports the same options as the svg element's preserveAspectRatio property
                        clearCanvas: false,
                        // className: 'some-css-class-name',
                        // id: 'some-id',
                        // viewBoxOnly: true
                      }}
                >
                </Player>
                
            </div>
        </Wrapper>
    );
}

export default Animation;


const Wrapper = styled.div`
.lf-player-container {
    position: relative;
}
`;
