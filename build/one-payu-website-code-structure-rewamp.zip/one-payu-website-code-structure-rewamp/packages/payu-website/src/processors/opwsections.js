import React, {useEffect} from 'react'
import { styled, connect, loadable } from 'frontity'

// import SectionTestimonials from '../components/sections/testimonials/index';
// import SectionContactUs from '../components/sections/contact-us/index'
// import SectionGettingStarted from '../components/sections/getting-started/index'
// import SectionFAQ from '../components/sections/faq/index'
// import SectionHowToUse from '../components/sections/how-to-use/index'
// import SectionPricing from '../components/sections/pricing/index'
import SectionHero from '../components/sections/hero/index'
// import SectionProductFeatures from '../components/sections/product-features2/index'
// import SectionBusinessUsecases from '../components/sections/business-usecases2/index'

// import SectionPopularPlugins from '../components/sections/popular-plugins/index'
// import SectionCheckoutCards from '../components/sections/checkout-cards/index'
// import SectionTabbedComponent from '../components/sections/tabbed-component/index'

// import SectionPlans from '../components/sections/plans/index'

const SectionTestimonials = loadable(()=>import('../components/sections/testimonials/index'));
const SectionContactUs = loadable(()=>import('../components/sections/contact-us/index'));
const SectionGettingStarted = loadable(()=>import('../components/sections/getting-started/index'));
const SectionFAQ = loadable(()=>import('../components/sections/faq/index'));
const SectionHowToUse = loadable(()=>import('../components/sections/how-to-use/index'));
const SectionPricing = loadable(()=>import('../components/sections/pricing/index'));
// const SectionHero = loadable(()=>import('../components/sections/hero/index'));
const SectionProductFeatures = loadable(()=>import('../components/sections/product-features2/index'));
const SectionBusinessUsecases = loadable(()=>import('../components/sections/business-usecases2/index'));

const SectionPopularPlugins = loadable(()=>import('../components/sections/popular-plugins/index'));
const SectionCheckoutCards = loadable(()=>import('../components/sections/checkout-cards/index'));
const SectionTabbedComponent = loadable(()=>import('../components/sections/tabbed-component/index'));

const SectionPlans = loadable(()=>import('../components/sections/plans/index'));
const SectionPricingHero = loadable(()=>import('../components/sections/pricing-hero/index'));
const SectionFAQDropDown = loadable(()=>import('../components/sections/faq-dropdown/index'));
const SectionPlansTable = loadable(()=>import('../components/sections/plans-table/index'));


import TestFooter from '../components/sections/footer';
import TestHeader from '../components/sections/header';
import { Section } from '../components/misc/layout';


const FallBackWrapper = styled.div`
    display: block;
`;

const ComponentWrapper = connect(({state, actions, data, sectionType}) => {

    useEffect(() => {
        data?.section?.name && actions.intraPageLinks.push({title: data?.section?.name, link: data?.section?.internalLink, active: false, sectionType: sectionType});
    }, [])

    switch(sectionType.value) {
        
        case 'testimonial': 
            return (
                <SectionTestimonials data={data} />
            )
            break;

        case 'contactUs': 
            return (
                <SectionContactUs data={data} />
            )
            break;

        case 'gettingStarted': 
            return (
                <SectionGettingStarted data={data} />
            )
            break;

        case 'faq': 
            return (
                <SectionFAQ data={data} />
            )
            break;
        
        case 'howToUse':
            return(
                <SectionHowToUse data={data} />
            )
            break;
        
        case 'pricing':
            return(
                <SectionPricing data={data} />
            )
            break;
        
        case 'hero':
            return(
                <SectionHero data={data} />
            )
            break;

        case 'footer':
            return(
                <TestFooter data={data} />
            )
            break;

        case 'productFeatures2':
            return(
                <SectionProductFeatures data={data} />
            )
            break;

        case 'businessUsecases2':
                return(
                    <SectionBusinessUsecases data={data} />
                )
                break;
        
        case 'howToUseTypeImageTransition':
            return(
                <SectionHowToUse data={data} isImageTransitionType={true} />
            )
            break;
        
        case 'header':
            return(
                <TestHeader data={data} />
            )
            break;

        // Phase 2 components
        case 'popularPlugins':
            return(
                <SectionPopularPlugins data={data} />
            )
            break;

        case 'checkoutCards':
            return(
                <SectionCheckoutCards data={data} />
            )
            break;

        case 'tabbedComponent':
            return(
                <SectionTabbedComponent data={data} />
            )
            break;

        case 'plans' : 
            return(
                <SectionPlans data={data}/>
            )
            break;

        case 'pricingHero' : 
            return(
                <SectionPricingHero data={data}/>
            )
            break;

        case 'faqDropDown' : 
            return(
                <SectionFAQDropDown data={data}/>
            )
            break;


        case 'plansTable' : 
            return(
                <SectionPlansTable data={data}/>
            )
            break;
            
            
        default:
            return(
                <Section>
                    {`Section type "${sectionType.value}" not supported!!!`}
                </Section>
                )
    }
});

const opwsections = {
    name: 'opwsections',
    priority: 20,
    test: ({ component, props }) => component === "div" && props.className.split(' ').includes("wp-block-cgb-block-opwsections"),
    processor: ({ node,props }) => {

        let attributes = JSON.parse(node.children[0].children[0].content || '{}'); 
        let data = JSON.parse(attributes.data || '{}');
        let sectionType = JSON.parse(attributes.sectionType || '{}');

        return {
          component: ComponentWrapper,
          props: {data, sectionType},
        }
      },
}

export default opwsections;