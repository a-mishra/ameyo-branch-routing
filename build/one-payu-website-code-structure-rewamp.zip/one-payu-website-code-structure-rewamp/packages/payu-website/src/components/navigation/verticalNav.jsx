import React, {useRef} from 'react'
import {styled, connect} from 'frontity';
import { layout } from '../../utils/constants';
import {
    motion,
    useSpring
  } from "framer-motion";
import { useHover } from 'usehooks-ts' 

const Wrapper = styled.div`
  ${layout.screen.mob} {
      display:none;
  }

    .vertical-nav-scroll {
        position: fixed;
        // top: ${layout.constants.headerHeight};
        top: 0px;
        bottom:0px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        gap: 3rem;
        margin-left: ${layout.constants.padding.level1};
        z-index: 10;
    }
`;

const VerticalNav = ({state}) => {
    return (
        <Wrapper>
            <div class="vertical-nav-scroll">
                {
                    state?.intraPageLinks?.map((elem, index)=>(
                        <ScrollItem link={elem.link} title={elem.title} active={elem.active}/>
                    ))
                }
            </div>
        </Wrapper>
    )
}

export default connect(VerticalNav)



const springConfig = {
    damping: 100,
    stiffness: 10,
    mass: 3
};

const ScrollItem = ({link, active, title}) => {

    const hoverRef = useRef(null);
    const isHover = useHover(hoverRef);
    const motionStyles = useSpring(
        springConfig
    );
    return (
        <ScrollItemWrapper >
            <a ref={hoverRef} href={`#${link}`} className={`small ${active && 'active'}`}>{title}</a>
            {(active || isHover) && <motion.div 
                initial={{height: "0px", top: "-0.5rem" }}
                style={motionStyles}
                animate={{
                    height: "20px",
                    transition: { delay: 0 },
                    top: "0rem"
                }}
                exit={{ height: "0px", top: "-0.5rem" }}
                className={"bottom-border"}
            />
            }
        </ScrollItemWrapper>
    )
}

const ScrollItemWrapper = styled.span`

    writing-mode: vertical-lr;
    transform: rotate(180deg);
    padding-left: 0.5rem;

    a {
        text-decoration: none;
        text-align: left;
        display: block;
        transition: all 0.4s ease-in-out;
        padding: 0rem 0.5rem;
        font-weight: 400;
        color: #96A5A2;

        &:hover {
            color: #00AB88;
            // &::after {
            //     transition: all 0.4s ease-in-out;
            //     position: absolute;
            //     content: '';
            //     display: block;
            //     width: 20px;
            //     height: 2px;
            //     background: #00AB88;
            //     top: 0.5rem;
            //     transform: rotate(90deg);
            //     left: 0rem;
            // }
        }
    }

    a.active {
        color: #00AB88;
    }


    .bottom-border {
        display: block;
        position: absolute;
        height: 20px;
        width: 2px;
        background: #00AB88;
        top: 0;
        left: 0.5rem;
        border-radius: 1px;
    }
`;