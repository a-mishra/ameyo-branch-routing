const domain = process?.env?.DOMAIN || "https://betatest.payu.in";
const wp_url = process?.env?.WORDPRESS_SOURCE_URL || "https://devguidetest.payu.in/wordpress/index.php";
const trackerId = process?.env?.TRACKER_ID || "GTM-P8DW2RX" ;
const homepage = process?.env?.HOMEPAGE || "/home/" ;

const settings = {
  "name": "payu-website",
  "state": {
    "frontity": {
      "url": domain,
      "title": "PayU",
      "description": "wordpress headless and frontity site",
    }
  },
  "packages": [
    {
      "name": "payu-website",
      "state": {
        "theme": {
        },
      },
    },
    {
      "name": "@frontity/wp-source",
      "state": {
        "source": {
          "url": wp_url,
          "homepage": homepage
        }
      }
    },
    "@frontity/tiny-router",
    "@frontity/html2react",
    {
      name: "@frontity/yoast",
      state: {
        yoast: {
          renderTags: "both",
          transformLinks: {
            ignore: "^",
          },
        },
      },
    },
    {
      name: "@frontity/google-tag-manager-analytics",
      state: {
        googleTagManagerAnalytics: {
          containerId: trackerId,
        },
      },
    }
  ]
};

export default settings;

