import React, {  useRef, useEffect, useState, useLayoutEffect } from 'react'
import { connect, styled , Global, css} from 'frontity';
import {layout, SectionAnimation} from '../../../utils/constants';
import {useOnScreen, useWindowDimentions, useContainerDimensions} from '../../../utils/hooks/usehooks'
import { Section, Row, Col, Container } from '../../misc/layout';
import { motion, useMotionValue, useAnimation } from "framer-motion";
import ThreadImage from './backgroundVector.png';
import { Swiper } from './Swiper';

const SectionWrapper = styled.div`
    min-height: 300px;
    position: relative;
    overflow-x: clip;

    .section-container {

        ${layout.screen.mob} {
            // padding-left: 0px;
            // padding-right: 0px;
        }
    }
    
    .section-inner {

        .heading-texts {
            h1,h2,h3,h4,h5,h6 {
                color: #141416;
                margin: 0px;
            }
            padding-bottom: ${layout.reponsiveCssValue(64, 86, 1200, 64, 1600, 86)};

            h2 {
                display: block;
            }

            h3 {
                display: none;
            }

            ${layout.screen.mob} {
                h2 {
                    display: none;
                }
                h3 {
                    display: block;
                }
                padding-bottom: 62px;
            }

            p {
                margin-top: 1rem;
                color: #2F695D;
            }
            

        
        }


        .cards-container {
            display: flex;
            justify-content: space-between;
            flex-direction: row;
            flex-wrap: wrap;
            gap: ${layout.reponsiveCssValue(41, 58, 1200, 41, 1600, 58 )};
            row-gap: ${layout.reponsiveCssValue(152, 160, 1200, 152, 1600, 160 )};
            padding-top: ${layout.reponsiveCssValue(36, 42, 1200, 42, 1600, 36)};

            display: grid;
            grid-template-columns: 1fr 1fr;

            ${layout.screen.mob} {
                gap: 18px;
                display:none;
            }
        }
    }


    .thread-image {
        width: 110%;
        position: absolute;
        top: 360px;
        z-index: -1;
        img {
            object-fit: cover;
        }

        ${layout.screen.mob} {
            position: absolute;
            height: 100%;
            top: 0;
            img {
                width: 100%;
                position: absolute;
                top: 50%;
                // left: 33%;
                // transform: translate(-50%, -50%);
                max-height: 500px;
            }
            display: none;
        }
    }


`;

const BackgroundMediaAnimation = {
    hidden: { opacity: 0, scale: 1, y: 0 },
    show: {
        opacity: 1,
        scale: 1,
        y: 0
    },
    transition: (n, longDelay=false) => ({
        // y: { type: "spring",
        //   damping: 10,
        //   mass: 0.2,
        //   stiffness: 150
        //  }, 
        ease: 'anticipate',
        duration: longDelay ? 0.8 : 0.5, 
        delay: (longDelay ? 0.8 : 0.5)*(n) - 0.1*n, 
    })
}

const CardAnimation = {
    hidden: {scale: 0.9, opacity: 0, y: 60 },
    show: {
        scale: 1,
        opacity: 1,
        y: 0
    },
    transition: (n, longDelay=false) => ({
        // y: { type: "spring",
        //   damping: 10,
        //   mass: 0.2,
        //   stiffness: 150
        //  }, 
        ease: 'anticipate',
        duration: longDelay ? 0.8 : 0.5, 
        delay: (longDelay ? 0.8 : 0.3)*(n) - 0.1*n+0.5, 
    })
}


const SectionCheckoutCards = ({state, actions, data, libraries}) =>  {

    const ref = useRef(null)
    const [onScreen, portionInView, viewed] = useOnScreen(ref, "0px");
    const Html2React = libraries.html2react.Component;


    useEffect(() => {
        actions.intraPageLinks.update(data?.section?.internalLink, portionInView);
        return () => {
            actions.intraPageLinks.update(data?.section?.internalLink, 0);
        }
    }, [portionInView])


    useEffect(() => {
        return () => {
        }
    }, [])


    const [page, setpage] = useState(0)
    const handleCardSelect = (page) => {
        setpage(page);
    }

    return (
        <>
            <SectionWrapper id={data?.section?.internalLink}>
                <Section padding={'level4'} className={'section-container'}>
                    <motion.div 
                        className="section-inner"
                        ref={ref}
                    >
                        


                                
                                    <motion.div className="heading-texts"
                                        variants={SectionAnimation}
                                        initial={'hidden'}
                                        animate={viewed ? 'show' : 'hidden'}
                                        transition={{ 
                                            ...SectionAnimation.transition(0, true)
                                        }}
                                    >
                                        <h2>{<Html2React html={data?.heading || ''} />}</h2>
                                        <h3>{<Html2React html={data?.heading || ''} />}</h3>
                                        <p>{<Html2React html={data?.description || ''} />}</p>
                                    </motion.div>


                                        <motion.div 
                                            className={'cards-container'}
                                            // variants={CardAnimation}
                                            // initial={'hidden'}
                                            // animate={viewed ? 'show' : 'hidden'}
                                            // transition={{ 
                                            //     // duration: 0.5, 
                                            //     // delay: 0.7,
                                            //     ...CardAnimation.transition(1)
                                            // }}
                                        >
                                            {data?.cards?.map((elem, index)=>(
                                                <Card 
                                                {...elem} 
                                                index={index} 
                                                onClick={()=>{setpage(index)}}
                                                isLarge={data?.settings?.cardSize?.value == 'large' ? true : false}
                                                viewed={viewed}
                                                />
                                            ))}

                                        </motion.div>

                                        {/* write the sciper piece for mobile; */}
                                        

                    </motion.div>
                </Section>

                {
                    data?.settings?.enableBackgroundImage?.value == 'true' && <motion.div 
                className="thread-image"
                variants={BackgroundMediaAnimation}
                    initial={'hidden'}
                    animate={viewed ? 'show' : 'hidden'}
                    transition={{
                        ...BackgroundMediaAnimation.transition(3)
                    }}
                >
                    <img src={ThreadImage} />
                </motion.div>}

                <Container>
                    <motion.div
                        className="mobile-swiper-wrapper"
                    >
                        <Swiper data={data && data.cards || []} page={page} setpage={(page)=>{
                            handleCardSelect(page)
                        }}/>
                    </motion.div>
                </Container>

            </SectionWrapper>
        </>
    )

}

export default connect(SectionCheckoutCards)

const CardWrapper = styled.div`

display: flex;
flex-basis: 300px;
flex-grow: 1;

${layout.screen.mob} {
    width: 80vw;
    max-width: 300px;
}


.card {

    background: #FFFFFF;

    &.translucent {

        background: rgba(255, 255, 255, 0.4);
        border: 1.81956px solid rgba(255, 255, 255, 0.72);
        box-sizing: border-box;
        backdrop-filter: blur(9px);
        /* Note: backdrop-filter has minimal browser support */

        border-radius: 25.4738px;
    }

    display: flex;
    flex-direction : row;

    border-radius: 28px;
    ${layout.screen.mob} {
        border-radius: 12px;
        flex-direction: column;
    }


    
    .image-container {
        height: inherit;
        position: relative;
        flex-shrink: 0;
        width: ${layout.reponsiveCssValue(180, 240, 1200, 180, 1600, 240)};
        ${layout.screen.mob} {
            width: 100%;
            max-width: 400px;
        }

        img {
            // top: ${layout.reponsiveCssValue(-42, -36, 1200, -42, 1600, -36)};
            bottom: ${layout.reponsiveCssValue(12, 24, 1200, 12, 1600, 24)};
            position: absolute;
            z-index: 10;
            ${layout.screen.mob} {
                position: relative;
            }
        }

        .image-shadow-wrapper.enabled {
            position: absolute;
            bottom: 24px;
            width: 100%;
            height: 24px;
            margin-top: 16px;
            z-index: 9;

            ${layout.screen.mob} {
                display: none;
            }

            .image-shadow {
                width: 80%;
                height: 24px;
                margin: 0px auto;
                background: #CDC7C7;
                mix-blend-mode: multiply;
                border-radius: 50%;
                opacity: 0.5;
                filter: blur(20.5382px);
                transform: matrix(1, 0.01, -0.01, 1, 0, 0);
            }
        }

        
    }
    .text-button-container {
        display: flex;
        flex-direction: column;

        padding-top: ${layout.reponsiveCssValue(32,48, 1200, 32, 1600, 48)};
        padding-bottom: ${layout.reponsiveCssValue(24,32, 1200, 24, 1600, 32)};
        padding-left: ${layout.reponsiveCssValue(16, 24, 1200, 16, 1600, 24)};
        padding-right: ${layout.reponsiveCssValue(32,27, 1200, 32, 1600, 27)};
        
        ${layout.screen.mob} {
            padding-top: ${layout.reponsiveCssValue(20,48, 375, 64, 992, 48)};
            padding-top: 0px;
            padding-bottom: ${layout.reponsiveCssValue(20,48, 375, 64, 992, 48)};
            padding-left: ${layout.reponsiveCssValue(27,64, 375, 28, 992,64 )};
            padding-right: ${layout.reponsiveCssValue(27,64, 375, 28, 992,64 )};
        }
    
        .texts {
            h1,h2,h3,h4,h5,h6 {
                color: #141416;
                margin: 0px;
            }

            h2 {
                display: block;
                font-family: Roboto Slab;
                font-style: normal;
                font-weight: 500;
                font-size: 18.1955px;
                line-height: 29px;
                /* identical to box height, or 160% */


                color: #000000;
            }

            h3 {
                display: none;
            }

            ${layout.screen.mob} {
                h2 {
                    display: none;
                }
                h3 {
                    display: block;
                }
            }

            p {
                margin-top: 1rem;
                color: #2F695D;

                font-family: Open Sans;
                font-style: normal;
                font-weight: normal;
                font-size: 14.5564px;
                line-height: 24px;
                /* or 162% */

                letter-spacing: 0.909778px;

                /* Text 3 */

                color: #2F695D;

            }        
        }
        
        .link-wrapper {
            margin-top: 40px;
            p {

                color: #00AB88;
            }
        }

    }
}
`;

const Card = ({index, heading, description, link, media, viewed, type}) => {
    return(
        <CardWrapper>
            <motion.div 
                className={`card ${type?.value}`}
                variants={CardAnimation}
                initial={'hidden'}
                animate={viewed ? 'show' : 'hidden'}
                transition={{
                    ...CardAnimation.transition(index)
                }}
            >
                <div className="image-container">
                    {
                        <motion.img 
                            className={'image-item'}
                            alt={media?.image?.name}
                            src={media?.image?.url}
                        />
                    }

                    {
                        <div className={`image-shadow-wrapper ${media?.shadow?.value == 'true' && 'enabled'}`}>
                            <div className={'image-shadow'}>
                            </div>
                        </div>
                        
                    }
                </div>
                <div className="text-button-container">
                    <div className="texts">
                        <h3>{heading}</h3>
                        <h2>{heading}</h2>
                        <p>{description}</p>
                    </div>
                    
                    <motion.a
                        className="link-wrapper"
                        variants={CardAnimation}
                        initial={{ opacity: 0}}
                        animate={viewed ? { opacity: 1} : {}}
                        href={link?.url || 'javascript::void(0)'}
                        whileHover={{
                            scale: 1.02,
                            transition: { ease: 'anticipate', duration: 0.200 },
                        }}
                        whileTap={{ scale: 0.98 }}
                    >
                        <p className='button2'>{link?.text}</p>
                    </motion.a>
                </div>
                
            </motion.div>
        </CardWrapper>
    )
}