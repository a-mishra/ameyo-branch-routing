import React, {useRef, useState, useEffect} from 'react';
import { Player, Controls } from '@lottiefiles/react-lottie-player';
import { useCounter, useHover } from 'usehooks-ts' 
import { useOnScreen, useLottieContainerDimensions } from '../../../utils/hooks/usehooks'; 
import {styled} from 'frontity'

const MobileAnimation = ({lottie, markedFrames,setpage, page, inView, onLoad, height, width }) => {

    const player = useRef();
    const playerWrapper = useRef();

    const { count, setCount, increment, decrement, reset } = useCounter(0);
    const [animationDirection, setanimationDirection] = useState(1);
    const [animationState, setanimationState] = useState('');
    const [initalRenderCompleted, setinitalRenderCompleted] = useState(false)
    const [isLoaded, setisLoaded] = useState(false);
    const playerDimentions = useLottieContainerDimensions(playerWrapper, isLoaded);

    const loopStartFrame = lottie?.settings?.loopStartFrame || 0;
    
    // const [page, setPage] = useState(0);

    const onEvent = (event) => {
        // take actions for events
        switch(event) {
            case "load": 
                if(inView) {
                    setPlayback(true);
                }
                setisLoaded(true);
                onLoad();
                break;

            case "play": 
                if(initalRenderCompleted) {
                    player?.current.setSeeker((loopStartFrame || 0 ), true);
                }
                break;

            case "frame":
                animationDirection ? increment() : decrement();
                if(count >=(loopStartFrame || 0 ) && initalRenderCompleted == false) {
                    setinitalRenderCompleted(true);
                }
                frameUpdateCheck();

                break;

            default :
                if(['loop', 'stop', 'complete'].includes(event)) {
                    resetAnimation();
                }
                break;
        }

        // update animation state
        if(['load', 'error', 'ready', 'play', 'pause', 'stop', 'freeze', 'complete'].includes(event))
            setanimationState(event);
    }

    const frameUpdateCheck = () => {
        let newPage = 0;
        for(let i = markedFrames.length-1 ; i >- 0; --i  ) {
            if(count >= markedFrames[i]) {
                newPage = i;
                break;
            }
        }

        if(newPage != page) {
            setpage(newPage);
            // frameRangeChangedCallback(newPage);
        }
    }

    const resetAnimation = () => {
        if(initalRenderCompleted) {
            player?.current.setSeeker(loopStartFrame || 0, true );
        }
        setCount((loopStartFrame || 0 ));
    }

    const startAnimationFromFrame = (frameId) => {
        setCount(frameId);
        player?.current.setSeeker(frameId, true );
    }

    // useEffect(() => {
    //     if(isLoaded) {
    //         startAnimationFromFrame(startFromFrame)
    //     } 
    // }, [startFromFrame])

    useEffect(() => {
        if(isLoaded) {
            // check if need to set tot he starting frame;
            if(count >= markedFrames[page] && markedFrames[page+1] && count < markedFrames[page+1]) {
                // donothing
            } else {
                startAnimationFromFrame(markedFrames[page]);
            }
        } 
    }, [page])

    const setPlayback = (flag) => {
        if(flag) {
            if(initalRenderCompleted) {
                player?.current.setSeeker(count, flag);
                player?.current.play();
            }
            else
                player?.current.play();
        } else {
            player?.current.pause();
        }
    }


    // useEffect(() => {
    //     setPlayback(startFromFrame) // hover off karne par animation pause ho jayega, agar shouldPlay false hai to || Agar shouldPlay true hai to hover off ka koi effect nahi aayega.
    // }, [startFromFrame])

    useEffect(() => {
        if(inView === true)
            setPlayback(true)
        else if(inView === false)
            setPlayback(false)
    }, [inView])

    return (
        <div>
            <div ref={playerWrapper}>
                <Player
                    onEvent={onEvent}
                    ref={player}
                    autoplay={true}
                    loop={true}
                    src= {lottie?.media?.url}
                    style={{ 
                        // height: 'auto', 
                        // width:  'auto', 
                        // maxHeight: '700px', 
                        // maxWidth: '500px'

                        height:  height || 'auto',
                        width:  width || 'auto', 
                        maxHeight: '100%', 
                        maxWidth: 640,
                        overflow: 'visible'
                    }}
                    hover={false}
                    renderer="svg"
                    className="lottie-animation"
                    keepLastFrame={true}
                    // rendererSettings={{
                    //     preserveAspectRatio: 'xMidYMid meet', // Supports the same options as the svg element's preserveAspectRatio property
                    //     clearCanvas: false,
                    //   }}
                    rendererSettings={{
                        preserveAspectRatio: 'xMidYMid meet', // Supports the same options as the svg element's preserveAspectRatio property
                        clearCanvas: false,
                        // className: 'some-css-class-name',
                        // id: 'some-id',
                        viewBoxOnly: true
                      }}
                >
                    {/* <Controls
                        transparentTheme={true}
                        showLabels={true}
                        visible={true}
                        buttons={['play', 'repeat', 'frame', 'debug', 'snapshot', 'background', 'stop']}
                    /> */}
                </Player>
                
            </div>
            
              {
                //   isLoaded && <FauxShadowContainer width={playerDimentions && playerDimentions.svgWidth || 0}/>
              }
            
        </div>
    );
}

export default MobileAnimation;

const FauxShadowContainer = styled.div`
    position: absolute;
    bottom: -72px;
    height: 24px;
    background: #DDE2DF5c;
    border-radius: 50%;
    z-index: -10;
    margin: 0px auto;
    // filter: drop-shadow(0px 72px 4px #DDE2DF);

    position: absolute;
    bottom: -72px;
    height: 18px;
    width: calc( ${(props) => props.width}px * 1 );
    background: #b0b0b016;
    border-radius: 40%;
    z-index: -10;
    margin: 0px auto;
    box-shadow: rgba(149, 157, 165, 0.2) 0px 0px 24px;
`;