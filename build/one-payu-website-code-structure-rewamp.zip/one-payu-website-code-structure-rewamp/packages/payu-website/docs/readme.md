- [x] pricing: https://one-payu-website.vercel.app/block-pricing
- [x] getting-started: https://one-payu-website.vercel.app/block-gettingstarted
- [x] contact-us: https://one-payu-website.vercel.app/block-contactus
- [x] HowToUse: https://one-payu-website.vercel.app/block-howtouse
- [x] ProductFeature: https://one-payu-website.vercel.app/block-product-feature
- [x] business-usecase: https://one-payu-website.vercel.app/block-business-usecase/
- [x] faq: https://one-payu-website.vercel.app/block-faq/
- [x] testimonial: https://one-payu-website.vercel.app/block-testimonial/
- [x] HowToUse(Image Transitions): https://one-payu-website.vercel.app/block-howtouse2


Home: https://one-payu-website.vercel.app/home
product: https://one-payu-website.vercel.app/web-payment-links