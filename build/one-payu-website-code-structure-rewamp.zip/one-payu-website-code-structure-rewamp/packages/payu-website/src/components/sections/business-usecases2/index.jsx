import React, {  useRef, useEffect, useState, useLayoutEffect } from 'react'
import { connect, styled , Global, css} from 'frontity';
import {layout, SectionAnimation} from '../../../utils/constants';
import {useOnScreen, useWindowDimentions, useContainerDimensions} from '../../../utils/hooks/usehooks'
import { Section, Row, Col, Container } from '../../misc/layout';
import { motion, useMotionValue, useAnimation } from "framer-motion";
import { Swiper } from './Swiper'
import { MobileSwiper } from './mobile-swiper'
import { VerticalMobileSwiper } from './mobile-swiper-vertical'

const SectionWrapper = styled.div`
    position: relative;
    overflow-x: clip;
    
    .texts {
        ${layout.screen.mob} {
            margin-bottom: 3.5rem;
        }
        p {
            margin-top: ${layout.reponsiveCssValue(9,12, 1440,9.8,1600,12)};
        }
        // margin-bottom: ${layout.reponsiveCssValue(58, 88, 1400, 72, 1600, 88)};
        margin-bottom: ${layout.reponsiveCssValue(34, 64, 1400, 48, 1600, 64)};
    }

`;


const SectionBusinessUsecases = ({state, actions, data, libraries}) =>  {

    const ref = useRef(null)
    const ref2 = useRef(null)
    const [onScreen, portionInView, viewed] = useOnScreen(ref2, "0px");
    const Html2React = libraries.html2react.Component;
    const [initalAnimationCompleted, setinitalAnimationCompleted] = useState(false);
    useEffect(() => {
        actions.intraPageLinks.update(data?.section?.internalLink, portionInView);
        return () => {
            actions.intraPageLinks.update(data?.section?.internalLink, 0);
        }
    }, [portionInView])

    const [width, setwidth] = useState(0);

    const handleResize = () => {
        if(ref.current) {
            setwidth(ref.current.offsetWidth);
        }
    }
    
    useEffect(() => {
        handleResize();
        window.addEventListener("resize", handleResize)
        window.addEventListener("orientationchange", handleResize)
        return () => {
        window.removeEventListener("resize", handleResize)
        window.removeEventListener("orientationchange", handleResize)
        }
    }, [])

    return (
        <>
            <SectionWrapper ref={ref2} id={data?.section?.internalLink}>
                <Section style={{marginBottom: 'unset', minHeight:'unset'}}  padding={'level4'} className="section-container" >
                    <motion.div 
                        className="texts"
                        ref={ref}
                        variants={SectionAnimation}
                        initial={'hidden'}
                        animate={viewed ? 'show' : 'hidden'}
                        transition={{
                            ...SectionAnimation.transition(0, true)
                        }}
                        onAnimationComplete={handleResize}
                    >
                        <h3 className='h3'>{data.heading}</h3>
                        <p className={'body2'}>{data.description}</p>
                    </motion.div>
                </Section>

                <Swiper data={data && data.cards || []} sectionWrapperWidth={width} viewed={viewed} />
                {/* <MobileSwiper data={data && data.cards || []} sectionWrapperWidth={width} viewed={viewed} /> */}
                <VerticalMobileSwiper data={data && data.cards || []} sectionWrapperWidth={width} viewed={viewed} />

            </SectionWrapper>
        </>
    )

}

export default connect(SectionBusinessUsecases)




