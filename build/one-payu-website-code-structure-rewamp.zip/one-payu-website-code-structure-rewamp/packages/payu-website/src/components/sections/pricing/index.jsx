import React, {  useRef, useEffect, useState, useLayoutEffect } from 'react'
import { connect, styled , Global, css} from 'frontity';
import {layout, SectionAnimation} from '../../../utils/constants';
import {useOnScreen, useWindowDimentions, useContainerDimensions} from '../../../utils/hooks/usehooks'
import { Section, Row, Col, Container } from '../../misc/layout';
import { motion, useMotionValue, useAnimation } from "framer-motion";


const SectionWrapper = styled.div`
    min-height: 300px;
    position: relative;
    overflow-x: clip;
    
    .section-inner {
        background: #FFFFFF;
        border-radius: 28px;
        ${layout.screen.mob} {
            border-radius: 12px;
        }
        display: flex;
        flex-direction : row;

        ${layout.screen.mob} {
            flex-direction: column;
        }

        .image-container {
            flex: 3;
            height: inherit;
            position: relative;
            img {
                position: absolute;
                height: 100%;
                width: 100%;
                object-fit: cover;
                ${layout.screen.mob} {
                    position: unset;
                }
            }
            
        }
        .text-button-container {
            display: flex;
            flex-direction: column;
            flex: 4;
            padding-top: ${layout.reponsiveCssValue(48,60, 1440, 52, 1600, 60)};
            padding-bottom: ${layout.reponsiveCssValue(48,60, 1440, 52, 1600, 60)};
            padding-left: ${layout.reponsiveCssValue(64,78, 1440, 72, 1600,78 )};
            padding-right: ${layout.reponsiveCssValue(64,78, 1440, 72, 1600,78 )};
            
            ${layout.screen.mob} {
                padding-top: ${layout.reponsiveCssValue(20,48, 375, 20, 992, 48)};
                padding-bottom: ${layout.reponsiveCssValue(20,48, 375, 20, 992, 48)};
                padding-left: ${layout.reponsiveCssValue(27,64, 375, 27, 992,64 )};
                padding-right: ${layout.reponsiveCssValue(27,64, 375, 27, 992,64 )};
            }

            .texts {
                h1,h2,h3,h4,h5,h6 {
                    // color: #0E342C;
                    margin: 0px;
                }
                p {
                    margin-top: 1rem;
                    // color: #40413B;
                }
                margin-bottom: ${layout.reponsiveCssValue(24,33, 1440, 28, 1600,33 )};
            
            }

            .buttons-wrapper {
                display: flex;
                flex-direction: row;
                gap: 1.5rem;
            }

        }
    }


`;


const SectionPricing = ({state, actions, data, libraries}) =>  {

    const ref = useRef(null)
    const [onScreen, portionInView, viewed] = useOnScreen(ref, "0px");
    const Html2React = libraries.html2react.Component;


    useEffect(() => {
        actions.intraPageLinks.update(data?.section?.internalLink, portionInView);
        return () => {
            actions.intraPageLinks.update(data?.section?.internalLink, 0);
        }
    }, [portionInView])


    // useEffect(() => {
    //     console.log(`Pricing`,data)
    //     return () => {
    //     }
    // }, [])

    return (
        <>
            <SectionWrapper id={data?.section?.internalLink}>
                <Section padding={'level1'}>
                    <motion.div 
                        className="section-inner"
                        ref={ref}
                        variants={SectionAnimation}
                        initial={'hidden'}
                        animate={viewed ? 'show' : 'hidden'}
                        transition={{
                            ...SectionAnimation.transition(0, true)
                        }}
                    >
                        <div className="image-container">
                            <img src={data.image?.url} />
                        </div>
                        <div className="text-button-container">
                            <div className="texts">
                                <h2 className='h2'>{data?.heading}</h2>
                                <p className='body2'>{data?.description}</p>
                            </div>
                            {data?.buttons && data?.buttons.length > 0 && 
                                <motion.div
                                    className="buttons-wrapper"
                                    variants={SectionAnimation}
                                    initial={{x: 16, opacity: 0}}
                                    animate={viewed ? {x:0, opacity: 1} : {}}
                                    transition={{
                                        // staggerChildren: 0.1,
                                        // delayChildren: 0.3,
                                        // duration: 0.5,
                                        // delay: 0.5
                                    }}
                                >
                                    {
                                        data?.buttons?.map((elem, index)=>(
                                            <Button title={elem?.title} link={elem?.link} type={elem?.type?.value || 'dark'}/>
                                        ))
                                    }
                                </motion.div>
                            }
                        </div>
                    </motion.div>
                </Section>
            </SectionWrapper>
        </>
    )

}

export default connect(SectionPricing)



// Start : Buttons component

const ButtonWrapper = styled.div`
    display: flex;
    justify-content: start;
    align-items: center;

    .button {
        cursor: pointer;
        margin-right: 12px;
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        // border-width: ${layout.reponsiveCssValue(1.5,2, 1440, 1.73558, 1600, 2)};
        border-width: 0px;
        border-color: rgba(255, 255, 255, 0.72);
        border-style: solid;
        padding: 13.2374px 26.4748px;
        border-radius: 13.2374px;
        a {
            display: flex;
            flex-direction: row;
        }

        h1,h2,h3,h4,h5,h6 {
            // font-family: Roboto Slab;
            // font-style: normal;
            // line-height: 22px;
            // font-weight: 500;
            flex: 1;
            margin: 0 2rem;
            ${layout.screen.mob} {
                margin: 0px;
            }
        }

        img {
            width: 6px;
        }

    }

    .button.dark {
        background: #00AB88;
        h1,h2,h3,h4,h5,h6 {
            color: #FFFFFF;
        }
    }

    .button.light {
        background: #ffffff;
        a {
            color: #1D6F5E;
        }
        h1,h2,h3,h4,h5,h6 {
            color: #2F695D;
        }
    }


    .button.transparent {
        background: transparent;
        h1,h2,h3,h4,h5,h6 {
            color: #1D6F5E;
        }
    }


    .button.translucent {
        background: rgba(255, 255, 255, 0.4);
        box-sizing: border-box;
        backdrop-filter: blur(3.30935px);
        h1,h2,h3,h4,h5,h6 {
            color: #1D6F5E;
        }
        
    }

`;


const Button = ({type, title, link}) => {
    return (
        <ButtonWrapper>
            <motion.div 
                className={`button ${type}`}
                whileHover={{
                    scale: 1.02,
                    transition: { ease: 'anticipate', duration: 0.200 },
                }}
                whileTap={{ scale: 0.95 }}
            >
                <a href={`${link || 'javascript:void(0)'}`}>
                    <h5 className='h5'>{title}</h5>
                </a>
            </motion.div>
        </ButtonWrapper>
    )
}

// End : Buttons component



