import React, {  useState, useEffect } from 'react'
import { styled } from 'frontity';
import {layout} from '../../../utils/constants';

import { Container } from '../../misc/layout';
import { motion } from "framer-motion";

import PayuLogo from '../../../assets/images/payu-logo.svg'
import SignupLogo from '../../../assets/images/Signup-new.png'
import LoginLogo from '../../../assets/images/Login-new.png'
import DropDownIcon from '../../../assets/icons/dropdown.svg'
import DropDownReversedIcon from '../../../assets/icons/dropdown_reversed.svg'
import CrossIcon from '../../../assets/icons/cross.svg'


const rotateAnimation = {
    initial: { scale: 1 },
    active: {
        transform: 'rotate(180deg)'
    },
    transition: () => ({
        transform: { type: "spring",
          damping: 10,
          mass: 0.2,
          stiffness: 150
         }, 
        ease: 'anticipate',
        duration: 0.2,
        delay: 0
    })
}

const MobileMenuWrapper = styled.div`
position: relative;

display: flex;
flex-direction: column;

// .container {
//     padding-left: 20px;
//     padding-right: 20px;
// }

.menu-dropdown-container {
    position: unset;
    top: unset;
    left: unset;
    transform: unset;
    z-index: unset;
    width: 100%;
}

.top-bar {
    position: relative;
    height: ${layout.constants.headerHeight};
    display: flex;
    align-items: center;

    .logo-wrapper {
        width: 56px;
        height: 28px;
    }
    .logo {
        width: 56px;
        position: absolute;
        left: 0px;
    }

    .mobile-menu-close-icon-wrapper {
        position: absolute;
        right: 0px;
        height: 100%;
        padding: 0px 12px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
}

.menu-main {
    ${(props)=>(props.windowHeight > 0 ? `
        height: calc( ${props.windowHeight}px - ${layout.constants.headerHeight} - 136px);
    ` : `
        height: calc( 100vh - ${layout.constants.headerHeight} - 136px);
    `)}
    
    overflow-y: scroll;
    overflow-x: hidden;

    .items-wrapper {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: flex-start;
        flex-grow: 1;
        padding-bottom: 16px;

        .menu-bar-item {
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            padding: 10px 1.5rem;
            
            img {
                margin-left: 4px;
                height: auto;
                width: 10px;
            }
        }

    }

}

.mobile-menu-actions {
    // display: flex;
    // flex-direction: row;
    // flex-wrap: wrap;

    display:grid;
    grid-template-columns: repeat(1, auto);

    ${layout.screen.only_sm} {
        grid-template-columns: repeat(2, auto);
    }

    position: fixed;
    bottom: 0;
    border-top: solid 1px #eef1ef;
    width: 100%;
    left: 0;

    .item {
        a {
            align-items: center;
            display: flex;
        }
        // min-width: 350px;
        width: 100%;

        height: 68px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex: 1;
        img {
            margin-right: 9.95px;
            width: 16px;
            height: auto;
        }

        span {
            // font-family: Open Sans;
            // font-style: normal;
            // font-weight: 600;
            // font-size: 14px;
            // line-height: 200%;
            color: #2F695D;
        }

        &.light {
            background: #FFFFFF;
        }

        &.dark {
            background: #BFDFBA;
        }
    } 

}
`;

export const MobileMenu = ({data, closeMenu, isMobileMenuOpen, frontity}) => {
const [activeMenuIndex, setactiveMenuIndex] = useState(-1)

const handleMenuTap = (index) => {
    if(activeMenuIndex == index) {
        setactiveMenuIndex(-1)
    } else {
        setactiveMenuIndex(index)
    }
}

const handleClose = () => {
    closeMenu();
}

const [windowHeight, setwindowHeight] = useState(0)

const handleResize = () => {
    window?.innerHeight && setwindowHeight(window.innerHeight)
}

useEffect(() => {
    handleResize();
    window.addEventListener("resize", handleResize)
    window.addEventListener("orientationchange", handleResize)
    
    return () => {
    window.removeEventListener("resize", handleResize)
    window.removeEventListener("orientationchange", handleResize)
    }
}, [])


return(
    <MobileMenuWrapper windowHeight={windowHeight}>
        <Container className="container" padding={'level1'}>
            <div className="top-bar">
                <a href={data?.settings?.url?.home} className="logo-wrapper" ><img className="logo" src={PayuLogo}></img></a>
                <motion.div
                    className="mobile-menu-close-icon-wrapper" 
                    variants={rotateAnimation}
                    initial={'initial'}
                    animate={isMobileMenuOpen ? 'active' : 'initial'}
                    transition={{
                        ...rotateAnimation.transition()
                    }}
                    onTap={()=>{handleClose()}}
                >
                    <img className="mobile-menu-close-icon" src={CrossIcon}/>
                </motion.div>
            </div>
        </Container>

        <div class="menu-main">
                    <div className='items-wrapper'>
                        {
                            data?.menu?.map((elem, index)=>{
                                return (
                                    <>
                                        <motion.span 
                                            className={`menu-bar-item nav-text-3 ${activeMenuIndex==index && 'active'}`}
                                            whileHover={()=>{}}
                                            
                                            onTap={()=>{
                                                handleMenuTap(index)
                                            }}
                                        >
                                            <a href={elem?.type?.type?.value == 'link' &&  elem?.type?.data?.link || 'javascript:void(0)'}>
                                                {elem.title}
                                            </a>
                                            {elem?.type?.type?.value == 'link' ? <></> :( activeMenuIndex==index ? <img src={DropDownReversedIcon}/> : <img src={DropDownIcon}/> ) }
                                        </motion.span>
                                        {
                                            activeMenuIndex==index && elem?.type?.type?.value != 'link' &&
                                            <motion.div
                                                className={"menu-dropdown-container"}
                                            >
                                                <MobileMenuDropdownComponent data={elem?.type?.data || {}} type={elem?.type?.type?.value || 'link'} />
                                            </motion.div>
                                            
                                        }
                                    </>
                                    
                                )
                            })
                        }
                    </div>
        </div>

        <div className="mobile-menu-actions">
                <div className="item nav-text-2 light">
                    <a href={data?.settings?.url?.login}><img src={SignupLogo}></img><span>Sign up</span></a>
                </div>
                <div className="item nav-text-2 dark">
                    <a href={data?.settings?.url?.login}><img src={LoginLogo}></img><span>Login</span></a>
                </div>
        </div>
        
    </MobileMenuWrapper>
)
}



const MobileMenuDropDownWrapper = styled.div`

// border-radius: 28px;
display: flex;
flex-direction: column;
overflow: hidden;
margin-bottom: 18px;

.level-1 {

    background: rgba(255, 255, 255, 0.6);
    box-sizing: border-box;
    backdrop-filter: blur(4px);

    width: 100%;

    // padding-bottom: 24px;
    // padding-top: 16px;

    .l1-menu-item {
        display: flex;
        flex-direction: row;
        cursor: default;

        .icon {
            width: 29px;
            height: 29px;
            border-radius: 50%;
            background: #96A5A2;

            margin-top: 36px;
            &.paraless {
                margin-top: 24px;
            }
            margin-left: 40px;
        }

        .text-container {
            display: flex;
            flex-direction: column;
            margin: 24px;
            margin-left: 21px;
            margin-bottom: 15px;
            gap: 4px;
            cursor: default;
            
            .heading {
                color: #2F695D;
            }
            .description {
                color: #96A5A2;
            }
        }

        &.active {
            background: #FFFFFF;
            .text-container {
                .heading {
                    color: #00AB88;
                }
                .description {
                    color: #2F695D;
                }
            }
        }
    }

    .level-2 {
        padding: 8px 24px;
        padding-left: 90px;
    }

    .get-more-container-wrapper {
        padding-left: 90px;
        padding-right: 24px;
    }
    
}

.level-2 {
    background: #FFFFFF;
    // width: 367px;
    width: 100%;
    padding: 36px 24px;
    padding-left: 68px;

    .level-2-heading {
        margin-bottom: 10px;
    }

    .level-2-item {
        padding: 20px 0px;

        &.border-top {
            border-top: 1px solid #BFDFBA;
        }

        .text-container {
            display: flex;
            flex-direction: column;
            gap: 2px;
            
            .heading {
                // font-family: Roboto;
                // font-style: normal;
                // font-weight: 500;
                // font-size: 14px;
                // line-height: 171%;
                // letter-spacing: 1px;
                color: #0E342C;
            }
            .description {
                // font-family: Roboto;
                // font-style: normal;
                // font-weight: 500;
                // font-size: 12px;
                // line-height: 167%;
                // letter-spacing: 1px;
                color: #2F695D;
                
            }
        }
    }
    
}
.get-more-container-wrapper {
    background: #ffffff;
    padding: 8px 41px 40px 27px;
    padding-left: 68px;
    padding-right: 24px;
}
.get-more-container {
    // background: linear-gradient(349.06deg, #1268B3 -76.74%, rgba(255, 255, 255, 0) 91.9%), #CFE4BF;
    background: linear-gradient(349.06deg, #1268B3 -100%, rgba(255, 255, 255, 0) 50%), #CFE4BF;
    backdrop-filter: blur(200px);
    border-radius: 20px;

    height: 100%;
    width: 256px;

    padding: 23px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-end;

    .heading {
        margin-bottom: 16px;
    }

    .links {
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        justify-content: flex-end;
        gap: 20px;
    }

    .item {

        &.border-top {
            border-top: 1px solid #BFDFBA;
        }

        .text-container {
            display: flex;
            flex-direction: column;
            gap: 2px;
            
            .heading {
                margin: 0px;
                padding: 0px;
                // font-family: Roboto;
                // font-style: normal;
                // font-weight: 500;
                // font-size: 14px;
                // line-height: 171%;
                // letter-spacing: 1px;
                color: #0E342C;
            }
            .description {
                // font-family: Roboto;
                // font-style: normal;
                // font-weight: 500;
                // font-size: 12px;
                // line-height: 167%;
                // letter-spacing: 1px;
                color: #2F695D;
                
            }
        }
    }

}
`;


const MobileMenuDropdownComponent = ({data, type}) => {
    const [selectedMenuItem, setselectedMenuItem] = useState(-1)
    
    const level2Data = data?.menuItems?.[selectedMenuItem]?.level1 || [];
    const level2Heading = data?.menuItems?.[selectedMenuItem]?.level1Heading;
    const getMoreData = data?.menuItems?.[selectedMenuItem]?.getMore;
    
    //type == 'singleLevel'
    
    return (
        <MobileMenuDropDownWrapper>
            {type == 'twoLevel' && 
                <>
                    <div className="level-1">
                        {data?.menuItems?.map((elem, index)=>(
                            <>
                            <motion.div 
                                className={`l1-menu-item ${selectedMenuItem == index && 'active'}`}
                                onHoverStart={()=>{setselectedMenuItem(index)}}
                                onTap={()=>{setselectedMenuItem(index)}}
                            >
                                <span className={`icon ${elem?.level0?.description ? '' : 'paraless'}`}></span>
                                <div className="text-container">
                                    <span className="heading nav-text-1">{elem?.level0?.title}</span>
                                    <span className="description nav-text-3">{elem?.level0?.description}</span>
                                </div>
                            </motion.div>
                            {
                                selectedMenuItem == index &&
                                <>
                                    <div className='level-2'>
                                    {level2Heading && <h5 className={'level-2-heading h7'}>{level2Heading}</h5>}
                                    {
                                        level2Data.map((elem, index)=>(
                                            <div className={`level-2-item ${index && 'border-top'}`}>
                                                <a href={elem?.link || 'javascript:void(0)'}>
                                                    <div className="text-container">
                                                        <span className="heading nav-text-2">{elem?.title}</span>
                                                        <span className="description nav-text-4">{elem?.description}</span>
                                                    </div>
                                                </a>
                                            </div>
                                        ))
                                    }
                                    </div>
                                    {getMoreData && (getMoreData?.heading || (getMoreData?.links?.length > 0)) &&
                                        <div className="get-more-container-wrapper">
                                            <div className="get-more-container">
                                                {getMoreData?.heading && <h4 className={'heading h5'}>{getMoreData?.heading}</h4>}
                                                
                                                <div className="links">
                                                    {
                                                        getMoreData?.links?.map((elem, index)=>(
                                                            <div className={`item`}>
                                                                <a href={elem?.link || 'javascript:void(0)'}>
                                                                    <div className="text-container">
                                                                        <span className="heading nav-text-2">{elem?.title}</span>
                                                                        <span className="description nav-text-4">{elem?.description}</span>
                                                                    </div>
                                                                </a>
                                                            </div>
                                                        ))
                                                    }
                                                </div>
                                                
                                            </div>
                                        </div>
                                    }
                                </>
                            }
                            </>
                        ))}
                    </div>
                    
                </>
            }
    
            {type == 'singleLevel' && 
                <>
                    <div className='level-2'>
                            {data.heading && <h5 className={'level-2-heading'}>{data.heading}</h5>}
                            {
                                data?.menuItems?.map((elem, index)=>(
                                    <div className={`level-2-item ${index && 'border-top'}`}>
                                        <a href={elem?.link || 'javascript:void(0)'}>
                                            <div className="text-container">
                                                <span className="heading nav-text-2">{elem?.title}</span>
                                                <span className="description nav-text-4">{elem?.description}</span>
                                            </div>
                                        </a>
                                    </div>
                                ))
                            }
                    </div>
                    {data?.getMore &&
                        <div className="get-more-container-wrapper">
                            <div className="get-more-container">
                                {data?.getMore?.heading && <h4 className={'heading h5'}>{data?.getMore?.heading}</h4>}
                                
                                <div className="links">
                                    {
                                        data?.getMore?.links?.map((elem, index)=>(
                                            <div className={`item`}>
                                                <a href={elem?.link || 'javascript:void(0)'}>
                                                    <div className="text-container">
                                                        <span className="heading nav-text-2">{elem?.title}</span>
                                                        <span className="description nav-text-4">{elem?.description}</span>
                                                    </div>
                                                </a>
                                            </div>
                                        ))
                                    }
                                </div>
                                
                            </div>
                        </div>
                    }
                </>
            }
        </MobileMenuDropDownWrapper>
    )
    }