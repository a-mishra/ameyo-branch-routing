import React from 'react'
import SectionProductUsecases from '../components/sections/product-usecases/index'


const ComponentWrapper = ({data}) => {


    return (
        <SectionProductUsecases data={data} />
    )
};

const productusecases = {
    name: 'productusecases',
    priority: 20,
    test: ({ component, props }) => component === "div" && props.className.split(' ').includes("wp-block-cgb-block-product-usecases"),
    processor: ({ node,props }) => {

        let data = JSON.parse(node.children[0].children[0].content || '{}'); 
        if(data.cards) {
            data.cards = JSON.parse(data.cards);
        }
        if(data.icons) {
            data.icons = JSON.parse(data.icons);
        }
        if(data.buttons) {
            data.buttons = JSON.parse(data.buttons);
        }

        return {
          component: ComponentWrapper,
          props: {data},
        }
      },
}

export default productusecases;