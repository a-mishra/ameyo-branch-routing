import React, {  useRef, useEffect, useState, useLayoutEffect } from 'react'
import { connect, styled , Global, css} from 'frontity';
import {layout, SectionAnimation} from '../../../utils/constants';
import {useOnScreen, useWindowDimentions, useContainerDimensions} from '../../../utils/hooks/usehooks'
import { Section, Row, Col, Container } from '../../misc/layout';
import { motion, useMotionValue, useAnimation } from "framer-motion";
import { Swiper } from './Swiper'
// import ThreadImage from '../../../assets/images/thread.svg'
import ThreadImage from './backgroundImageFAQ.png';


const SectionWrapper = styled.div`
    min-height: 300px;
    position: relative;
    overflow-x: clip;

    .section-container {
        ${layout.screen.mob} {
            padding-left: 0px;
            padding-right: 0px;
        }
    }
    .section-inner {
        display: flex;
        flex-direction: row;
        ${layout.screen.mob} {
             flex-direction: column;
        }

        .text-cards-container {
            display: flex;
            flex-direction: column;
            // flex: 12;
            width: 55%;
            .texts {
                margin-bottom: 3rem;
                h1,h2,h3,h4,h5,h6 {
                    // color: #0E342C;
                }
                p {
                    margin-top: 0.5rem;
                    // color: #40413B;
                }

                ${layout.screen.mob} {
                    padding-left: ${layout.constants.mobile_padding['level4'] || '0rem'};
                    padding-right: ${layout.constants.mobile_padding['level4'] || '0rem'};

                    margin-bottom: 2rem;
                    h1,h2,h3,h4,h5,h6 {
                        // font-size: ${layout.reponsiveCssValue(20,24, 375, 20, 992, 24)};
                        margin: 0rem;
                    }
                }
            }
            ${layout.screen.mob} {
                flex-grow: 1;
                flex: 1;
                width: 100%;
            }

            .image-wrapper {
                visibility: hidden;
                display: none;
                justify-content: center;
                align-items: center;
                img {
                    width: none;
                    height: 100%;

                    ${layout.screen.mob} {
                        // width: auto;
                        // height: 100%;
                        // max-height: 500px;
                        width: 100%;
                        height: auto;
                        /* max-height: 500px; */
                        max-width: 500px;
                    }
                }
                ${layout.screen.mob} {
                    padding-left: ${layout.constants.mobile_padding['level4'] || '0rem'};
                    padding-right: ${layout.constants.mobile_padding['level4'] || '0rem'};
                    
                    display: flex;
                    visibility: visible;
                }
            }

        }

        .image-container {
            visibility:visible;
            display: flex;
            // flex: 9;
            width: 45%;

            justify-content: flex-start;
            align-items: flex-start;
            img {
                width: auto;
                height: 100%;
                max-width: 100%;
            }


            ${layout.screen.mob} {
                visibility: hidden;
                display: none;
            }
        }



    }

    .thread-image {
        width: 100%;
        position: absolute;
        top: ${(props)=>(props.threadOffset ? `${props.threadOffset+64}px`:'8rem')};
        z-index: -1;
        img {
            // object-fit: cover;
            // max-height: ${(props)=>(props.threadMaxHeight ? `${props.threadMaxHeight}px`:'500px')};;
        }

        ${layout.screen.mob} {
            position: absolute;
            height: 100%;
            top: 0;
            img {
                width: 190%;
                position: absolute;
                top: 50%;
                // left: 33%;
                transform: translate(-45%, -45%);
                max-height: 500px;
            }
        }
        // width < 400
    }


    .mobileOnly {
        display: none;
        ${layout.screen.mob} {
            display: block;
        }
    }

    .desktopOnly {
        display: block;
        ${layout.screen.mob} {
            display: none;
        }
    }

`;


const SectionFAQ = ({state, actions, data, libraries}) =>  {

    const ref = useRef(null)
    const ref2 = useRef(null)
    const [onScreen, portionInView, viewed] = useOnScreen(ref, "0px");
    const Html2React = libraries.html2react.Component;

    useEffect(() => {
        actions.intraPageLinks.update(data?.section?.internalLink, portionInView);
        return () => {
            actions.intraPageLinks.update(data?.section?.internalLink, 0);
        }
    }, [portionInView])

    const [width, setwidth] = useState(0);
    const [height, setheight] = useState(0);
    const [sectionHeight, setsectionHeight] = useState(0);

    const handleResize = () => {
        if(ref2.current) {
            setwidth(ref2.current.offsetWidth);
            setheight(ref2.current.offsetHeight);
        }
        if(ref.current) {
            setsectionHeight(ref.current.offsetHeight)
        }
    }
    
    useEffect(() => {
        handleResize();
        window.addEventListener("resize", handleResize)
        window.addEventListener("orientationchange", handleResize)
        
        return () => {
        window.removeEventListener("resize", handleResize)
        window.removeEventListener("orientationchange", handleResize)
        }
    }, [])

    const ImageAnimation = {
        show: {
            y: 0,
            opacity: 1,
            scale: 1,
        },
        hidden: {
            y: 60,
            opacity: 0,
            scale:0.95
        }
    }

    const BackgroundMediaAnimation = {
        hidden: { opacity: 0, scale: 1, y: 0 },
        show: {
            opacity: 1,
            scale: 1,
            y: 0
        },
        transition: (n, longDelay=false) => ({
            // y: { type: "spring",
            //   damping: 10,
            //   mass: 0.2,
            //   stiffness: 150
            //  }, 
            ease: 'anticipate',
            duration: longDelay ? 0.8 : 0.5, 
            delay: (longDelay ? 0.8 : 0.5)*(n) - 0.1*n, 
        })
    }

    return (
    <>
        <SectionWrapper  id={data?.section?.internalLink} threadOffset={height} threadMaxHeight={sectionHeight}>
            <Section padding={'level4'} className='section-container'>
                <motion.div 
                    className="section-inner"
                    ref={ref}
                    variants={SectionAnimation}
                    initial={'hidden'}
                    animate={viewed ? 'show' : 'hidden'}
                    transition={{
                        ...SectionAnimation.transition(0, true)
                    }}
                    onAnimationComplete={handleResize}
                >

                    <div className="text-cards-container"> 
                        <div ref={ref2} className="texts">
                            <h2 className='h2'>{data.heading}</h2>
                            <p className={'body2'}>{data.description}</p>
                        </div>

                        <motion.div 
                        className="image-wrapper"
                        variants={ImageAnimation}
                        initial={'hidden'}
                        animate={viewed ? 'show' : 'hidden'}
                        transition={{
                            ...SectionAnimation.transition(2)
                        }}
                        >
                            <img src={data?.image?.url} />
                        </motion.div>


                        <Swiper data={data && data.cards || []} sectionWrapperWidth={width} viewed={viewed} />

                    </div>


                    <motion.div 
                    className="image-container"  
                    variants={ImageAnimation}
                    initial={'hidden'}
                    animate={viewed ? 'show' : 'hidden'}
                    transition={{
                        ...SectionAnimation.transition(2)
                    }}
                    >
                        <img src={data?.image?.url} />
                    </motion.div>



                </motion.div>
            </Section>

            <motion.div 
            className="thread-image"
            variants={BackgroundMediaAnimation}
                initial={'hidden'}
                animate={viewed ? 'show' : 'hidden'}
                transition={{
                    ...BackgroundMediaAnimation.transition(4)
                }}
            >
                <img src={ThreadImage} />
            </motion.div>
        </SectionWrapper>
    </>
    )

}

export default connect(SectionFAQ)
