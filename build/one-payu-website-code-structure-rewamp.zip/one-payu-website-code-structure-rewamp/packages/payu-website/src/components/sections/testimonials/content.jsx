import React, {  useRef, useEffect, useState, useLayoutEffect } from 'react'
import { connect, styled , Global, css} from 'frontity';
import {layout, SectionAnimation} from '../../../utils/constants';
import {useOnScreen, useWindowDimentions, useContainerDimensions} from '../../../utils/hooks/usehooks'
import { Section, Row, Col, Container } from '../../misc/layout';
import { motion, useMotionValue, useAnimation, AnimatePresence } from "framer-motion";


const ContentWrapper = styled.div`
    position: relative;

    .section-inner {
        position: relative;
        background: #FFFFFF;
        border-radius: 28px;
        z-index: 30;
        padding-top: ${layout.reponsiveCssValue(64, 93, 1440, 77, 1600, 93)};
        padding-right: ${layout.reponsiveCssValue(94, 141, 1440, 116, 1600, 141)};
        padding-bottom: ${layout.reponsiveCssValue(64, 93, 1440, 77, 1600, 93)};
        padding-left: ${layout.reponsiveCssValue(94, 141, 1440, 116, 1600, 141)};

        ${layout.screen.mob} {
            padding-top: ${layout.reponsiveCssValue(58, 77, 375, 58, 1440, 77)};
            padding-right: ${layout.reponsiveCssValue(27, 116, 375, 27, 1440, 116)};
            padding-bottom: ${layout.reponsiveCssValue(72, 77, 375, 72, 1440, 77)};
            padding-left: ${layout.reponsiveCssValue(27, 116, 375, 27, 1440, 116)};
        }
    }


    .row1 {
        display: flex;
        // row-gap: ${layout.reponsiveCssValue(36, 48, 1440, 52, 1600, 68)};

        ${layout.screen.mob} {
            flex-direction: column;
            //row-gap: ${layout.reponsiveCssValue(48, 62, 375, 62, 992, 48)};
        }

        .texts {
            flex: 10;

            p {
                margin-top: ${layout.reponsiveCssValue(12,20, 1440,16.54,1600,20)};
                ${layout.screen.mob} {
                    margin-top: ${layout.reponsiveCssValue(12,20, 375,20,992,12)};
                }
            }

            

        }


        .logos {
            display: flex;
            flex: 16;
            align-items: center;
            justify-content: center;

            .logocontainer {
                width: 90%;
            }
        }

    }

    ${layout.screen.md} {
        .row1 > div {
            &:not(:last-child) {
                margin-right: ${layout.reponsiveCssValue(36, 48, 1440, 52, 1600, 68)}; // flex->gap safari <14.1 fix
            }
        }
    }

    ${layout.screen.mob} {
        .row1 > div {
            &:not(:last-child) {
                margin-bottom: ${layout.reponsiveCssValue(48, 62, 375, 62, 992, 48)}; // flex->gap safari <14.1 fix
            }
        }
    }


    
        .row2 {
            display: flex;
            // gap: ${layout.reponsiveCssValue(36, 48, 1440, 52, 1600, 68)}; // flex->gap safari <14.1 fix
            transition: all 0.2s cubic-bezier(0.17, 0.12, 0.63, 0.66);

            margin-top: ${layout.reponsiveCssValue(58, 88, 1440, 72, 1600, 88)};
            ${layout.screen.mob} {
                flex-direction: column;
                margin-top: ${layout.reponsiveCssValue(60, 108, 375, 108, 993, 60)};
                // column-gap: ${layout.reponsiveCssValue(36, 41, 375, 41, 993, 36)};
            }
            .profile-container {
                flex: 9;
                position: relative;
                display: flex;
                align-items: flex-start;
                justify-content: flex-start;
                ${layout.screen.mob} {
                    align-items: center;
                    justify-content: center;

                }

                .wrapper {
                    position: relative;
                    width: 100%;
                    // width: ${layout.reponsiveCssValue(280, 413, 1440, 342, 1600, 413)};
                    height: ${layout.reponsiveCssValue(296, 455, 1440, 380, 1600, 455)};
                    ${layout.screen.mob} {
                        height: ${layout.reponsiveCssValue(308, 455, 1440, 380, 1600, 455)};
                    }
                }

                .image-green-background {
                    position: absolute;
                    bottom: 0px;
                    background: linear-gradient(349.06deg, #1268B3 -100%, rgba(255, 255, 255, 0) 50%), #CFE4BF;
                    opacity: 0.5;
                    backdrop-filter: blur(200px);
                    border-radius: 28px;
                    width: 100%;
                    height: 85.7%;
                    // aspect-ratio: 7/6;
                    ${layout.screen.mob} {
                        background: #EBF0ED;
                        border-radius: 16px;
                        opacity: 1;
                        max-height: 80%;
                        left: 50%;
                        transform: translateX(-50%);
                    }
                }

                .details-container {
                    position: absolute;
                    top: 0px;
                    bottom: 0px;
                    width: 100%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    flex-direction: column;

                    .image-wrapper {
                        width: ${layout.reponsiveCssValue(198, 279, 1440, 230.78, 1600, 279)};
                        height: ${layout.reponsiveCssValue(198, 294, 1440, 243.19, 1600, 294)};
                        position: relative;
                        max-width: 75%;
                        img {
                            height: auto;
                            object-fit: cover;
                            // border-radius: ${layout.reponsiveCssValue(16, 20, 1400, 16, 1600, 20)};
                            // ${layout.screen.mob} {
                            //     border-radius: ${layout.reponsiveCssValue(20, 16, 375, 20, 1400, 16)};
                            // }
                            bottom: 0;
                            position: absolute;
                        }
                    }


                    .text-container {
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        max-width: 80%;
                        margin-top: ${layout.reponsiveCssValue(24, 38, 1400, 32, 1600, 38)};
                        margin-bottom: ${layout.reponsiveCssValue(24, 38, 1400, 32, 1600, 38)};
                        h1,h2,h3,h4,h5,h6 {
                            // font-size: ${layout.reponsiveCssValue(13, 20, 1440, 16.5467, 1600, 20)};
                            // color: #0E342C;
                            text-align: center;
                            ${layout.screen.mob} {
                                // font-size: ${layout.reponsiveCssValue(16, 20, 375, 20, 992, 16.5467)};
                                // line-height: 129.2%;
                            }
                        }
                        p {
                            margin-top: ${layout.reponsiveCssValue(10, 12, 1440, 9.93, 1600, 12)};
                            // color: #2F695D;
                            text-align: center;
                            ${layout.screen.mob} {
                                // color: #71755E;
                                // font-size: ${layout.reponsiveCssValue(12, 17, 375, 17, 992, 12)};
                            }
                        }
                        ${layout.screen.mob} {
                            margin-bottom: ${layout.reponsiveCssValue(24, 38, 1400, 32, 1600, 38)};
                        }
                    }
                }
            }

            .text-and-cards-container {
                display:flex;
                flex: 16;
                flex-direction: column;

                .texts {
                    display: flex;
                    align-items: start;
                    justify-content: start;
                    flex-direction: column;
                    flex-grow: 1;
                    h1,h2,h3,h4,h5,h6 {
                        // font-size: ${layout.reponsiveCssValue(16, 24, 1440, 19.85, 1600, 24)};
                        // color: #40413B;
                        ${layout.screen.mob} {
                            text-align: center;
                            // color: #0E342C;
                            // font-size: ${layout.reponsiveCssValue(16, 20, 375, 20, 992, 16.5467)};
                            // line-height: 160%;
                            // font-weight: 500;
                        }

                    }
                    p {
                        margin-top: ${layout.reponsiveCssValue(11, 17, 1440, 14, 1600, 17)};
                        padding-bottom: ${layout.reponsiveCssValue(11, 17, 1440, 14, 1600, 17)};
                        // color: #2F695D;
                        ${layout.screen.mob} {
                            // color: #40413B;
                            margin-top: ${layout.reponsiveCssValue(17, 20, 375, 20, 993, 17)};
                        }
                    }
                }

                .texts.center {
                    justify-content: center;
                }

                .small-cards {
                    ${layout.screen.mob} {
                        display:none;
                    }
                    align-items: center;
                    display: flex;
                    flex-direction: row;
                    justify-content: flex-end;
                    flex-wrap: wrap;
                    // column-gap: ${layout.reponsiveCssValue(24, 38, 1440, 32, 1600, 38)}; // flex->gap safari <14.1 fix
                    row-gap: ${layout.reponsiveCssValue(11, 17, 1440, 14, 1600, 17)};

                    .small-cards-heading {
                        display: flex;
                        align-item: center;
                        justify-content: flex-end;
                        flex-basis: 120px;
                        flex: 1;
                        p {
                            // color: #2F695D;
                            // font-weight: 600;
                        }
                    }

                    .small-cards-items {
                        display: flex;
                        flex-direction: row;
                        // gap : ${layout.reponsiveCssValue(12, 22, 1440, 18, 1600, 22)}; // flex->gap safari <14.1 fix
                    }
                }
            }
        }

        ${layout.screen.md} {
            .row2 > div {
                &:not(:last-child) {
                    margin-right: ${layout.reponsiveCssValue(36, 48, 1440, 52, 1600, 68)}; // flex->gap safari <14.1 fix
                }
            }

            .row2 > .text-and-cards-container > .small-cards {
                &:not(:last-child) {
                    margin-right:${layout.reponsiveCssValue(24, 38, 1440, 32, 1600, 38)}; // flex->gap safari <14.1 fix
                }

                .small-cards-items {
                    &:not(:last-child) {
                        margin-right:${layout.reponsiveCssValue(12, 22, 1440, 18, 1600, 22)}; // flex->gap safari <14.1 fix
                    }
                }
            }
        }

        ${layout.screen.mob} {
            .row2 > div {
                &:not(:last-child) {
                    margin-bottom: ${layout.reponsiveCssValue(36, 41, 375, 41, 993, 36)} // flex->gap safari <14.1 fix
                }
            }

            .row2 > .text-and-cards-container > .small-cards {
                &:not(:last-child) {
                    margin-right:${layout.reponsiveCssValue(24, 38, 1440, 32, 1600, 38)}; // flex->gap safari <14.1 fix
                }

                .small-cards-items {
                    &:not(:last-child) {
                        margin-right:${layout.reponsiveCssValue(12, 22, 1440, 18, 1600, 22)}; // flex->gap safari <14.1 fix
                    }
                }
            }
        }



    .section-inner.small {
        padding-top: ${layout.reponsiveCssValue(36, 58, 1440, 48, 1600, 58)};
        padding-right: ${layout.reponsiveCssValue(96, 153, 1440, 130, 1600, 153)};
        padding-bottom: ${layout.reponsiveCssValue(64, 93, 1440, 77, 1600, 93)};
        padding-left: ${layout.reponsiveCssValue(96, 153, 1440, 130, 1600, 153)};


        ${layout.screen.mob} {
            padding-top: ${layout.reponsiveCssValue(58, 77, 375, 58, 1440, 77)};
            padding-right: ${layout.reponsiveCssValue(27, 116, 375, 27, 1440, 116)};
            padding-bottom: ${layout.reponsiveCssValue(72, 77, 375, 72, 1440, 77)};
            padding-left: ${layout.reponsiveCssValue(27, 116, 375, 27, 1440, 116)};
        }
        
        .row1 {
            .texts {
                p {
                    margin-top: ${layout.reponsiveCssValue(9,16, 1440,10.61,1600,16)};
                }
            }
        }

        .row2 {
            margin-top: ${layout.reponsiveCssValue(42, 62, 1440, 50, 1600, 62)};
            .profile-container {
                flex: 9;
            }
            .text-and-cards-container {
                flex: 10;
            }
        }
    }
`;


const Content = ({state, actions, data, index, libraries, isTopCard, updateHeight, setCardIndex}) =>  {

    const ref = useRef(null)
    const Html2React = libraries.html2react.Component;
    const NumberOfSliders = data?.cards?.length  || 1;
    const loopedIndex = (index) % NumberOfSliders;

    const isSmall= data && data.logo && data.logo.length > 0 ? false : true;

    const handleUpdateHeight = () => {
        if(ref.current) {
            if(isTopCard) {
                updateHeight?.(ref.current.offsetHeight);
            }
        }
    }

    const [immidiate, setimmidiate] = useState(true);
    const handlesetCardIndex = (newIndex) => {
        setimmidiate(false)
        setCardIndex(newIndex);
    }

    useEffect(() => {
        handleUpdateHeight();
        window.addEventListener("resize", handleUpdateHeight)
        window.addEventListener("orientationchange", handleUpdateHeight)
        
        return () => {
        window.removeEventListener("resize", handleUpdateHeight)
        window.removeEventListener("orientationchange", handleUpdateHeight)
        }
    }, [])
    
    useEffect(() => {
        handleUpdateHeight();
    }, [isTopCard])


 const CardElementAnimations = {
        hidden: { opacity: 0, scale: 0.95, y: -60 },
        show: {
            opacity: 1,
            scale: 1,
            y: 0
        },
        transition: (n) => ({
            y: { type: "spring",
              damping: 10,
              mass: 0.2,
              stiffness: 150
             }, 
            opacity: {
                duration: 0.5, 
            },
            // ease: 'anticipate',
            // duration: 0.4, 
            // delay: (0.3)*(n) - 0.1*n, 
            duration: 0.5, 
            delay: (0.3)*(n) - 0.1*n, 
        })
    }

    return (
    <>
        <ContentWrapper ref={ref}>
                        <div className={`section-inner ${isSmall && 'small'}`}  >
                            <div className="row1">
                                <motion.div 
                                    className="texts"
                                    // variants={CardElementAnimations}
                                    // initial={'hidden'}
                                    // animate={isTopCard ? 'show' : 'hidden'}
                                    // transition={{
                                    //     ...CardElementAnimations.transition(0)
                                    // }}
                                >
                                    <h3 className='h3'>{data.heading}</h3>
                                    <p className={'body2'}>{data.description}</p>
                                </motion.div>
                                
                                {
                                    data && data.logo && data.logo.length > 0 && 
                                    <motion.div 
                                        className="logos"
                                        // variants={CardElementAnimations}
                                        // initial={'hidden'}
                                        // animate={isTopCard ? 'show' : 'hidden'}
                                        // transition={{
                                        //     ...CardElementAnimations.transition(1)
                                        // }}
                                    >
                                        <div className="logocontainer">
                                            <Icons icons={data?.logo}/>
                                        </div>
                                    </motion.div>
                                }
                                
                            </div>


                            {data?.cards?.map((elem, index)=>(
                                (loopedIndex == index) && 
                                            <motion.div
                                                initial={immidiate ? {
                                                        opacity: 1, y: 0, scale: 1, 
                                                    }
                                                    : {
                                                        opacity: 0, y: 8, scale: 1, 
                                                    }
                                                }
                                                animate={
                                                    { opacity: 1, y:0, scale: 1 ,
                                                        transition: {
                                                            delay: 0,
                                                            duration: 0.150,
                                                            y: { 
                                                                type: "spring",
                                                                damping: 10,
                                                                mass: 0.2,
                                                                stiffness: 150
                                                           },
                                                        }
                                                    }
                                                }
                                                exit={
                                                    { opacity: 0, y: 0, scale: 1 ,
                                                        transition: {
                                                            delay: 0,
                                                            duration: 0
                                                        } 
                                                    }
                                                }
                                                className="row2"
                                                // animate={isTopCard ? 'show' : 'hidden'}
                                                onAnimationStart={handleUpdateHeight}
                                                onAnimationEnd={handleUpdateHeight}
                                            >
                                            <div className="profile-container">
                                                <div className="wrapper">
                                                    <div className="image-green-background"></div>
                                                    <div className="details-container">
                                                        <div className="image-wrapper">
                                                            <img src={elem?.image?.url} />
                                                        </div>
                                                        <div className="text-container">
                                                            <h4 className='h5'>{elem?.personName}</h4>
                                                            <p className='body2'>{<Html2React html={elem?.personOccupatioin|| ''} />}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="text-and-cards-container">
                                                <div className={`texts ${elem?.smallCards && elem?.smallCards.length > 0 ? '': 'center'}`}>
                                                    <h4 className='h3'>{elem?.heading}</h4>
                                                    <p className='body2'>{elem?.description}</p>
                                                </div>

                                                <div className="small-cards">
                                                    <div className="small-cards-heading">
                                                        <p className='small-text1'>{<Html2React html={elem?.smallCardsHeading || ''} />}</p>
                                                    </div>
                                                    <div className="small-cards-items">
                                                        {elem?.smallCards && elem.smallCards.map((item, index)=>(
                                                            <SmallCard image={item?.image} title={item?.heading} description={item?.description} link={item?.link}/>
                                                        ))}
                                                    </div>
                                                </div>
                                            </div>

                                        </motion.div>
                                )
                            )}

                        </div>

                        {isTopCard && <motion.div
                                variants={CardElementAnimations}
                                initial={'hidden'}
                                animate={isTopCard ? 'show' : 'hidden'}
                                >
                                <GreenDots index={loopedIndex} length={NumberOfSliders} onClick={handlesetCardIndex}/>
                            </motion.div>}
        </ContentWrapper>
    </>
    )

}

export default connect(Content)


//---------------------------------------------------------------------------------------------

// Start : Icons component

const IconsWrapper = styled.div`
display: flex;
justify-content: space-around;
${layout.screen.mob} {
    justify-content: space-evenly;
} 
align-items: center;
flex-wrap: wrap;
gap: 30px;
`;

const Logo = styled.div`
height: ${layout.reponsiveCssValue(20, 32, 1440, 25.22, 1600, 32)};
display: flex;
justify-content: center;
flex-basis: 64px;
img {
    height: 100%;
    width: auto;
}
`;


const Icons = ({icons}) => {
    return (
        <IconsWrapper>
            {icons && icons.map((elem)=>{
                return(
                    <Logo>
                        <img src={elem?.image?.url} alt={elem?.image?.name}/>
                    </Logo>
                )
                
            })}
        </IconsWrapper>
    )
}

// End : Icons component



// Start : SmallCard component

const SmallCardWrapper = styled.div`
    display: flex;
    flex-direction: row;
    gap: ${layout.reponsiveCssValue(9, 18, 1440, 14, 1600, 18)};

    .image-container {
        position: relative;
        border-radius: 12px;
        background: #c4c4c4;
        width: ${layout.reponsiveCssValue(64, 96, 1440, 79.41, 1600, 96)};
        height: ${layout.reponsiveCssValue(64, 96, 1440, 79.41, 1600, 96)};
        img {
            height: auto;
            width: 100%
            object-fit: cover;
        }
    }

    .text-container {
        min-width: 118px;
        width: ${layout.reponsiveCssValue(118, 155, 1440, 128, 1600, 155)};
        h1,h2,h3,h4,h5,h6 {
            // color: #0E342C;
            // font-size: ${layout.reponsiveCssValue(12, 16, 1440, 13.2374, 1600, 16)};
            ${layout.screen.mob} {
                // font-size: ${layout.reponsiveCssValue(13,16, 375, 16, 1440, 13)};
            }
        }
        p {
            margin-top: ${layout.reponsiveCssValue(4, 6, 1440, 4.96, 1600, 6)};
            // color: #2F695D;
            // font-weight: 600;
        }
    }
`;

export const SmallCard = ({image, title, description, link }) => {

    return (
        <SmallCardWrapper>
            <div className="image-container">
                {image?.url && <img src={image.url}/>}
            </div>
            <div className="text-container">
                <h5 className='h7'>{title}</h5>
                <p className="small-text1 semibold">{description}</p>
            </div>
        </SmallCardWrapper>
    )
}

// End : SmallCard component


const GreenDotsWrapper = styled.div`
    position: absolute;
    bottom: 20px;
    width: 100%;
    display: flex;
    justify-content: center;
    // gap: 20px; // flex->gap safari <14.1 fix
    z-index: 30;
    height: 20px;

    .gd-wrapper {
        display: flex;
        margin-left: 10px; // flex->gap safari <14.1 fix
        margin-right: 10px; // flex->gap safari <14.1 fix
    }
    
    .gd-item {
        border: 2px solid #BFDFBA;
        width: 40px;
        height: 0px;
        border-radius: 2px;
        button {
            width: 40px;
        }
        box-sizing: border-box;
        margin: 8px 0px;

        &.active {
            border: 2px solid #00AB88;
        }
    }


`;

export const GreenDots = ({index, length, onClick}) => {
    const emptyArray = Array.from(Array(length).keys())
    return (
        <GreenDotsWrapper>
            {
                emptyArray?.map((elem, arrindex)=>(
                    <>
                    <span className='gd-wrapper'
                    onClick = {()=>{onClick(arrindex)}}
                    >
                        <span
                        className={`${arrindex == index && 'active'} gd-item`}
                        >
                        </span>
                    </span>
                    </>
                    
                ))

            }
        </GreenDotsWrapper>
    )
}