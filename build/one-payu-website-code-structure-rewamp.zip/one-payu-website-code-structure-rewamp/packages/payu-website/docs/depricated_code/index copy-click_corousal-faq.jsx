import React, {  useRef, useEffect, useState, useLayoutEffect } from 'react'
import { connect, styled , Global, css} from 'frontity';
import {layout} from '../../../utils/constants';
import {useOnScreen, useWindowDimentions} from '../../../utils/hooks/usehooks'
import SequenceReveal from '../sequence-reveal'
import {ParallaxBox} from '../parallax-box'
import { Section, Row, Col, Container } from '../../misc/layout';
import ThreadImage from '../../../assets/images/thread.svg'


import Slider from "react-slick";
import SlickCSS from "slick-carousel/slick/slick.css";
import SlickTheme from "slick-carousel/slick/slick-theme.css";

const SectionWrapper = styled.div`
    min-height: 300px;
    position: relative;
    overflow-x: clip;

    .section-inner {
        display: flex;
        flex-direction: row;
        margin-left: 3rem;
        margin-right: 3rem;

        .text-cards-container {
            display: flex;
            flex-direction: column;
            flex: 4;
            .texts {
                margin-bottom: 3rem;
                max-width: 550px;
                p {
                    margin-top: 0.5rem;
                    color: ##40413B;
                }
            }

            .slider-section {
                // margin-bottom: 0.5rem;
                position: relative;
                height: 250.27px;

                .slick-slider {
                    position: absolute;
                    max-width: 100%;
                }
                
                .swiper-card {
                    width: 281.55px;
                    height: 250.27px;
                    margin:0px 0.5rem;
                    background: rgba(255, 255, 255, 0.4);
                    border: 2px solid rgba(255, 255, 255, 0.72);
                    box-sizing: border-box;
                    backdrop-filter: blur(8px);
                    border-radius: 28px;

                    // &:hover {
                    //     background: #FFFFFF;
                    //     border-radius: 28px;
                    // }

                    .card-text-wrapper {
                        height: 100%;
                        width: 100%;

                        padding: 2.5rem 1.5rem;
                        position: relative;
                        a { 
                            position: absolute;
                            bottom: 1.5rem;
                            left: 1.5rem;

                            font-family: SF Pro Display;
                            font-style: normal;
                            font-weight: 600;
                            font-size: 13px;
                            letter-spacing: 0.827336px;
                            color: #00AB88;
                        }
                    }
                }
        
                .swiper-card.active {
                    background: #FFFFFF;
                    border-radius: 28px;
                }
        
            }
        }

        .image-container {
            display: flex;
            flex: 3;
            justify-content: flex-start;
            align-items: flex-start;
            height: 300px;
            img {
                width: auto;
            }
        }

        .desktop {
            ${layout.screen.xs} {
                display: none;
            }
        }
        .mobile {
            ${layout.screen.sm} {
                display: none;
            }
        }



    }

    .thread-image {
        width: 100%;
        position: absolute;
        top: 5rem;
        z-index: -1;
    }

`;


const SectionFAQ = ({state, actions, data, libraries}) =>  {

    const ref = useRef(null)
    const [onScreen, portionInView] = useOnScreen(ref, "0px");

    useEffect(() => {
        actions.intraPageLinks.update(data?.section?.internalLink, portionInView);
        return () => {
            actions.intraPageLinks.update(data?.section?.internalLink, 0);
        }
    }, [portionInView])
    
    const windowDimentions = useWindowDimentions();
    const [activeSlideIndex, setactiveSlideIndex] = useState(0)

    const Html2React = libraries.html2react.Component;

    const sliderDesktopSettings = {
        className: "slider ",
        dots: false,
        infinite: false,
        speed: 1000,
        slidesToShow: 1,
        slidesToScroll: 1,
        variableWidth: true,
        draggable: true,
        easing:'easeInOut',
        initialSlide: 0,
        swipe: true,
        // focusOnSelect: true,
        // centerMode: true,
        afterChange: (current) => console.log(current),
        beforeChange: (current, next) =>
        setactiveSlideIndex(next),
      }

      const slickSlider = useRef(null);
      const handleSlideChange = (direction) => {
        if(direction == 'prev') {
            slickSlider && slickSlider.current.slickPrev();
        }
        if(direction == 'next') {
            slickSlider && slickSlider.current.slickNext();
        }
      }

    return (
        <>
        <Global styles={css([SlickCSS, SlickTheme ])} />
    <SectionWrapper ref={ref}>
        <ParallaxBox fadeOut={false} easing={'backInOut'}>
            <SequenceReveal sequence={0} inView={onScreen}>

                <Section>
                        
                    <div className="section-inner">

                        <div className="text-cards-container"> 
                            <div className="texts" id={data?.section?.internalLink}>
                                <h3>{data.heading}</h3>
                                <p>{data.description}</p>
                            </div>

                            <div className="image-wrapper mobile">
                                <img src={data?.image?.url} />
                            </div>

                            <div className="slider-section">
                                <Slider {...sliderDesktopSettings} ref={slickSlider}>
                                    {
                                        data && data.cards && data.cards.map((elem, index)=>(
                                            <div className="swiper-card-wrapper">
                                                <div className={`swiper-card ${activeSlideIndex == index ? 'active' : ''}`}>
                                                    <div className="card-text-wrapper"> 
                                                        <h5>{elem.title}</h5>
                                                        <p>{elem.description}</p>
                                                        {
                                                            elem.linkText && 
                                                            <a href={elem.link}>{elem.linkText}</a>
                                                        }
                                                    </div>
                                                </div>
                                            </div>
                                        ))
                                    }
                                </Slider>
                            </div>
                        </div>


                        <div className="image-container desktop">
                            <div className="image-wrapper">
                                <img src={data?.image?.url} />
                            </div>
                        </div>



                    </div>
                </Section>


            </SequenceReveal>
        </ParallaxBox>
        <div className="thread-image">
            <img src={ThreadImage} />
        </div>
    </SectionWrapper>
    </>
    )

}

export default connect(SectionFAQ)
