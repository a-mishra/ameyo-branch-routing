import React, {  useRef, useEffect, useState, useLayoutEffect } from 'react'
import { connect, styled , Global, css} from 'frontity';
import {layout, SectionAnimation} from '../../../utils/constants';
import {useOnScreen, useWindowDimentions, useContainerDimensions} from '../../../utils/hooks/usehooks'
import { Section, Row, Col, Container } from '../../misc/layout';
import { motion, useMotionValue, useAnimation } from "framer-motion";

import StackedSwiper from './stacked-swiper'

const SectionWrapper = styled.div`
    min-height: 300px;
    position: relative;
    padding-bottom: 3rem;
    overflow-x: clip;

    .section-inner {
        position: relative;
    }
`;

const SectionTestimonials = ({state, actions, data, libraries}) =>  {

    const ref = useRef(null)
    const [onScreen, portionInView, viewed] = useOnScreen(ref, "0px");
    useEffect(() => {
        actions.intraPageLinks.update(data?.section?.internalLink, portionInView);
        return () => {
            actions.intraPageLinks.update(data?.section?.internalLink, 0);
        }
    }, [portionInView])

    const Html2React = libraries.html2react.Component;

    const SectionInnerRef = useRef(null);
    const [width, setwidth] = useState(0);

    const handleResize = () => {
        if(SectionInnerRef.current) {
            setwidth(SectionInnerRef.current.offsetWidth);
        }
    }

    useEffect(() => {
        handleResize();
        window.addEventListener("resize", handleResize)
        window.addEventListener("orientationchange", handleResize)
        
        return () => {
        window.removeEventListener("resize", handleResize)
        window.removeEventListener("orientationchange", handleResize)
        }
    }, [])

    return (
    <>
    <SectionWrapper ref={ref}>
        <Section padding={data && data.logo && data.logo.length > 0 ? 'level1': 'level4'}  id={data?.section?.internalLink} paddingMob={'level0'}>
            <motion.div 
                className={`section-inner`} 
                ref={SectionInnerRef} 
                variants={SectionAnimation}
                initial={'hidden'}
                animate={viewed ? 'show' : 'hidden'}
                transition={{
                    ...SectionAnimation.transition(0, true)
                }}
                onAnimationComplete={handleResize}
            >
                <StackedSwiper width={width} data={data}/>
            </motion.div>
        </Section>
    </SectionWrapper>
    </>
    )

}

export default connect(SectionTestimonials)