import React from 'react'
import SectionBusinessUsecases from '../components/sections/business-usecases/index'

import { Section } from '../components/misc/layout';

const ComponentWrapper = ({data}) => {


    return (
        // <SectionBusinessUsecases data={data} />
        <Section>
            {`Plugin 'Business usecases' is depricated, please redefine this block from opwsections -> businessUsecase!!!`}
        </Section>
    )
};

const businessusecases = {
    name: 'businessusecases',
    priority: 20,
    test: ({ component, props }) => component === "div" && props.className.split(' ').includes("wp-block-cgb-block-business-usecases"),
    processor: ({ node,props }) => {

        let data = JSON.parse(node.children[0].children[0].content || '{}'); 
        if(data.cards) {
            data.cards = JSON.parse(data.cards);
        }

        return {
          component: ComponentWrapper,
          props: {data},
        }
      },
}

export default businessusecases;