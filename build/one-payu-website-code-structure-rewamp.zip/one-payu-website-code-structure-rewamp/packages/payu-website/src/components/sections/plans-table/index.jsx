import React, {  useRef, useEffect, useState, useLayoutEffect } from 'react'
import { connect, styled , Global, css} from 'frontity';
import {layout, SectionAnimation} from '../../../utils/constants';
import {useOnScreen, useWindowDimentions, useContainerDimensions, useType} from '../../../utils/hooks/usehooks'
import { Section, Container } from '../../misc/layout';
import { motion, useMotionValue, useAnimation } from "framer-motion";
import DropDownIcon from '../../../assets/icons/dropdown.svg'
import DropDownReversedIcon from '../../../assets/icons/dropdown_reversed.svg'
import {MobileTable} from './mobile-table'

const SectionWrapper = styled.div`
position: relative;
overflow-x: clip;

.section-container {
    ${layout.screen.mob} {
        padding-left: 0px;
        padding-right: 0px;
    }
}


.section-inner {
    .text-table-conatiner {
        display: flex;
        flex-direction: column;

        .texts {
            padding-bottom: 0px;
            margin-bottom: 4rem;

            .texts-heading {
                color: #0E342C;
            }
            .texts-description {
                margin-top: ${layout.reponsiveCssValue(4, 19, 1200, 2, 1600, 19)};
            }

            ${layout.screen.mob} {
                padding-left: ${layout.constants.mobile_padding['level4'] || '0rem'};
                padding-right: ${layout.constants.mobile_padding['level4'] || '0rem'};

                margin-bottom: 2.5rem;
                
                .texts-heading {
                    margin: 0rem;
                }

                .texts-description {
                    margin-top: 1.5rem;
                }
            }
        }

        .table-container {
            padding-top: 0px;
            margin-top: 0px;
            ${layout.screen.xs} {
                padding-left: 0px;
                padding-right: 0px;
            }
            box-sizing: border-box;

            .table-wrapper {
                background: rgba(255, 255, 255, 0.4);
                border: 2px solid rgba(255, 255, 255, 0.72);
                border-radius: ${layout.reponsiveCssValue(20, 26.9, 1200, 20, 1600, 26.9)};


                padding: ${layout.reponsiveCssValue(27.42,36.58, 1200, 27.42, 1600, 36.58)};
                display: grid;
                grid-template-columns: repeat(1, auto);
                grid-row-gap: 0px;
            }

        }
    }
}
`;

const SectionPlansTable = ({state, actions, data, libraries}) =>  {
    const ref = useRef(null)
    const [onScreen, portionInView, viewed] = useOnScreen(ref, "0px");
    const Html2React = libraries.html2react.Component;
    const deviceType = useType();

    useEffect(() => {
        actions.intraPageLinks.update(data?.section?.internalLink, portionInView);
        return () => {
            actions.intraPageLinks.update(data?.section?.internalLink, 0);
        }
    }, [portionInView])

    
    useEffect(() => {
        // console.log('data in Section Plans Table:', data);
    }, [])


    return (
        <>
            <SectionWrapper  id={data?.section?.internalLink}>
                <div className='section-container'>
                    <motion.div 
                        className="section-inner"
                        ref={ref}
                        variants={SectionAnimation}
                        initial={'hidden'}
                        animate={viewed ? 'show' : 'hidden'}
                        transition={{
                            ...SectionAnimation.transition(0, true)
                        }}
                    >
    
                        <div className="text-table-conatiner"> 
                            <Section padding={'level4'} className="texts">
                                <h2 className={`${deviceType=='mobile'? 'h1':'h2'} texts-heading`}>{data.heading}</h2>
                                <p className={`${deviceType=='mobile'? 'body1':'body1'} texts-description`}>{data.description}</p>
                            </Section>

                            <Section padding={'level3'} className="table-container">
                                    
                                    {
                                        deviceType == 'mobile' ? 
                                            <MobileTable data={data} viewed={viewed} deviceType={deviceType}/>
                                        :
                                            <motion.div
                                                className='table-wrapper'
                                                variants={SectionAnimation}
                                                initial={'hidden'}
                                                animate={viewed ? 'show' : 'hidden'}
                                                transition={{
                                                    ...SectionAnimation.transition(1, false)
                                                }}
                                            >
                                                <Header data={data?.column} viewed={viewed} deviceType={deviceType} />
                                                {data?.row?.map((elem, index) => (
                                                            <>
                                                                {<Row index={index} data={elem} viewed={viewed} deviceType={deviceType} numberOfColumns={data?.column?.length} isLastRow={index+1 == data?.row?.length ? true : false}/>}
                                                            </>
                                                        )
                                                    )
                                                }
                                            </motion.div>
                                    }
                                    


                            </Section>
                        </div>

                    </motion.div>
                </div>

            </SectionWrapper>
        </>
    )
}

export default connect(SectionPlansTable)


const ItemAnimation = {
    hidden: {
        opacity: 0,
        scale: 1,
        y: 20
    },
    show: {
        opacity: 1.1,
        y: 0,
        scale: 1,
    },
    hover: {
        opacity: 1.1,
        y: 0,
    },
    transition: (n) => ({
        y: { type: "spring",
          damping: 10,
          mass: 0.2,
          stiffness: 150
         }, 
        ease: 'anticipate',
        duration:  0.5, 
        delay:  0.150*n + .150, 
    })
}


/**
 * Header
 */
    const Header = (props) => {

        return(
            <HeaderWrapper numberOfColumns={props?.data?.length}>
                    <FirstHeaderCell/>
                    <motion.div
                        className='data-cells'
                    >
                    {
                        props?.data?.map((elem, index)=>(
                            <HeaderCell data={elem} index={index}/>
                        ))
                    }
                    </motion.div>
            </HeaderWrapper>
        )
    }

    const HeaderWrapper = styled.div`
        display: grid;
        grid-template-columns: 27% auto;
        grid-column-gap: 0px;

        .data-cells {
            display: grid;
            grid-template-columns: repeat(${(props)=>(props.numberOfColumns)},  minmax(0, 1fr) );
            grid-column-gap: 0px
        }
    `;


    const HeaderCell = (props) => {
        return(
            <HeaderCellWrapper>
                <p className='h6 cell-title'>{props?.data?.title}</p>
            </HeaderCellWrapper>
        )
    }

    const HeaderCellWrapper = styled.div`
        margin-left: ${layout.reponsiveCssValue(24, 44, 1200, 33, 1600, 44)};

        display: grid;
        grid-template-columns: repeat(1, auto);
        grid-row-gap: 4px;

        justify-content: center;
        justify-content: center;
        text-align: center;
        background: #fff;
        border-radius: ${layout.reponsiveCssValue(20, 26.9, 1200, 20, 1600, 26.9)};
        border-bottom-left-radius: 0px;
        border-bottom-right-radius: 0px;

        padding-top: ${layout.reponsiveCssValue(23, 30, 1200, 23, 1600, 30)};
        padding-bottom: ${layout.reponsiveCssValue(23, 30, 1200, 23, 1600, 30)};
        padding-left: ${layout.reponsiveCssValue(14, 21, 1200, 14, 1600, 21)};
        padding-right: ${layout.reponsiveCssValue(14, 21, 1200, 14, 1600, 21)};

        .cell-title {
            color: #0E342C;
        }
    `;

    const FirstHeaderCell = (props) => {
        return(
            <FirstHeaderCellWrapper>
                <p className='h6'>{props?.data?.title}</p>
            </FirstHeaderCellWrapper>
        )
    }
    const FirstHeaderCellWrapper = styled.div`
        background: #EAEFEC;
        border-radius: ${layout.reponsiveCssValue(20, 26.9, 1200, 20, 1600, 26.9)};
        border-bottom-left-radius: 0px;
        border-bottom-right-radius: 0px;
        padding: 29px;

    `;




/**
 * Row
 */
    const Row = (props) => {
        const [animationCompleted, setanimationCompleted] = useState(false)
        // props?.isLastRow


        return(
            <RowWrapper isLastRow={props?.isLastRow} numberOfColumns={props?.numberOfColumns}>
                <motion.div className='cells-wrapper'
                    // variants={ItemAnimation}
                    // whileHover= {'hover'}
                    // initial={'hidden'}
                    // animate={props?.viewed ? 'show' : 'hidden'}
                    // transition={
                    //     // animationCompleted && props?.viewed ? 
                    //     {
                    //         transition: { duration: 0.500, delay: .500 }
                    //     }
                    //     // : {
                    //     //     ...ItemAnimation.transition(props.index+1)
                    //     // }
                    // }
                    // onAnimationComplete={()=>setanimationCompleted(true)}
                >
                    <RowTitleCell title={props?.data?.title} isLastRow={props?.isLastRow}/>
                    
                    <motion.div
                        className='data-cells'
                    >
                    {
                        props?.data?.cell?.map((elem, index)=>(
                            <Cell data={elem} index={index} isLastRow={props?.isLastRow}/>
                        ))
                    }
                    </motion.div>
                    
                </motion.div>
                
            </RowWrapper>
        )
    }

    const RowWrapper = styled.div`
        .cells-wrapper {
            display: grid;
            grid-template-columns: 27% auto;
            grid-column-gap: 0px;

            .data-cells {
                display: grid;
                grid-template-columns: repeat(${(props)=>(props.numberOfColumns)},  minmax(0, 1fr) );
                grid-column-gap: 0px
            }
            
        }
    `;


    /**
     * Cell
     */
        const RowTitleCell = (props) => {
            return(
                <RowTitleCellWrapper isLastRow={props?.isLastRow}>
                    <p className='h7 cell-title'>{props?.title}</p>
                </RowTitleCellWrapper>
            )
        }

        const RowTitleCellWrapper = styled.div`
            display: grid;
            grid-template-columns: repeat(1, auto);
            grid-row-gap: 4px;
            background: #EAEFEC;
            padding-top: ${layout.reponsiveCssValue(14, 19, 1200, 14, 1600, 19)};
            padding-bottom: ${layout.reponsiveCssValue(14, 19, 1200, 14, 1600, 19)};
            padding-left: ${layout.reponsiveCssValue(27, 43, 1200, 27, 1600, 43)};
            padding-right: ${layout.reponsiveCssValue(27, 43, 1200, 27, 1600, 43)};

            ${(props)=>(props.isLastRow == true ? `
                border-radius: ${layout.reponsiveCssValue(20, 26.9, 1200, 20, 1600, 26.9)};
                border-top-left-radius: 0px;
                border-top-right-radius: 0px;

            `:`
                border-bottom: 0.961971px solid #BFDFBA;
            `)}

            .cell-title {
                color: #0E342C;
            }

        `;


        const Cell = (props) => {
            return(
                <CellWrapper isLastRow={props?.isLastRow}>
                    <p className='body2 cell-title'>{props?.data?.title}</p>
                    <p className='nav-text-6 cell-subtext'>{props?.data?.subText}</p>
                    {props?.data?.image?.url && <motion.div className='image-wrapper' >
                        <img src={props?.data?.image?.url} alt={props?.data?.image?.name}></img>
                    </motion.div>}
                </CellWrapper>
            )
        }

        const CellWrapper = styled.div`
            margin-left: ${layout.reponsiveCssValue(24, 44, 1200, 33, 1600, 44)};
            display: grid;
            grid-template-columns: repeat(1, auto);
            grid-row-gap: 4px;

            justify-content: center;
            justify-content: center;
            text-align: center;

            background: #fff;
            padding-top: ${layout.reponsiveCssValue(14, 19, 1200, 14, 1600, 19)};
            padding-bottom: ${layout.reponsiveCssValue(17, 23, 1200, 17, 1600, 23)};
            padding-left: ${layout.reponsiveCssValue(27, 43, 1200, 27, 1600, 43)};
            padding-right: ${layout.reponsiveCssValue(27, 43, 1200, 27, 1600, 43)};

            ${(props)=>(props.isLastRow == true ? `
                border-radius: ${layout.reponsiveCssValue(20, 26.9, 1200, 20, 1600, 26.9)};
                border-top-left-radius: 0px;
                border-top-right-radius: 0px;
                padding-bottom: 60px;
            `:`
                border-bottom: 0.961971px solid #BFDFBA;
            `)}

            .cell-title {
                color: #40413B;
            }

            .cell-subtext {
                color: #96A5A2;
            }

            .image-wrapper {
                margin-top: ${layout.reponsiveCssValue(4, 9, 1200, 4, 1600, 9)};
                img {
                    width: ${layout.reponsiveCssValue(69, 92, 1200, 69, 1600, 92)};
                    height: auto;
                }
                
            }
        `;



