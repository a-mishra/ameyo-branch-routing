import Root from './components/root'
import image from "@frontity/html2react/processors/image";
import link from "@frontity/html2react/processors/link";
import parser from 'ua-parser-js'

import assetHandler from './handlers/asset-handler'
import opwsections from './processors/opwsections';

import { colors } from './utils/constants';
import { getPostToRender } from "./utils/methods";


const PayUWebsite =  {
  name: "payu-website",
  roots: {
    theme: Root
  },
  state: {
    theme: {
      colors,
    },
    "intraPageLinks": [],
    nav: {
      footer: {},
      header: {}
    },
    environment: {},
    assets: {}
    /* key: value
    key = url;
    value = {
      isFetching,
      isReady,
      data,
      type,
    }
    */
  },
  actions: {
    theme: {
      beforeSSR: ({ state, actions }) => async ({ ctx }) => {
        const ua = ctx.get("user-agent");
        const parsed_ua = parser(ua);
        state.environment.ua = parsed_ua;
        state.environment.isWindowsDesktop = parsed_ua?.browser?.name?.includes('Chrome') && parsed_ua?.os?.name?.includes('Window') ? true : false;
        state.environment.isFirefox = parsed_ua?.browser?.name?.includes('Firefox') ? true : false;
        state.environment.isMobile = parsed_ua?.device?.type?.includes('mobile') || parsed_ua?.device?.type?.includes('tablet') ? true : false;

        await actions.nav.getHeader();
        await actions.nav.getFooter();
        // await actions.source.fetch(getPostToRender(state.router.link));
        // await actions.nav.getHome();
        // ctx.throw(401, 'access_denied');
        // # Possible 'device.type': console, mobile, tablet, smarttv, wearable, embedded

        // if(state.router.link == '/') {
        //   ctx.throw(200);
        // }

      },
      beforeCSR: async ({ state, actions }) => {
        await actions.intraPageLinks.clear();
      },
    },
    source: {

    },
    intraPageLinks: {
      clear: ({state}) => {
        // console.log(`intraPageLinks -> Clearing`)
        state.intraPageLinks = [];
      },
      push: ({state}) => (data) => {
        // console.log(`intraPageLinks -> Pushing ${JSON.stringify(data)}`)
        state.intraPageLinks.push(data);
      },
      update: ({state}) => (link, portionInView) => {
        
        // take percentage inView of diffrent section; the section which has largest % shall dominate and shall be activated
        let intraPageLinks  = state.intraPageLinks;
        let LinkWithLargestViewPortion = {index: -1, portionInView: 0};
        intraPageLinks.forEach((element, index) => {
          if(element.link == link) {
            intraPageLinks[index].portionInView = portionInView;
          }
          intraPageLinks[index].active= false;
          if(element?.portionInView && (element?.portionInView > LinkWithLargestViewPortion.portionInView) ) {
            LinkWithLargestViewPortion = {index, portionInView: element.portionInView};
          }
        });

        // console.log(`intraPageLinks`, intraPageLinks);
        // console.log(`LinkWithLargestViewPortion`, LinkWithLargestViewPortion);
        if(LinkWithLargestViewPortion.index>=0) {
          intraPageLinks[LinkWithLargestViewPortion.index].active = true;
        }

        state.intraPageLinks = intraPageLinks;
        
      }
    },
    nav: {
      getFooter: ({state, actions}) => {
        actions.source.fetch(`/footer/`,{force: false})
        .then(()=>{
          let data = state.source.get(`/footer/`);
          const page = state.source[data.type][data.id];
          state.nav.footer = page;
        })
      },

      getHeader: ({state, actions}) => {
        actions.source.fetch(`/header/`,{force: false})
        .then(()=>{
          let data = state.source.get(`/header/`);
          const page = state.source[data.type][data.id];
          state.nav.header = page;
        })
      },

      getHome: ({state, actions}) => {
        actions.source.fetch(`/home/`,{force: false})
        .then(()=>{
          
        })
      },

      getCurrentPage: ({state, actions}) => {
        actions.source.fetch(getPostToRender(state.router.link),{force: false})
        .then(()=>{
          let data = state.source.get(getPostToRender(state.router.link));
          const page = state.source[data.type][data.id];
          state.nav.currentPage = page;
        })
      },

    },
    assets: {
      get: ({state, actions}) => (key)  => {
        // check in state if this key exists;
        // if not check in localstorage;
        // if not make a network call and wait till result
        // store the result in state;
        // store the result in localstorage;

        //in the client use state?.assets?.[url] instead of asset url;
        return state.assets;
      },
      post:({state, actions}) => (key, value) => {
        state.assets[key] = value;
      }
    }
  },
  
  libraries: {
    html2react: {
      processors: [image, link, opwsections ],
    },
    source: {
      handlers: [assetHandler],
    },
  },
};

export default PayUWebsite;