import React, {useRef, useState, useEffect} from 'react';
import ReactPlayer from 'react-player'
import {styled} from 'frontity'

const Video = ({video, markedFrames, resetPage, next, page, inView, onLoad, height, width, manuallySelectedPage}) => {

    const playerref = useRef();

    const [isLoaded, setisLoaded] = useState(false);
    const [isPlaying, setisPlaying] = useState(false);
    const fps = 60;
    const markedSeconds = markedFrames.map((value, index, elements)=>{
            return (  Math.floor(((value )/ fps)*1000)  );  //ms to next part of animation
    });

    const handleLoaded = () => {
        setisLoaded(true);
        if(inView)
            setisPlaying(true);
        onLoad();
    }

    const handleReset = () => {
        playerref?.seekTo?.( markedSeconds[0], 'seconds' );
    }

    const startSection = (sectionId) => {
        console.log('playerref', playerref)
        playerref?.seekTo?.(markedSeconds[sectionId] , 'seconds' );
    }

    const handleProgress = (data) => {
        console.log(data)
    }


    useEffect(() => {
        if(page == 0)
            startSection(page);
    }, [page])

    useEffect(() => {
        startSection(manuallySelectedPage);
    }, [manuallySelectedPage])


    useEffect(() => {
        if(inView === true && isLoaded)
            setisPlaying(true);
        else if(inView === false) {
        }
    }, [inView, isLoaded])

    // const setplayerref = ({player,wrapper}) => {

    //     playerref = player;
    // }

    return (
        <ReactPlayer 
            ref={(player)=>playerref}
            url={video?.url || ''}
            className='react-player'
            playing={isPlaying}
            width={width || 'auto'}
            height= {height || 'auto'}
            controls={false}
            loop={true}
            muted={true}
            playsinline={true}
            progressInterval={250}
            onProgress={handleProgress}
            onReady={handleLoaded}
            onEnded={handleReset}
        />
    )
}


export default Video;