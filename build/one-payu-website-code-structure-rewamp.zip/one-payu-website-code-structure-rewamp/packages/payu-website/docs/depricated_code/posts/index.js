import { styled, connect } from "frontity";
import {useEffect, useState} from 'react';
import Loading from "../pages/misc/loading";
import Post from "./post";
import { getPostToRender} from '../../utils/methods'

const Posts = ({ state, actions, libraries }) => {

  // Get information about the current URL.
  const data = state.source.get(getPostToRender(state.router.link));
  // Get the data of the post.
  const page = state.source[data.type][data.id];

  // Get the html2react component.
  const Html2React = libraries.html2react.Component;

  /**
   * Once the post has loaded in the DOM, prefetch both the
   * home posts and the list component so if the user visits
   * the home page, everything is ready and it loads instantly.
   */
  // useEffect(() => {
  //   actions.source.fetch('/');
  //   List.preload();
  // }, []);


  if(data.isReady) {
    const post = data.id ? state.source[data.type][data.id] : null;
    return (
      <Container id={"postContainer"}>
      </Container>
    );
  } else {
    // if is404 : return not found
    // if isReady false return loading
    return (
      <>
      </>
    )
  }
};

export default connect(Posts);

export const Container = styled.div`
  width: 100%;
  flex-grow: 1;
`;
