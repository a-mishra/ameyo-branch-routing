import { styled } from 'frontity';
import { layout, container_max_width } from '../../utils/constants'




export const Container = styled.div`
    position: relative;
    // border: dashed 1px #2F695D;
    padding-right: 1.5rem;
    padding-left: 1.5rem;
    margin-right: auto;
    margin-left: auto;

    padding-left: ${(props)=>( layout.constants.padding[props.padding] || '1.5rem')};
    padding-right: ${(props)=>( layout.constants.padding[props.padding] || '1.5rem')};

    width: ${(props)=>( layout.constants.width[props.padding] || '85%')};

    ${layout.screen.mob} {
        width: 100%;
        padding-left: ${(props)=>( layout.constants.mobile_padding[props.paddingMob || props.padding] || '0rem')};
        padding-right: ${(props)=>( layout.constants.mobile_padding[props.paddingMob || props.padding] || '0rem')};
    }

    ${layout.screen.sm} {
        max-width: ${container_max_width.sm}px;
    }
    ${layout.screen.md} {
        max-width: ${container_max_width.md}px;
        padding-left: ${(props)=>( props.padding == 'level4' ? (layout.reponsiveCssValue(0, 36, 992, 0, 1440, 36)): (layout.constants.mobile_padding[props.paddingMob || props.padding] || '0rem'))};
        padding-right: ${(props)=>( props.padding == 'level4' ? (layout.reponsiveCssValue(0, 36, 992, 0, 1440, 36)): (layout.constants.mobile_padding[props.paddingMob || props.padding] || '0rem'))};
    }
    ${layout.screen.lg} {
        max-width: 90%;
    }

    ${layout.screen.xxl} {
        max-width: ${container_max_width.xxl}px;
    }
`;

export const Row = styled.div`
    display: grid;
    grid-template-columns: repeat(12, 1fr);
    grid-auto-flow: row;
    gap: ${(props)=>props.gap};
`;

export const Col = styled.div`
    grid-column: auto;

    ${layout.screen.xs} {
        grid-column: span ${(props)=>props.xs};
     }

    ${layout.screen.sm} {
       grid-column: span ${(props)=>props.sm};
    }

    ${layout.screen.md} {
       grid-column: span ${(props)=>props.md};
    }

    ${layout.screen.lg} {
       grid-column: span ${(props)=>props.lg};
    }

    ${layout.screen.xl} {
       grid-column: span ${(props)=>props.xl};
    }

    ${layout.screen.xxl} {
       grid-column: span ${(props)=>props.xxl};
    }

    align-self: ${(props)=>(props.centered == true ? 'center' : (props.vcenter== true ? 'center' : 'stretch'))};
    justify-self: ${(props)=>(props.centered == true ? 'center' : (props.hcenter== true ? 'center' : 'stretch'))};

`;


export const Section = styled(Container)`
    position: relative;

    margin-top: ${layout.reponsiveCssValue( 100, 100 ,1200, 100, 1600, 100)};
    padding-top: ${layout.reponsiveCssValue( 30, 70 ,1200, 30, 1600, 70)};

    ${layout.screen.mob} {
        margin-top: ${layout.reponsiveCssValue( 100, 100 ,375, 100, 1200, 100)};
        padding-top: ${layout.reponsiveCssValue( 24, 30 ,375, 24, 1200, 30)};
    }
`;


export const MobileOnly = styled.div`
    display: none;
    ${layout.screen.xs} {
        display: block;
    }
`;


export const BelowLargeScreen = styled(MobileOnly)`
    ${layout.screen.sm} {
        display: block;
    }
    ${layout.screen.lg} {
        display: none;
    }
`;