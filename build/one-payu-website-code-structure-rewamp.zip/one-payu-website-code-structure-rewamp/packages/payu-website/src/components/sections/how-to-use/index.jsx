import React, {  useRef, useEffect, useState, useLayoutEffect } from 'react'
import { connect, styled , Global, css} from 'frontity';
import {layout, SectionAnimation} from '../../../utils/constants';
import {useOnScreen, useWindowDimentions, useContainerDimensions, useType} from '../../../utils/hooks/usehooks'

import { Section, Row, Col, Container } from '../../misc/layout';
import { motion, useMotionValue, useAnimation, AnimatePresence } from "framer-motion";
import Animation from './animation';
import MobileAnimation from './mobile-animation';
import NavArrowRightIcon from '../../../assets/icons/nav_arrow_right.svg'
import { Swiper } from './Swiper';
import { useInterval } from "usehooks-ts";
import {getAnimDimentions} from '../../../utils/methods';
import Video from './video2'

const SectionWrapper = styled.div`
    min-height: 300px;
    position: relative;
    overflow-x: clip;
    
    .section-inner {
        display: flex;
        flex-direction: column;

        .text-payment-button-container {
            display: flex;
            flex-direction: row;
            flex: 1;
            .texts {
                // max-width: 550px;
                justify-content: left;
                align-items: center;
                display: flex;
                flex: 1;

                flex-direction: column;
                align-items: flex-start;
                padding-right: 78px;
                ${layout.screen.mob} {
                    padding-right: 0px;
                }
                
                h1,h2,h3,h4,h5,h6 {
                    color: #0E342C;
                    margin: 0px;
                    ${layout.screen.mob} {
                        color: #141416;
                    }
                    
                }
                p {
                    margin-top: 0.5rem;
                    color: #314235;
                }
            }
            .payment-button {
                display: flex;
                justify-content: flex-end;
                // flex: 1;
                ${layout.screen.mob} {
                    display:none;
                }
            }

        }

        .steps-animation-container {
            display: flex;
            flex: 1;
            position: relative;
            margin-top: 4rem;
            ${layout.screen.mob} {
                display: none;
            }

            .steps-container {
                flex: 0 0 50%;
                width: 50%;
                display: flex;
                justify-content: flex-start;
                align-items: flex-start;
                flex-direction: column;
                // gap: ${layout.reponsiveCssValue(24, 32, 1440, 27, 1600, 32)};
                margin-top: 0rem;
                min-height: 400px;
                justify-content: center;
            }

            .steps-container > div {
                &:not(:last-child) {
                    margin-bottom: ${layout.reponsiveCssValue(24, 32, 1440, 27, 1600, 32)}; // flex->gap safari <14.1 fix
                }
            }
            
            .animation-container {
                flex: 1;
                display: flex;
                justify-content: flex-end;
                align-items: center;

                position: absolute;
                left: 50%;
                top: 0;
                bottom: 0;
                right: 0;
                overflow: none;
            }
        }


        .animation-container-mobile {
            display: none;
            ${layout.screen.mob} {
                display:flex;
                justify-content: center;
                align-items: center;
                // margin-top: ${layout.reponsiveCssValue(64, 86, 375, 86, 993, 64)};
                margin-top: ${layout.reponsiveCssValue(48, 64, 375, 64, 993, 64)};
                min-height: 200px;
            }
        }
    }

    .mobile-swiper-wrapper {
        display: none;
        ${layout.screen.mob} {
            display: block;
            // margin-top: ${layout.reponsiveCssValue(64, 86, 375, 86, 993, 64)};
            margin-top: ${layout.reponsiveCssValue(48, 64, 375, 64, 993, 64)};

        }
    }


`;


const usePageCounter = () => {
    const [page, setpage] = useState( 0)
  
    const incrementpage = () => setpage(x => x + 1)
    const decrementpage = () => setpage(x => x - 1)
    const resetpage = () => setpage( 0)
  
    return {
      page,
      incrementpage,
      decrementpage,
      resetpage,
      setpage,
    }
  }

const SectionHowToUse = ({state, actions, data, libraries, isImageTransitionType}) =>  {

    const ref = useRef(null)
    const [onScreen, portionInView, viewed] = useOnScreen(ref, "0px");  
    const deviceType = useType();

    useEffect(() => {
        actions.intraPageLinks.update(data?.section?.internalLink, portionInView);
        return () => {
            actions.intraPageLinks.update(data?.section?.internalLink, 0);
        }
    }, [portionInView])

    const markedFrame = data?.buttons?.map((elem)=>(elem.frameId)) || [];
    const Html2React = libraries.html2react.Component;

    const stepsContainerRef = useRef(null);
    const [ count, setCount] = useState(0);
    const stepsDimention = useContainerDimensions(stepsContainerRef, count);
    const reCalculateContainerWidth = () => {
        setCount(count+1);
    }

    const { page, setpage, incrementpage, decrementpage, resetpage } = usePageCounter(0);
    const [manuallySelectedPage, setmanuallySelectedPage] = useState(0);

    const nextPage = () => {
        let range = data?.buttons?.length ;
        setpage(x=>(x+1)%range)
    }

    const setpagewrapper = (newpage) => {
        setpage(newpage);
    }

    const handleCardSelect = (page) => {
        setpagewrapper(page);
        setmanuallySelectedPage(page);
    }


    useEffect(() => {
        if(isImageTransitionType) {
            setTimerRunning(onScreen);
        }
    }, [onScreen])


    const [delay, setDelay] = useState(data?.settings?.cardSwitchInterval ? Number(data?.settings?.cardSwitchInterval)*1000 :  10000 );
    const [timerRunning, setTimerRunning] = useState(!(!isImageTransitionType));

    useInterval(
        () => {
            let range = data?.buttons?.length ;
            if(range)
                setpagewrapper(((page+1) % range));
        },
        timerRunning ? delay : null
    );

    const [animWidth, setanimWidth] = useState(0);
    const [animHeight, setanimHeight] = useState(0);
    const handleResize = () => {
        if(window?.innerWidth) {
            let animDimentions = getAnimDimentions(data?.settings?.animationSize?.value, window.innerWidth, false);
            setanimWidth(animDimentions.width);
            setanimHeight(animDimentions.height);
        }
    }

    useEffect(() => {
        handleResize();
        //console.log('howToUse', data)
        window.addEventListener("resize", handleResize)
        window.addEventListener("orientationchange", handleResize)
        
        return () => {
        window.removeEventListener("resize", handleResize)
        window.removeEventListener("orientationchange", handleResize)
        }
    }, [])

    // const [animationContainerAnimatedFlag, setanimationContainerAnimatedFlag] = useState(false)

    return (
        <>
            <SectionWrapper id={data?.section?.internalLink}>
                <Section padding={'level4'}>
                            <motion.div 
                                className="section-inner"
                                ref={ref}
                            >

                                <div className="text-payment-button-container"> 
                                    <motion.div className="texts"
                                        variants={SectionAnimation}
                                        initial={'hidden'}
                                        animate={viewed ? 'show' : 'hidden'}
                                        transition={{ 
                                            // duration: 0.8, 
                                            // delay: 0.0, 
                                            ...SectionAnimation.transition(0, true)
                                        }}
                                    >
                                        <h2 className='h2'>{data?.heading}</h2>
                                        <p className="body2">{data?.description}</p>
                                    </motion.div>

                                    {data["payment Button"]?.linkText && <motion.div 
                                        className="payment-button"
                                        variants={SectionAnimation}
                                        initial={'hidden'}
                                        animate={viewed ? 'show' : 'hidden'}
                                        transition={{ 
                                            // duration: 0.5, 
                                            // delay: 1.5,
                                            ...SectionAnimation.transition(3)
                                        }}
                                    >
                                        <Button title={data["payment Button"]?.linkText} link={data["payment Button"]?.link} type="light"/>
                                    </motion.div>}
                                </div>

                                <div className="steps-animation-container">

                                    <motion.div 
                                        className={'steps-container'}
                                        variants={SectionAnimation}
                                        initial={'hidden'}
                                        animate={viewed ? 'show' : 'hidden'}
                                        transition={{ 
                                            // duration: 0.5, 
                                            // delay: 0.7,
                                            ...SectionAnimation.transition(1)
                                        }}
                                        onAnimationComplete={reCalculateContainerWidth}
                                        onAnimationEnd={reCalculateContainerWidth}
                                        ref={stepsContainerRef}
                                    >
                                        {data?.buttons?.map((elem, index)=>(
                                            <Card {...elem} page={page} index={index} onClick={()=>{handleCardSelect(index)}}/>
                                        ))}
                                    </motion.div>

                                    <motion.div className="animation-container"
                                        variants={SectionAnimation}
                                        initial={'hidden'}
                                        animate={viewed ? 'show' : 'hidden'}
                                        transition={{ 
                                            // duration: 0.5, 
                                            // delay: 1.1,
                                            ...SectionAnimation.transition(2)
                                        }}
                                        // onAnimationEnd={()=>{setanimationContainerAnimatedFlag(true)}}
                                    >
                                            {
                                                isImageTransitionType ?
                                                    <div style={{width:'100%'}}>
                                                        {data?.buttons?.map((elem, index)=>(
                                                            <AnimatePresence>
                                                                {page == (index) && (
                                                                    <motion.img
                                                                        initial={{
                                                                            opacity: 0, y: 60, scale: 0.95, 
                                                                        }}
                                                                        animate={{ opacity: 1, y:0, scale: 1 ,
                                                                            transition: {
                                                                                // delay: 1.5,
                                                                                duration: 0.8
                                                                            }
                                                                        }}
                                                                        // exit={{ opacity: 0, y: 60, scale: 0.95 ,
                                                                        //     transition: {
                                                                        //         delay: 0,
                                                                        //         duration: 0.8
                                                                        //     } 
                                                                        // }}
                                                                        src={elem?.image?.url}
                                                                    >
                                                                    </motion.img>
                                                                )}
                                                            </AnimatePresence>
                                                        ))}
                                                    </div>
                                                :

                                                (
                                                    (state?.environment?.isWindowsDesktop==true && data?.settings?.dontUseFallback?.value!=='true') && deviceType == 'desktop' ?
                                                        <Video
                                                            video={data?.fallbackVideo}
                                                            markedFrames={markedFrame} 
                                                            resetpage={resetpage}
                                                            next={nextPage}
                                                            setPage={setpagewrapper}
                                                            page={page}
                                                            inView={ onScreen }
                                                            onLoad={()=>{}}
                                                            width={animWidth} 
                                                            height={animHeight}
                                                            manuallySelectedPage={manuallySelectedPage}
                                                        />
                                                    :
                                                        <Animation 
                                                            markedFrames={markedFrame} 
                                                            // frameRangeChangedCallback={(newpage)=>{ page!=newpage && setpagewrapper(newpage)}} 
                                                            // startFromFrame={startingFrame} 
                                                            lottie={data?.animation || {}} 
                                                            inView={ 
                                                                onScreen 
                                                                // && animationContainerAnimatedFlag ? true : false 
                                                            }
                                                            onLoad={()=>{}}
                                                            // height={stepsDimention.height}
                                                            // width={stepsDimention.width}
                                                            page={page}
                                                            // setpage={(newpage)=>{console.log(new Date().toLocaleString(), 'PAGE CHANGED : ', newpage); setpagewrapper(newpage)}}
                                                            setpage={()=>{}}
                                                            resetpage={resetpage}
                                                            next={nextPage}
                                                            manuallySelectedPage={manuallySelectedPage}
                                                            width={animWidth} 
                                                            height={animHeight}
                                                        />
                                                )
                                                
                                                
                                                
                                            }
                                    </motion.div>
                                </div>

                                <motion.div className="animation-container-mobile"
                                        variants={SectionAnimation}
                                        initial={'hidden'}
                                        animate={viewed ? 'show' : 'hidden'}
                                        transition={{ 
                                            // duration: 0.5, 
                                            // delay: 1.1,
                                            ...SectionAnimation.transition(2)
                                        }}
                                        // onAnimationEnd={()=>{setanimationContainerAnimatedFlag(true)}}
                                    >
                                            {
                                                isImageTransitionType ?
                                                <div style={{width:'100%', maxHeight: '700px', maxWidth: '500px'}}>
                                                        {data?.buttons?.map((elem, index)=>(
                                                            <AnimatePresence>
                                                                {page == (index) && (
                                                                    <motion.img
                                                                        initial={{
                                                                            opacity: 0, y: 60, scale: 0.95, 
                                                                        }}
                                                                        animate={{ opacity: 1, y:0, scale: 1 ,
                                                                            transition: {
                                                                                // delay: 1.5,
                                                                                duration: 0.8
                                                                            }
                                                                        }}
                                                                        // exit={{ opacity: 0, y: 60, scale: 0.95 ,
                                                                        //     transition: {
                                                                        //         delay: 0,
                                                                        //         duration: 0.8
                                                                        //     } 
                                                                        // }}
                                                                        src={elem?.image?.url}
                                                                    >
                                                                    </motion.img>
                                                                )}
                                                            </AnimatePresence>
                                                        ))}
                                                    </div>
                                                :
                                                <MobileAnimation 
                                                    markedFrames={markedFrame} 
                                                    // frameRangeChangedCallback={(newpage)=>{ page!=newpage && setpagewrapper(newpage)}}
                                                    // startFromFrame={startingFrame} 
                                                    lottie={data?.animation || {}} 
                                                    inView={
                                                        onScreen 
                                                        // && animationContainerAnimatedFlag ? true : false 
                                                    }
                                                    onLoad={()=>{}}
                                                    page={page}
                                                    // setpage={setpagewrapper}
                                                    setpage={()=>{}}
                                                    width={animWidth} 
                                                    height={animHeight}
                                                />
                                            }
                                </motion.div>

                            </motion.div>
                </Section>
                <Container>
                    { (state?.environment?.isWindowsDesktop==true && data?.settings?.dontUseFallback?.value!=='true') && deviceType == 'desktop' ?
                            <></>
                        :
                        <motion.div
                            className="mobile-swiper-wrapper"
                        >
                            <Swiper data={data && data.buttons || []} page={page} setpage={(page)=>{
                                handleCardSelect(page)
                            }}/>
                        </motion.div>
                    }
                </Container>
            </SectionWrapper>
        </>
    )

}

export default connect(SectionHowToUse)





// Start : Buttons component

const ButtonWrapper = styled.div`
    display: flex;
    justify-content: start;
    align-items: center;

    .button {
        cursor: pointer;
        margin-right: 12px;
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        padding: ${layout.reponsiveCssValue(18,26, 1440, 22, 1600, 26)} ${layout.reponsiveCssValue(28,36, 1440, 32, 1600, 36)};
        border-width: ${layout.reponsiveCssValue(1.5,2, 1440, 1.73558, 1600, 2)};
        border-color: rgba(255, 255, 255, 0.72);
        border-style: solid;
        border-radius:  ${layout.reponsiveCssValue(10, 12, 1440, 10.4, 1600, 12)};
        a {
            display: flex;
            flex-direction: row;
        }

        h1, h2, h3, h4, h5, h6 {
            // font-family: Roboto Slab;
            // font-style: normal;
            // line-height: 22px;
            // font-weight: 500;
            flex: 1;
            // margin-right: 2rem;
        }

        img {
            width: 6px;
        }

    }

    .button.dark {
        background: #00AB88;
        h1, h2, h3, h4, h5, h6 {
            color: #FFFFFF;
        }
    }

    .button.light {
        background: #ffffff;
        padding-top: ${layout.reponsiveCssValue(9,12, 1200, 9.4, 1600, 12)};
        padding-bottom: ${layout.reponsiveCssValue(9,12, 1200, 9.4, 1600, 12)};
        padding-left: ${layout.reponsiveCssValue(18,24, 1200, 18, 1600, 24)};
        padding-right: ${layout.reponsiveCssValue(18,24, 1200, 18, 1600, 24)};
        border-radius: ${layout.reponsiveCssValue(9,12, 1200, 9.4, 1600, 12)};
        border-width: 0px;

        a {
            color: #1D6F5E;
        }
        h1, h2, h3, h4, h5, h6 {
            color: #2F695D;
        }
    }


    .button.transparent {
        background: transparent;
        h1, h2, h3, h4, h5, h6 {
            color: #1D6F5E;
        }
    }


    .button.translucent {
        background: rgba(255, 255, 255, 0.4);
        box-sizing: border-box;
        backdrop-filter: blur(3.30935px);
        h1, h2, h3, h4, h5, h6 {
            color: #1D6F5E;
        }
        
    }

`;


const Button = ({type, title, link}) => {
    return (
        <ButtonWrapper>
            <motion.div 
                className={`button ${type}`}
                whileHover={{
                    scale: 1.05,
                    transition: { ease: 'anticipate', duration: 0.200 },
                }}
                whileTap={{ scale: 0.95 }}
            >
                <a href={`${link || 'javascript:void(0)'}`}>
                    <h6 className='h6'>{title}</h6>
                    {/* <img src={NavArrowRightIcon}/> */}
                </a>
            </motion.div>
        </ButtonWrapper>
    )
}

// End : Buttons component


const CardWrapper = styled.div`
    max-width: 100%;
    .card {
        background-color: rgba(255, 255, 255, 0.4);
        border: solid 2px rgba(255, 255, 255, 0.72);
        border-radius: 12px;

        box-sizing: border-box;
        color: rgb(47, 105, 93);
        cursor: pointer;
        display: flex;

        width:  ${layout.reponsiveCssValue(300, 550, 1440, 470, 1600, 550)};
        max-width: 100%;
        opacity: 0.72;
        padding: 16px;
        text-align: left;

        display: flex;
        flex: 1;
        flex-direction: row;
        // gap: 16px;

        .icon {
            display: flex;
            align-items: flex-start;
            justify-content: flex-start;

            .number-icon {
                width: 48px;
                height: 48px;
                border: solid 1px white;
                background: #ffffffdd;
                border-radius: 50%;
            
                display: flex;
                justify-content: center;
                align-items: center;
            
                h1,h2,h3,h4,h5,h6 {
                    color: #2F695D;
                    font-family: "Roboto";
                }
            }

        }
        
        .texts {
            display: flex;
            flex: 1;
            flex-direction: column;
            gap: 8px;
            padding: 0px 1.5rem 0px 0.5rem;
            h1,h2,h3,h4,h5,h6 {
                // color: #0E342C;
            }
            p {
                // color: #2F695D;
                padding-right: 2rem;
            }
        }
    }


    .card > div {
        &:not(:last-child) {
            margin-right: 16px; // flex->gap safari <14.1 fix
        }
    }

    .active {
        .icon {
            .number-icon {
                background: #00AB88;
                h1,h2,h3,h4,h5,h6 {
                    color: #FBFBFB;
                }
            }
        }
    }
`;

const Card = ({title, description, frameId, index, page, onClick}) => {
    const CardsAnimations = {
        hidden: { opacity: 0.2, scale: 0.9 },
        show: {
            opacity: 1,
            scale: 1,
            backgroundColor: 'rgba(255  255 255 0.4)',
            transition: {
                staggerChildren: 0.1,
                delayChildren: 0.3,
            },
        },
        showActive: {
            opacity: 1,
            scale: 1,
            boxShadow: 'rgba(20 20 22 .16) 0px 8px 24px',
            zIndex: 10,
            color: '#fff',
            backdropFilter: 'blur(4px)',
            backgroundColor: 'rgba(255  255 255 0.6)'
        }
    }

    const CardsNumberedIconAnimation = {
        active: {
            scale: 1.1,
            background: '#00AB88',
        },
        inactive: {
            background: '#ffffffdd',
        }
    }
    return (
        <CardWrapper>
            <motion.div
                onTap={(event) => {
                        event.preventDefault();
                        event.stopPropagation();
                        onClick();
                    }}
                whileHover={{
                    scale: 1.05,
                    boxShadow: 'rgba(20 20 22 .16) 0px 8px 24px',
                    zIndex: 20,
                    transition: { ease: 'anticipate', duration: 0.250 },
                    backdropFilter: 'blur(4px)',
                    opacity: 1,
                    }}
                whileTap={{ scale: 0.95 }}
                className={`card ${page==index && 'active'}`}
                variants={CardsAnimations}
                initial={'hidden'}
                animate={page==index ? 'showActive' : 'show'}
                transition={{ duration: 0.250, delay: 0.0 }}
            >
                <div className="icon"> 
                    <motion.div 
                        className="number-icon"
                        variants={CardsNumberedIconAnimation}
                        initial={'inactive'}
                        animate={page==index ? 'active' : 'inactive'}
                        transition={{ duration: 0.250, delay: 0.0 }}
                    >
                        <h5>{index+1}</h5>
                    </motion.div>
                </div>
                <div className="texts">
                    <h5 className='h5'>{title}</h5>
                    <p className='body3'>{description}</p>
                </div>

            </motion.div>
        </CardWrapper>

    )
}