Section #4: Testimonial
{
    topsection: {
        heading: ""
        description: ""
        images: [{<media>},{<media>}]
    }
    cards: {
        data: [{
            person: {
                image: <media>
                name: ""
                occupation: "
            }
            heading: ""
            description: ""
            cards: [{
                heading
                data: [{image: <media>, heading, description, link}]
            }]
        }]
    }
}



section #5: Getting Started
{
    Heading: 
    description
    cards: [
        {
            image:
            heading
            description
            buttons [{
                title:
                link:
                type: [light | primary | transparent]
            }]
            link
        }
    ]

}


section #6 Contact Us
{
    image: <media>
    heading:
    description:
    buttons [{
                title:
                link:
                type: [light | primary | transparent]
            }]
}


section #7 FAQ
{
    image: <media>
    heading:
    description:
    Cards [{
                title:
                description:
                link:
            }]
}