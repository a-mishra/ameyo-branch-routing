const assetHandler = {
  name: "assethandler",
  priority: 10,
  pattern: "^(wp-content)",
  func: async ({ link, route, params, state, libraries }) => {
    
    // const { post_id } = params;
    // Fetch the postmeta data from the endpoint
    // console.log({ link, route, params, state, libraries })
    const response = await libraries.source.api.get({
      endpoint: `/wp-content`,
    });

    // Parse the JSON to get the object
    const metaData = await response.json();

    // Add the meta to source.data
    const postmeta = state.source.data[link];

    Object.assign(postmeta, {
      // items: metaData,
      isAsset: true,
    });

    return postmeta;

  },
};

export default assetHandler;