import React, {  useRef, useEffect, useState, useLayoutEffect } from 'react'
import { connect, styled , Global, css} from 'frontity';
import {layout, SectionAnimation} from '../../../utils/constants';
import {useOnScreen, useWindowDimentions, useContainerDimensions, useType} from '../../../utils/hooks/usehooks'

import { Section, Row, Col, Container } from '../../misc/layout';
import { motion, useMotionValue, useAnimation, AnimatePresence, useSpring } from "framer-motion";

import PayuLogo from '../../../assets/images/payu-logo.svg'
import HamLogo from '../../../assets/images/ham.svg'
import SignupLogo from '../../../assets/images/Signup-new.png'
import LoginLogo from '../../../assets/images/Login-new.png'
import DropDownIcon from '../../../assets/icons/dropdown.svg'
import DropDownReversedIcon from '../../../assets/icons/dropdown_reversed.svg'
import CrossIcon from '../../../assets/icons/cross.svg'
import  {MobileMenu} from './mobile-menu'

const Wrapper = styled.div`
height: ${layout.constants.headerHeight};
// background: #F5F5F5;

a {
    font-family: inherit;
    font-style: inherit;
    font-weight: inherit;
    font-size: inherit;
    line-height: inherit;
    color: inherit;
    // display: inherit;
    // flex: inherit;
    // flex-direction: inherit;
}

.container {
    height: 100%;
    .inner-section {
        height: 100%;
        .menu-bar {
            height: 100%;
        }
    }
}

.menu-dropdown-container {
    position: absolute;
    top: ${layout.constants.headerHeight};
    left: 50%;
    transform: translateX(-50%);
    z-index: 10;

    // top: 72px;
    // left: -20%;
}


    // span styles;
    span {
        &.menu-bar-item {
            &.active {
                background: #ffffff;
            }
            transition: all 0.2s cubic-bezier(0.17, 0.12, 0.63, 0.66);
        }


    }

    .menu-bar {
        display: flex;
        flex-direction: row;
        align-items: center;

        .menu-bar-logo-wrapper {
            display: flex;
            align-items: center;
            justify-content: flex-start;

            .logo {
                width: ${layout.reponsiveCssValue(64, 71.36,1200, 68, 1600, 71.36)};
                ${layout.screen.mob} {
                    width: 55px;
                }
            }
            .mobile-menu-dropdown-wrapper {
                height: 100%;
                padding: 0px 12px;
                display: none;
                ${layout.screen.mob} {
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }
            }

        }

        .menu-bar-items-wrapper {
            display: flex;
            flex-direction: row;
            // gap: ${layout.reponsiveCssValue(0, 20, 1024, 0, 1440, 20)}; // flex->gap safari <14.1 fix

            justify-content: center;
            align-items: center;
            flex-grow: 1;
            height: 100%;

            position: absolute;
            transform: translate(-50%, -50%)!important;
            left: 50%;
            top: 50%;
            z-index: 100;
            
            ${layout.screen.mob} {
                display: none;
            }

            .menu-bar-item {
                height: 100%;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: default;
                padding: 0px ${layout.reponsiveCssValue(12, 20, 1200, 12, 1600, 20)};
                
                a {
                    cursor: pointer;
                }

                img {
                    margin-left: 4px;
                    height: auto;
                    width: 10px;
                }
            }



        }

        .menu-bar-items-wrapper > span {
            &:not(:last-child) {
                margin-right: ${layout.reponsiveCssValue(0, 20, 1024, 0, 1440, 20)}; // flex->gap safari <14.1 fix
            }
        }

        .menu-bar-actions-panel {
            display: flex;
            flex-direction: row;
            // gap: ${layout.reponsiveCssValue(20, 40, 1024, 20, 1440, 40)};
            // gap: ${layout.reponsiveCssValue(8, 28, 1024, 8, 1440, 28)}; // flex->gap safari <14.1 fix
            justify-content: flex-end;
            align-items: center;
            height: 100%;

            // position: absolute;
            // right: 0px;
            // padding-right: 1.5rem;

            flex-grow: 1;

            ${layout.screen.mob} {
                display: none;
            }

            .item {
                display: flex;
                flex-direction: row;
                // gap: 12px;
                justify-content: space-between;
                align-items: center;
                cursor: pointer;
                padding: 8px 12px;
                img {
                    width: 16px;
                    height: auto;
                    
                }
                span {
                }
                &.border {
                    border: 1.5px solid #2F695D;
                    box-sizing: border-box;
                    border-radius: 10px;
                }
            }
        }

        
            .menu-bar-actions-panel > a {
                &:not(:last-child) {
                    margin-right: ${layout.reponsiveCssValue(8, 28, 1024, 8, 1440, 28)}; // flex->gap safari <14.1 fix
                }
            }

            // .menu-bar-actions-panel > a > .item > * + * {
            //     &:not(:last-child) {
            //         margin-right: 12px; // flex->gap safari <14.1 fix
            //     }
            // }

            .menu-bar-actions-panel > a > .item > img {
                    margin-right: 12px; // flex->gap safari <14.1 fix
            }

        


        .menu-bar-actions-panel-mobile {
            display: flex;
            flex-direction: row;
            gap: ${layout.reponsiveCssValue(20, 40, 1024, 20, 1440, 40)};
            justify-content: flex-end;
            align-items: center;
            height: 100%;

            position: absolute;
            right: 0px;
            padding-right: 1.5rem;

            display: none;
            ${layout.screen.mob} {
                display: flex;
            }

            .item {
                display: flex;
                flex-direction: row;
                gap: 12px;
                justify-content: space-between;
                align-items: center;
                cursor: pointer;
                img {
                    width: 16px;
                    height: auto;
                    ${layout.screen.mob} {
                        width: 24px;
                    }
                }
                span {
                    // font-family: Open Sans;
                    // font-style: normal;
                    // font-weight: 600;
                    // font-size: 14px;
                    // line-height: 200%;
                    color: #96A5A2;
                }
            }
        }
    }


    .mobile-menu-container {
        width: 100vw;
        height: 100vh;
        background: #EAEFEC;
        z-index: 10;
        position: fixed;
        top: 0;
        left: 0;
        .container-component {
            ${layout.screen.xs} {
                padding: 0px;
                margin: 0px;
            }
        }
    }
`;

const rotateAnimation = {
    initial: { scale: 1 },
    active: {
        transform: 'rotate(180deg)'
    },
    transition: () => ({
        transform: { type: "spring",
          damping: 10,
          mass: 0.2,
          stiffness: 150
         }, 
        ease: 'anticipate',
        duration: 0.2,
        delay: 0
    })
}

const mobileMenuAnimation = {
    initial: { opacity: 0, transform: 'translateX(-100%)'},
    active: {
        transform: 'translateX(0%)', opacity: 1
    },
    transition: () => ({
        transform: { type: "spring",
          damping: 10,
          mass: 0.2,
          stiffness: 150
         }, 
        ease: 'anticipate',
        duration: 0.5,
        delay: 0
    })
}

const TestHeader = ({ state, data, actions, libraries}) => {

    const Html2React = libraries.html2react.Component;
    const [activeMenuIndex, setactiveMenuIndex] = useState(-1);
    const [isMobileMenuOpen, setisMobileMenuOpen] = useState(false);

    const ToggleMobileMenuOpen = () => {
        setisMobileMenuOpen(!isMobileMenuOpen);
    }

    // React.useEffect(()=>{
    //     console.log(`data in Header:`, data);
    // }, [])


    const selectedMenuData = data?.menu?.[activeMenuIndex]?.type?.data || {};
    const selectedMenuType = data?.menu?.[activeMenuIndex]?.type?.type?.value || 'link';


    const handleLink = (link) => {
        if(link) {
            window.href = link;
        }
    }


    return (
        <Wrapper>
            <Container className="container" padding={'level4'}>
                <div className="inner-section">
                    <div className='menu-bar'>
                        {
                            //website logo
                            <motion.div 
                            className="menu-bar-logo-wrapper"
                            // onTap={()=>handleLink(state?.frontity?.home)}
                            >
                                <a href={data?.settings?.url?.home}><img className="logo" src={PayuLogo}></img></a>
                                {/* <motion.div
                                    className="mobile-menu-dropdown-wrapper" 
                                    variants={rotateAnimation}
                                    initial={'initial'}
                                    animate={isMobileMenuOpen ? 'active' : 'initial'}
                                    transition={{
                                        ...rotateAnimation.transition()
                                    }}
                                    onTap={()=>{ToggleMobileMenuOpen()}}
                                >
                                    <img className="mobile-menu-dropdown" src={DropDownIcon}/>
                                </motion.div> */}
                            </motion.div>
                        }

                        <div className='menu-bar-items-wrapper'>
                            {
                                data?.menu?.map((elem, index)=>{
                                    return (
                                        <>
                                            <motion.span 
                                                className={`menu-bar-item ${activeMenuIndex==index && 'active'} small-text1`}
                                                whileHover={()=>{}}
                                                onHoverStart={()=>{
                                                    setactiveMenuIndex(index)
                                                }}
                                                onTap={()=>{
                                                    setactiveMenuIndex(index)
                                                }}
                                                onHoverEnd={()=>{
                                                    setactiveMenuIndex(-1)
                                                }}
                                            >
                                                <a href={elem?.type?.type?.value == 'link' &&  elem?.type?.data?.link || 'javascript:void(0)'}>
                                                    {elem.title}
                                                </a>
                                                {elem?.type?.type?.value == 'link' ? <></> :( activeMenuIndex==index ? <img src={DropDownReversedIcon}/> : <img src={DropDownIcon}/> ) }
                                            </motion.span>
                                            {
                                                activeMenuIndex==index && elem?.type?.type?.value != 'link' &&
                                                <motion.div
                                                    className={"menu-dropdown-container"}
                                                    onHoverStart={()=>{
                                                        setactiveMenuIndex(index)
                                                    }}
                                                    onTap={()=>{
                                                        setactiveMenuIndex(index)
                                                    }}
                                                    onHoverEnd={()=>{
                                                        setactiveMenuIndex(-1)
                                                    }}
                                                    style={index == 0 ? {width: '1041px'} : {width: 'auto'} }
                                                >
                                                    <MenuDropdownComponent isFirefox={state?.environment?.isFirefox} data={elem?.type?.data || {}} type={elem?.type?.type?.value || 'link'} width={index == 0 ? 'fit-content' : 'fit-content'} />
                                                </motion.div>
                                                
                                            }
                                        </>
                                        
                                    )
                                })
                            }
                        </div>

                        {
                            // login & signup
                        }
                            <div className='menu-bar-actions-panel'>
                            <a href={data?.settings?.url?.login}><div className='item small-text1'>
                                    <img src={LoginLogo}></img><span>Login</span>
                                </div></a>
                                <a href={data?.settings?.url?.signup}><div className='border item small-text1'>
                                    <img src={SignupLogo}></img><span>Sign up</span>
                                </div></a>
                            </div>
                            <div className='menu-bar-actions-panel-mobile'>
                                <div className='item small-text1'>
                                {/* <img src={HamLogo}></img> */}
                                <motion.div
                                    variants={rotateAnimation}
                                    initial={'initial'}
                                    animate={isMobileMenuOpen ? 'active' : 'initial'}
                                    transition={{
                                        ...rotateAnimation.transition()
                                    }}
                                    onTap={()=>{ToggleMobileMenuOpen()}}
                                >
                                    <img src={HamLogo}/>
                                </motion.div>
                                </div>
                            </div>
                    </div>
                </div>
            </Container>

            <motion.div
                className="mobile-menu-container"
                variants={mobileMenuAnimation}
                initial={'initial'}
                animate={isMobileMenuOpen ? 'active' : 'initial'}
                transition={{
                    ...mobileMenuAnimation.transition()
                }}
                // onTap={()=>{ToggleMobileMenuOpen()}}
            >
                <Container padding={'level4'} className="container-component">
                    <MobileMenu frontity={state?.frontity} data={data} closeMenu={ToggleMobileMenuOpen} isMobileMenuOpen={isMobileMenuOpen}/>
                </Container>
            </motion.div>
            
        </Wrapper>
    )
}

export default connect(TestHeader)



const MenuDropdownComponent = ({data, type, width, isFirefox}) => {
    const [selectedMenuItem, setselectedMenuItem] = useState(0)

    const level2Data = data?.menuItems?.[selectedMenuItem]?.level1 || [];
    const level2Heading = data?.menuItems?.[selectedMenuItem]?.level1Heading;
    const getMoreData = data?.menuItems?.[selectedMenuItem]?.getMore;

    //type == 'singleLevel'


    return (
        <MenuDropDownWrapper width={width} isFirefox={isFirefox}>
            {type == 'twoLevel' && 
                <>
                    <div className="level-1">
                        {data?.menuItems?.map((elem, index)=>(
                            <motion.div 
                                className={`menu-item ${selectedMenuItem == index && 'active'}`}
                                onHoverStart={()=>{setselectedMenuItem(index)}}
                                onTap={()=>{setselectedMenuItem(index)}}
                                style={index == 0 ? {borderRadius: '28px 0px 0px 0px'} : ( index == (data.menuItems.length -1) ? {borderRadius: '0px 0px 0px 28px'} : {})}
                            >
                                <span className={`icon ${elem?.level0?.description ? '' : 'paraless'}`}></span>
                                <div className="text-container">
                                    <span className="heading nav-text-1">{elem?.level0?.title}</span>
                                    <span className="description nav-text-3">{elem?.level0?.description}</span>
                                </div>
                            </motion.div>
                        ))}
                    </div>
                    <div className='level-2'>
                            {level2Heading && <h5 className={'level-2-heading h7'}>{level2Heading}</h5>}
                            {
                                level2Data.map((elem, index)=>(
                                    <div className={`level-2-item ${index && 'border-top'}`}>
                                        <a href={elem?.link || 'javascript:void(0)'}>
                                            <div className="text-container">
                                                <span className="heading nav-text-2">{elem?.title}</span>
                                                <span className="description nav-text-4">{elem?.description}</span>
                                            </div>
                                        </a>
                                    </div>
                                ))
                            }
                    </div>
                    {getMoreData && (getMoreData?.heading || (getMoreData?.links?.length > 0)) &&
                        <div className="get-more-container-wrapper">
                            <div className="get-more-container">
                                {getMoreData?.heading && <h4 className={'heading h5'}>{getMoreData?.heading}</h4>}
                                
                                <div className="links">
                                    {
                                        getMoreData?.links?.map((elem, index)=>(
                                            <div className={`item`}>
                                                <a href={elem?.link || 'javascript:void(0)'}>
                                                    <div className="text-container">
                                                        <span className="heading nav-text-2">{elem?.title}</span>
                                                        <span className="description nav-text-4">{elem?.description}</span>
                                                    </div>
                                                </a>
                                            </div>
                                        ))
                                    }
                                </div>
                                
                            </div>
                        </div>
                    }
                </>
            }

            {type == 'singleLevel' && 
                <>
                    <div className='level-2'>
                            {data.heading && <h5 className={'level-2-heading h7'}>{data.heading}</h5>}
                            {
                                data?.menuItems?.map((elem, index)=>(
                                    <div className={`level-2-item ${index && 'border-top'}`}>
                                        <a href={elem?.link || 'javascript:void(0)'}>
                                            <div className="text-container">
                                                <span className="heading nav-text-2">{elem?.title}</span>
                                                <span className="description nav-text-4">{elem?.description}</span>
                                            </div>
                                        </a>
                                    </div>
                                ))
                            }
                    </div>
                    {data?.getMore &&
                        <div className="get-more-container-wrapper">
                            <div className="get-more-container">
                                {data?.getMore?.heading && <h4 className={'heading h5'}>{data?.getMore?.heading}</h4>}
                                
                                <div className="links">
                                    {
                                        data?.getMore?.links?.map((elem, index)=>(
                                            <div className={`item`}>
                                                <a href={elem?.link || 'javascript:void(0)'}>
                                                    <div className="text-container">
                                                        <span className="heading nav-text-2">{elem?.title}</span>
                                                        <span className="description nav-text-4">{elem?.description}</span>
                                                    </div>
                                                </a>
                                            </div>
                                        ))
                                    }
                                </div>
                                
                            </div>
                        </div>
                    }
                </>
            }
        </MenuDropDownWrapper>
    )
}

const MenuDropDownWrapper = styled.div`

    border-radius: 28px;
    display: flex;
    flex-direction: row;
    overflow: hidden;
    transition: all 0.2s cubic-bezier(0.17, 0.12, 0.63, 0.66);
    width: ${(props)=>props.width};
    .level-1 {

        border: 2px solid rgba(255, 255, 255, 0.72);
        border-right-width: 0px;
        box-sizing: border-box;

        background-color: rgba(248, 252, 248, 1);          

        border-radius: 28px 0px 0px 28px;
        cursor: default;
        width: 350px;

        

        transition: all 0.2s cubic-bezier(0.17, 0.12, 0.63, 0.66);
        .menu-item {
            display: flex;
            flex-direction: row;
            transition: all 0.2s cubic-bezier(0.17, 0.12, 0.63, 0.66);
            .icon {
                width: 29px;
                height: 29px;
                border-radius: 50%;
                background: #96A5A2;

                margin-top: 36px;
                &.paraless {
                    margin-top: 24px;
                }
                margin-left: 40px;
            }

            .text-container {
                display: flex;
                flex-direction: column;
                margin: 24px;
                margin-left: 21px;
                margin-bottom: 15px;
                gap: 4px;
                cursor: default;
                
                .heading {
                    color: #2F695D;
                }
                .description {
                    color: #96A5A2;
                }
            }

            &.active {
                background: #FFFFFF;
                .text-container {
                    .heading {
                        color: #00AB88;
                    }
                    .description {
                        color: #2F695D;
                    }
                }
            }
        }
        
    }

    .level-2 {
        background: #FFFFFF;
        width: 367px;
        padding: 36px 47px;
        transition: all 0.2s cubic-bezier(0.17, 0.12, 0.63, 0.66);

        .level-2-heading {
            margin-bottom: 10px;
        }

        .level-2-item {
            padding: 20px 0px;

            &.border-top {
                border-top: 1px solid #BFDFBA;
            }

            .text-container {
                display: flex;
                flex-direction: column;
                gap: 2px;
                
                .heading {
                    // font-family: Roboto;
                    // font-style: normal;
                    // font-weight: 500;
                    // font-size: 14px;
                    // line-height: 171%;
                    // letter-spacing: 1px;
                    color: #0E342C;
                }
                .description {
                    // font-family: Roboto;
                    // font-style: normal;
                    // font-weight: 500;
                    // font-size: 12px;
                    // line-height: 167%;
                    // letter-spacing: 1px;
                    color: #2F695D;
                    
                }
            }
        }
        
    }
    .get-more-container-wrapper {
        background: #ffffff;
        padding: 27px 41px 40px 27px;
    }
    .get-more-container {
        // background: linear-gradient(349.06deg, #1268B3 -76.74%, rgba(255, 255, 255, 0) 91.9%), #CFE4BF;
        background: linear-gradient(349.06deg, #1268B3 -100%, rgba(255, 255, 255, 0) 50%), #CFE4BF;
        backdrop-filter: blur(200px);
        border-radius: 20px;

        height: 100%;
        width: 256px;

        padding: 23px;
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        justify-content: flex-end;

        .heading {
            margin-bottom: 16px;
        }

        .links {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            justify-content: flex-end;
            // gap: 20px; // flex->gap safari <14.1 fix
        }

        .links > div {
            &:not(:last-child) {
                margin-bottom: 20px; // flex->gap safari <14.1 fix
            }
        }

        .item {

            &.border-top {
                border-top: 1px solid #BFDFBA;
            }

            .text-container {
                display: flex;
                flex-direction: column;
                gap: 2px;
                
                .heading {
                    margin: 0px;
                    padding: 0px;
                    // font-family: Roboto;
                    // font-style: normal;
                    // font-weight: 500;
                    // font-size: 14px;
                    // line-height: 171%;
                    // letter-spacing: 1px;
                    color: #0E342C;
                }
                .description {
                    // font-family: Roboto;
                    // font-style: normal;
                    // font-weight: 500;
                    // font-size: 12px;
                    // line-height: 167%;
                    // letter-spacing: 1px;
                    color: #2F695D;
                    
                }
            }
        }

    }
`;

