
import React, {  useRef, useEffect, useState, useLayoutEffect } from 'react'
import { connect, styled , Global, css} from 'frontity';
import {layout, SectionAnimation} from '../../../utils/constants';
import {useOnScreen, useWindowDimentions, useContainerDimensions} from '../../../utils/hooks/usehooks'
import { Section, Row, Col, Container } from '../../misc/layout';
import { motion, useMotionValue, useAnimation, AnimatePresence } from "framer-motion";
import Animation from './mobile-animation';

const Wrapper = styled.div`
    max-width: 480px;
    margin: 0 auto;
    visibility: hidden;
    display: none;
    ${layout.screen.mob} {
        visibility: visible;
        display: block;
    }


    .animation-container-mobile {

        display: flex;
        justify-content: center;
        align-items: center;
        width: 100%;
        
        .animation-wrapper {
            position: relative;
            width: 100%;
            // aspect-ratio: 640/800;
            height: ${(props)=>(props.animHeight)}px;

            // top:0;
            // bottom: 0;
            // left: 0;
            // right: 0;

            // place-items: center;
            // display: flex;
            overflow: visible;
            .xyz {
                position: absolute;
                top:0;
                bottom: 0;
                left: 0;
                right: 0;
                display: flex;
                justify-content: flex-end;
                align-items: flex-end;
                place-content: center;
            }
        }
    }

`;

const MobileAnimationContainer = ({viewed, data, onScreen, page, animWidth, animHeight}) => {
    return (
        <Wrapper animHeight={animHeight}>
            <motion.div className="animation-container-mobile"
                variants={SectionAnimation}
                initial={'hidden'}
                animate={viewed ? 'show' : 'hidden'}
                transition={{ 
                    ...SectionAnimation.transition(2)
                }}
            >
                <motion.div className="animation-wrapper">
                        {data?.buttons?.map((elem, index)=>(
                            <div className="xyz">
                            <AnimatePresence>
                                {page == (index) && (
                                    <motion.div
                                        initial={{
                                            opacity: 0, y: 60, scale: 0.95, 
                                        }}
                                        animate={{ opacity: 1, y:0, scale: 1 ,
                                            transition: {
                                                delay: 0.7,
                                                duration: 0.8
                                            }
                                        }}
                                        exit={{ opacity: 0, y: 60, scale: 0.95 ,
                                            transition: {
                                                delay: 0,
                                                duration: 0.8
                                            } 
                                        }}
                                    >
                                        <Animation 
                                            {...elem}
                                            lottie={elem?.media?.data?.animation}
                                            animationText={elem?.media?.data}
                                            inView={onScreen}
                                            onLoad={()=>{}}
                                            width={animWidth || 'auto' }
                                            height={animHeight || 'auto'}
                                        />
                                    </motion.div>
                                )}
                            </AnimatePresence>
                            </div>
                        ))}

                </motion.div>
                
            </motion.div>
        </Wrapper>
    )
}

export default MobileAnimationContainer;
