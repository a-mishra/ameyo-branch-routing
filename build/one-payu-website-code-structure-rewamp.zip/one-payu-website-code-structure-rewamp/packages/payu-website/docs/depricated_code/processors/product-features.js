import React from 'react'
import SectionProductFeatures from '../components/sections/product-features/index'

/*
{"id":"","heading":"Your access point to <span style=\"color:#52d072\" class=\"has-inline-color\">limitless business growth</span>","subheading":"We’re more than a payments partner - we enable all-round business growth. With us, expect smoother payment processes and an outstanding user experience for your customers.","cards":{"data":[{"title":"Payments technology with a heart","animationTextHeading":"Payments technology with a heart","animationTextSubHeading":"Get robust yet accessible technology innovation that understands your specific needs and helps you manage your money at every step simply, securely & efficiently.","lottie":{"settings":{"loopStartFrame":"50"},"media":{"id":143,"url":"http://localhost:8000/wp-content/uploads/2021/10/checkout_ux_2.json","name":"checkout_ux_2"}}}],"settings":{}}}
*/

import { Section } from '../components/misc/layout';


const ComponentWrapper = ({data}) => {


    return (
        // <SectionProductFeatures data={data} />
        <Section>
            {`Plugin 'Product features' is depricated, please redefine this block from opwsections -> productFeatures!!!`}
        </Section>
    )
};

const productfeatures = {
    name: 'productfeatures',
    priority: 20,
    test: ({ component, props }) => component === "div" && props.className.split(' ').includes("wp-block-cgb-block-product-features"),
    processor: ({ node,props }) => {

        let data = JSON.parse(node.children[0].children[0].content || '{}'); 
        if(data.cards) {
            data.cards = JSON.parse(data.cards);
        }

        return {
          component: ComponentWrapper,
          props: {data},
        }
      },
}

export default productfeatures;