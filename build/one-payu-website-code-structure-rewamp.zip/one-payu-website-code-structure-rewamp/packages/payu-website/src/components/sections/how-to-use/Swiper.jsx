import * as React from "react";
import { useRef, useEffect, useState } from "react";
import { motion, useMotionValue, useAnimation } from "framer-motion";
// import { clamp, snap } from "@popmotion/popcorn";
import { InView } from "react-intersection-observer";
import {styled} from 'frontity'
import {layout} from '../../../utils/constants';
import { Container } from '../../misc/layout';

import NavArrowLeftIcon from '../../../assets/icons/nav_arrow_left.svg'
import NavArrowRightIcon from '../../../assets/icons/nav_arrow_right.svg'
import { useWindowDimentions } from "../../../utils/hooks/usehooks";



function useContainerConstraints(ref, markerOffset) {
  const [constraints, setConstraints] = useState({
    top: 0,
    bottom: 0,
    left: 0,
    right: 0
  });

  const setData = () => {
    const element = ref.current;
    const viewportHeight = element.offsetHeight;
    const contentHeight = element.firstChild.offsetHeight;
    const viewportWidth = element.offsetWidth;
    const contentWidth = element.firstChild.offsetWidth;

    setConstraints({
      top: viewportHeight - contentHeight,
      bottom: 0,
      left: viewportWidth - contentWidth,
      right: 0
    });
  }

  useEffect(() => {
    setData();
    window.addEventListener("resize", setData)
    window.addEventListener("orientationchange", setData)
    return () => {
      window.removeEventListener("resize", setData)
      window.addEventListener("orientationchange", setData)
    }
  }, []);

  return constraints;
}

export const Swiper = ({data, page, setpage}) => {
  const x = useMotionValue(0);
  let animControls = useAnimation();
  // const [page, setpage] = useState(0);

  const [markerOffset, setmarkerOffset] = useState(["pixel", 38]);
  const [itemsMargin, setitemsMargin] = useState(18);
  const [swipeConfidenceThreshold, setswipeConfidenceThreshold] = useState(100);

  const containerRef = useRef(null);
  const { top, bottom, left, right } = useContainerConstraints(containerRef, markerOffset);

  const scrollRef = useRef(null);

  const scrollToPage = (newpage) => {
    const element = containerRef.current;
    const containerWidth = element.offsetWidth;

    const boundingBox = element.getBoundingClientRect();
    const markerLeft =
      boundingBox.left +
      (markerOffset[0] == "pixel"
        ? markerOffset[1]
        : markerOffset[1] * containerWidth);
    const markerRight =
      boundingBox.right -
      (markerOffset[0] == "pixel"
        ? markerOffset[1]
        : markerOffset[1] * containerWidth);
    const markerHorizontalCenter = boundingBox.left + 0.5 * containerWidth;

    const scrollElem = scrollRef.current;
    let scrollOffset = 0;

    // let traslation_x_Value =
    //   (scrollElem?.children?.[newpage]?.getBoundingClientRect()?.left || 0) - markerLeft + scrollOffset ;

    let traslation_x_Value =
      (scrollElem?.children?.[newpage]?.getBoundingClientRect()?.left || 0) + ((scrollElem?.children?.[newpage]?.getBoundingClientRect()?.width || 0)/2) - markerHorizontalCenter + scrollOffset ;


      if (newpage >=0 && newpage < data.length) {
        setpage(newpage);
        translateX(
          traslation_x_Value ,
          1
        );
      }

  };


  

  function handleWheel_X(event) {
    // event.preventDefault();

    // uncomment to allow scroll
    //------------------------------------------
    // const newX = x.get() - event.deltaX;
    // const clampedX = clamp(left, right, newX);
    // x.stop();
    // x.set(clampedX);
  }

  const translateX = (delta, direction) => {
    const newX = x.get() - delta * direction;
    // const clampedX = clamp(left, right, snapTo(newX) + 32);
    // const clampedX = snapTo(newX) + itemsMargin;
    const clampedX = newX;
    x.stop();
    x.start(function () {
      animControls.start({ x: clampedX, transition: { duration: 0.5 } });
    });
    // x.set(clampedX);
  };

  const swipePower = (offset, velocity) => {
    return Math.abs(offset) * velocity;
  };

  const paginate = (newDirection) => {
    scrollToPage(page + newDirection);
  };

  const initialSetup = () => {
     scrollToPage(page || 0);
  }

  useEffect(() => {
    initialSetup();
    window.addEventListener("resize", initialSetup)
    window.addEventListener("orientationchange", initialSetup)
    
    return () => {
      window.removeEventListener("resize", initialSetup)
      window.removeEventListener("orientationchange", initialSetup)
    }
  }, []);

  useEffect(() => {
    scrollToPage(page||0)
  }, [page])

  return (
    <Wrapper itemsMargin={itemsMargin}>
      <div className="swiper-container" ref={containerRef} onWheel={handleWheel_X}>
        <motion.div
          drag="x"
          dragConstraints={{ top, bottom, left, right }}
          className="scrollable"
          style={{ x }}
          animate={animControls}
          ref={scrollRef}
          dragElastic={1}
          onDragEnd={(e, { offset, velocity }) => {
            const swipe = swipePower(offset.x, velocity.x);
            if (swipe < -swipeConfidenceThreshold) {
              paginate(1);
            } else if (swipe > swipeConfidenceThreshold) {
              paginate(-1);
            }
          }}
          dragMomentum={false}
          transition={{
            x: { type: "spring", stiffness: 300, damping: 10 }
          }}
        >
          {data && data.map((elem, index) => (
            <InView threshold={0.1} triggerOnce={true}>
              {({ ref, inView, entry }) => {
                return (
                  <motion.div
                    onTap={(event) => {
                      event.stopPropagation()
                      scrollToPage(index);
                    }}
                    className={`swiper-card ${page == index && "active"}`}
                    ref={ref}
                    initial={{ opacity: 0 }}
                    animate={
                      inView
                        ? page == index
                          ? {
                              opacity: 1,
                              margin: `0px ${itemsMargin/2}px`,
                              // boxShadow: 'rgba(20 20 22 .16) 0px 50px 50px',
                              zIndex: 10
                            }
                          : { 
                              opacity: 1, 
                              margin: `0px ${itemsMargin/2}px`,
                            }
                        : { opacity: 0.6 }
                    }
                    transition={{ duration: 0.5, delay: 0.0 }}
                  >
                    {/* // cards content goes here */}
                        <Card 
                        {...elem} 
                        page={page} 
                        index={index} 
                        onClick={()=>{setpage(index)}}
                        isLarge={false}
                        setTimerRunning={()=>{}}
                        />
                  </motion.div>
                );
              }}
            </InView>
          ))}
        </motion.div>
      </div>

    </Wrapper>
  );
};


const Wrapper = styled.div`

  visibility: hidden;
  display: none;
  ${layout.screen.mob} {
      visibility: visible;
      display: block;
  }
  
  .swiper-container {
    overflow: hidden;
    display: flex;
    flex-direction: row;
    // max-width: 960px;
    margin: 0px auto;
  }
  
  .scrollable {
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    padding-bottom: 32px;
    height: 100%;
  }
  
  .swiper-card {
    display: flex;
    border-radius: 28px;
    margin:0px ${(props)=>(props.itemsMargin/2)}px;
    position: relative;
    background: transparent;

  }
  

  .active {

  }
    
}
`;





const CardWrapper = styled.div`
    display: flex;
    flex-grow: 1;
    background: transparent;
    
    .card {
        width: ${layout.reponsiveCssValue(248, 442, 375, 300, 993, 440)}
        background-color: rgba(255, 255, 255, 0.4);
        border: solid 2px rgba(255, 255, 255, 0.72);
        border-radius: ${layout.reponsiveCssValue(28, 16, 375, 28, 1400, 16)};
        box-sizing: border-box;
        cursor: pointer;
        opacity: 0.72;
        padding-left: ${layout.reponsiveCssValue(12, 20, 1440, 16, 1600, 20)};
        padding-right: ${layout.reponsiveCssValue(12, 20, 1440, 16, 1600, 20)};
        padding-top: ${layout.reponsiveCssValue(10, 15, 1440, 12, 1600, 15)};
        padding-bottom: ${layout.reponsiveCssValue(10, 15, 1440, 12, 1600, 15)};
        ${layout.screen.mob} {
          padding-top: ${layout.reponsiveCssValue(22, 30, 375, 22, 993, 30)};
          padding-right: ${layout.reponsiveCssValue(16, 24, 375, 16, 993, 24)};
          padding-bottom: ${layout.reponsiveCssValue(16, 24, 375, 16, 993, 24)};
          padding-left: ${layout.reponsiveCssValue(16, 24, 375, 16, 993, 24)};
        }
        display: flex;
        flex-direction: row;
        align-items: flex-start;
        flex-grow: 1;
        gap: 12px;

        &:.active {
          background-color: rgba(255, 255, 255, 0.6);
        }

        .icon {
            width: ${layout.reponsiveCssValue(48, 66, 1440, 55, 1600, 66)};
            height: ${layout.reponsiveCssValue(48, 66, 1440, 55, 1600, 66)};
            ${layout.screen.mob} {
              width: ${layout.reponsiveCssValue(30, 48, 375, 30, 993, 48)};
              height: ${layout.reponsiveCssValue(30, 48, 375, 30, 993, 48)};
            
            }
            // border: solid 1px white;
            background: #ffffff;
            border-radius: 50%;
        
            display: flex;
            justify-content: center;
            align-items: center;

            img {
                width: ${layout.reponsiveCssValue(28, 42, 1440, 34, 1600, 42)};
                ${layout.screen.mob} {
                  width: 32px;
                }
            }

            .number-icon {
              width: ${layout.reponsiveCssValue(30, 48, 375, 30, 993, 48)};
              height: ${layout.reponsiveCssValue(30, 48, 375, 30, 993, 48)};
              // border: solid 1px white;
              background: #ffffff;
              border-radius: 50%;
          
              display: flex;
              justify-content: center;
              align-items: center;
          
              h1,h2,h3,h4,h5,h6 {
                  color: #2F695D;
                  font-family: "Roboto";
              }
          }
        }
        
        .card-texts {
            display: flex;
            flex: 1;
            flex-direction: column;
            align-items: flex-start;
            justify-content: flex-start;
            h1,h2,h3,h4,h5,h6 {
                font-family: "Roboto Slab";
                font-size: ${layout.reponsiveCssValue(12, 16, 1440, 13, 1600, 16)};
                ${layout.screen.mob} {
                  font-size: 16px;
                }
                color: #0E342C;
            }
            p {
              margin-top: ${layout.reponsiveCssValue(10, 12, 375, 10, 993, 12)};
              color: #2F695D;
              font-size: 13px
            }
            opacity: 0.72;
            &:hover {
                opacity: 1;
            }
            transition: opacity 0.2s ease-in;
        }
    }

    .active {
        .card-texts {
            opacity: 1;
        }
        
        .icon {
          .number-icon {
              background: #00AB88;
              h1,h2,h3,h4,h5,h6 {
                  color: #FBFBFB;
              }
          }
      }
    }

`;

const Card = ({title, description, index, page, onClick, setTimerRunning}) => {
    const CardsAnimations = {
        hidden: { opacity: 0.2, scale: 0.9 },
        show: {
            opacity: 0.72,
            scale: 1,
            border: '2px solid #FFFFFF',
            transition: {
                staggerChildren: 0.1,
                delayChildren: 0.3,
            },
        },
        showActive: {
            opacity: 1,
            scale: 1,
            boxShadow: 'rgba(20 20 22 .16) 0px 8px 24px',
            zIndex: 10,
            // color: '#fff',
            backdropFilter: 'blur(4px)',
            backgroundColor: '#ffffff99',
            borderColor: '#ffffffb8',
        }
    }

    const CardsNumberedIconAnimation = {
        active: {
            scale: 1.1,
            background: '#00AB88',
        },
        inactive: {
            background: '#ffffffdd',
        }
    }
    return (
        <CardWrapper>
            <motion.div
                onTap={(event) => {
                        event.preventDefault();
                        event.stopPropagation()
                        onClick();
                    }}
                whileHover={{
                    // scale: 1.05,
                    // boxShadow: 'rgba(20 20 22 .16) 0px 8px 24px',
                    // zIndex: 20,
                    // transition: { ease: 'anticipate', duration: 0.250 },
                    // backdropFilter: 'blur(4px)',
                    // opacity: 1,
                    }}
                whileTap={{ scale: 0.95 }}
                className={`card ${page==index && 'active'}`}
                variants={CardsAnimations}
                initial={'hidden'}
                animate={page==index ? 'showActive' : 'show'}
                transition={{ duration: 0.250, delay: 0.0 }}
            >
                <div className="icon"> 
                    <motion.div 
                        className="number-icon"
                        variants={CardsNumberedIconAnimation}
                        initial={'inactive'}
                        animate={page==index ? 'active' : 'inactive'}
                        transition={{ duration: 0.250, delay: 0.0 }}
                    >
                        <h5>{index+1}</h5>
                    </motion.div>
                </div>
                <div className="card-texts">
                    <h5>{title}</h5>
                    <p>{description}</p>
                </div>

            </motion.div>
        </CardWrapper>

    )
}