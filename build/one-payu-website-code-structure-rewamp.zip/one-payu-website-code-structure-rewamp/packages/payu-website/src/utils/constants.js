export const colors = {
    primary:'#3aae97',
    primary_shade1:'#eefbf6', 
    primary_shade2: '#3aae97', 
    secondary:'#040404',
    secondary_shade1:'#727781',
    secondary_shade2:'#000000',

    bg: '#eef1ef',
    text2: '#314235',
    text3: '#2F695D',

    white: '#ffffff',
    black: '#000000',
    base: '#141416',
    base_light: '#727781',
    grey_color : '#080808',
    grey_color1 : '#f5f5f5',
    grey_color2 : '#454545',  
    grey_color3 : '#dfdfdf',
    grey_color4 : '#868686', 
    grey_color5: '#040404',
  }

export const homeConfig = {
    "page":{ 
      "slug":"/"
    },
    "menu":{ 
      "name":"home"
    }
  };

 export const container_max_width = {
    xs: "0",
    sm: "600",
    md: "960",
    lg: "1100",
    lg2: "1200",
    xl: "1300",
    xxl: "1550"
}

export const layout = {
    breakpoints : {
      b0: "440",
      b1: "568", 
      b2: "767", 
      b3: "992",
      b4: "1024",
      b5: "1200",

      xs: "0",
      sm: "540", //above 540 sm screen
      md: "992",
      lg: "1200",
      lg2: "1300",
      xl: "1440",
      xxl: "1600",
    },
    get screen() {
      return {
        // md: `@media only screen and (max-width: ${this.breakpoints.b3}px) and (min-width: ${String(Number(this.breakpoints.b0 ) + 1)}px)`,
        //  xxl: `@media only screen and  (min-width: ${String(Number(this.breakpoints.b5 ) + 1)}px)`,

        // X-Small devices (portrait phones, less than 576px)
        xs: `@media only screen and (max-width: ${this.breakpoints.sm}px)`,

        // Small devices (landscape phones, 576px and up)
        sm: `@media only screen and (min-width: ${this.breakpoints.sm}px)`,

        // Medium devices (tablets, 768px and up)
        md: `@media only screen and (min-width: ${this.breakpoints.md}px)`,

        // Large devices (desktops, 992px and up)
        lg: `@media only screen and (min-width: ${this.breakpoints.lg}px)`,

        lg2: `@media only screen and (min-width: ${this.breakpoints.lg2}px)`,

        // X-Large devices (large desktops, 1400px and up)
        xl: `@media only screen and (min-width: ${this.breakpoints.xl}px)`,
        
        // XX-Large devices (larger desktops, 1600px and up)
        xxl: `@media only screen and (min-width: ${this.breakpoints.xxl}px)`,


        // Mobile devices ( less than 992px)
        mob: `@media only screen and (max-width: ${this.breakpoints.md}px)`,



        // X-Small devices (portrait phones, less than 576px)
        only_xs: `@media only screen and (max-width: ${this.breakpoints.sm}px)`,

        // Small devices (landscape phones, 576px and up)
        only_sm: `@media only screen and (min-width: ${this.breakpoints.sm}px) and (max-width: ${this.breakpoints.md}px) `,

        // Medium devices (tablets, 768px and up)
        only_md: `@media only screen and (min-width: ${this.breakpoints.md}px) and (max-width: ${this.breakpoints.lg}px)`,

        // Large devices (desktops, 992px and up)
        only_lg: `@media only screen and (min-width: ${this.breakpoints.lg}px) and (max-width: ${this.breakpoints.xl}px)`,

        // X-Large devices (large desktops, 1200px and up)
        only_xl: `@media only screen and (min-width: ${this.breakpoints.xl}px) and (max-width: ${this.breakpoints.xxl}px)`,
        
        // XX-Large devices (larger desktops, 1400px and up)
        only_xxl: `@media only screen and (min-width: ${this.breakpoints.xxl}px)`,
      }
    },
    constants: {
      headerHeight: '81px',
      // margin: {
      //   level0: "0rem",
      //   level1: "1.5rem",
      //   level2: "3rem",
      //   level3: "5rem"
      // },
      padding: {
          level0: "0rem",
          level1: "1.5rem",
          level2: "3rem",
          level3: "5rem",
          level4: "7rem"
      },
      mobile_padding: {
            level0: "0rem",
            level1: "1.5rem",
            level2: "1.6rem",
            level3: "1.6rem",
            level4: "1.6rem"
      },
      width: {
        level0: "100%",
        level1: "98%",
        level2: "95%",
        level3: "90%",
        level4: "86%"
      },
      debug: true
    },
    
    reponsiveCssValue: (min, max, projection_start, projection_start_value, projection_end, projection_end_value, comparator = null) => {
      return `calc(  min( max(calc( ${projection_start_value}px + (${projection_end_value} - ${projection_start_value}) * (( ${comparator || '100vw'} - ${projection_start}px) / (${projection_end} - ${projection_start})) ) , ${min}px), ${max}px  ) );`
    }
  }


  export const constants = {
    links: {
      payu: {
        twitter: "https://twitter.com/PayUindia",
        youtube: "https://www.youtube.com/c/payuindia",
        github: "https://github.com/payu-india",
        payu: "https://payu.in"
      }
    },
  }

  export const SectionAnimation = {
    hidden: { opacity: 0, scale: 0.95, y: -60 },
    show: {
        opacity: 1.1,
        scale: 1,
        y: 0
    },
    transition: (n, longDelay=false) => ({
        // y: { type: "spring",
        //   damping: 10,
        //   mass: 0.2,
        //   stiffness: 150
        //  }, 
        ease: 'anticipate',
        duration: longDelay ? 0.8 : 0.5, 
        delay: (longDelay ? 0.8 : 0.5)*(n) - 0.1*n, 
    })
}