import React from 'react'
import AnimatedNavbar from './AnimatedNavbar'
import { Global, css } from 'frontity'
import NavBarCss from './index.css'

const Menu = () => {

    return (
        <>
            <Global styles={css(NavBarCss)}/>
            {/* <ul class="nv-main d-flex">
                <li class="nav-item dropdown"><a href="#">Products <span class="down-arrow">
                    <svg width="10" height="7" viewBox="0 0 10 7" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M0.212903 0.88907C-0.0709677 1.15523 -0.0709677 1.58732 0.212903 1.85347L4.49677 5.94438C4.77204 6.21054 5.22796 6.21054 5.50323 5.94438L9.7871 1.85347C10.071 1.58732 10.071 1.15523 9.7871 0.88907C9.51183 0.622914 9.05591 0.622914 8.78065 0.88907L4.9957 4.49778L1.21935 0.88907C0.944086 0.622914 0.488172 0.622914 0.212903 0.88907Z" fill="#2F695D"/>
                    </svg>
                    </span></a></li>
                <li><a href="#">Resources <span class="down-arrow"><svg width="10" height="7" viewBox="0 0 10 7" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M0.212903 0.88907C-0.0709677 1.15523 -0.0709677 1.58732 0.212903 1.85347L4.49677 5.94438C4.77204 6.21054 5.22796 6.21054 5.50323 5.94438L9.7871 1.85347C10.071 1.58732 10.071 1.15523 9.7871 0.88907C9.51183 0.622914 9.05591 0.622914 8.78065 0.88907L4.9957 4.49778L1.21935 0.88907C0.944086 0.622914 0.488172 0.622914 0.212903 0.88907Z" fill="#2F695D"/>
                    </svg>
                    </span></a></li>
                <li><a href="#">Company <span class="down-arrow"><svg width="10" height="7" viewBox="0 0 10 7" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M0.212903 0.88907C-0.0709677 1.15523 -0.0709677 1.58732 0.212903 1.85347L4.49677 5.94438C4.77204 6.21054 5.22796 6.21054 5.50323 5.94438L9.7871 1.85347C10.071 1.58732 10.071 1.15523 9.7871 0.88907C9.51183 0.622914 9.05591 0.622914 8.78065 0.88907L4.9957 4.49778L1.21935 0.88907C0.944086 0.622914 0.488172 0.622914 0.212903 0.88907Z" fill="#2F695D"/>
                    </svg>
                    </span></a></li>
                <li><a href="#">Pricing</a></li>
                <li><a href="#">Support</a></li>
            </ul> */}
            {/* <AnimatedNavbar  duration={300}/> */}
        </>
    )
}

export default Menu
